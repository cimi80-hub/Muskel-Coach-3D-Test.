
/* =====================================================================
   SPRACHE / LANGUAGE – Deutsch & Englisch
   Die App ist auf Deutsch geschrieben; im englischen Modus übersetzt diese
   Schicht jeden angezeigten Text automatisch (Wörterbuch + Muster).
   Neue Texte: unten in I18N_D ergänzen  ('Deutsch':'English').
   ===================================================================== */
const LX=(de,en)=>LANG==='en'?en:de;
const LANG=(()=>{ try{ const l=testLocal.getItem('mc_lang'); if(l==='de'||l==='en') return l; }catch(e){} return 'en'; /* Standard: Englisch – Deutsch im Profil umschaltbar */ })();
document.documentElement.lang=LANG;
function setLang(l){ try{ testLocal.setItem('mc_lang',l); }catch(e){} location.reload(); }
const I18N_D={"Code eingeben":"Enter code","Neuer Knopf „Code eingeben“ unten im Demo-Feld – direkt zum Freischalten":"New “Enter code” button in the demo bar at the bottom – unlock directly","Freischalt-Code":"Unlock code","Gib hier den":"Enter the","lokalen Testcode":"6-digit code","ein, den du von":"you received from","bekommen hast. Danach ist die Vollversion für immer frei.":". The full version is then unlocked forever.","TEST-123456":"e.g. 123456","Noch keinen Code? Vollversion für":"No code yet? Full version for","💬 Im Chat kaufen":"💬 Buy in the chat","Abbrechen":"Cancel","🔑 Code eingeben":"🔑 Enter code","🎁 Demo · noch":"🎁 Demo ·","🔓 Basis ·":"🔓 Basic ·","Black Friday −50 %":"Black Friday −50 %","Bis 30.11.: Vollversion nur 4,99 € statt 9,99 € – auch schon während der 10-Tage-Demo sichtbar":"Until 30 Nov: full version only €4.99 instead of €9.99 – visible during the 10-day demo too",". Danach geht es mit der kostenlosen Basis-Version weiter (nur 3 Übungen, ohne Trainingsplan) – oder du behältst alles für einmalig":". After that you continue with the free basic version (only 3 exercises, no training plan) – or keep everything for a one-time","🔒 Trainingsplan & Training in der":"🔒 Training plan & workouts in the","Bis 30.11.:":"Until 30 Nov:","statt nur 3 – inkl. Maschinen, Kabel- & Freihantel-Übungen":"instead of only 3 – incl. machine, cable & free-weight exercises","Trainingsplan & Training":"Training plan & workouts","eigener Plan, geführtes Training mit Satz-Timer und Pausen":"your own plan, guided workouts with set timer and rests","Trainingstage planen und abhaken":"plan and tick off training days","Trainingskalender":"Training calendar","(nur 3 Übungen, ohne Trainingsplan)":"(only 3 exercises, no training plan)","Vollversion jetzt nur":"Full version now only","statt":"instead of","Laufband – zügiges Gehen":"Treadmill – brisk walk","Herz-Kreislauf, Beine":"Cardiovascular system, legs","Aufwärmen der Gelenke":"Warming up the joints","Laufband":"Treadmill","Anfänger":"Beginner","1 × 5–7 Min. (4 km/h)":"1 × 5–7 min (4 km/h)","Aufs Laufband stellen, Notaus-Clip an der Kleidung befestigen.":"Step onto the treadmill and attach the emergency stop clip to your clothing.","Mit 3 km/h starten und nach 1 Minute auf ca. 4 km/h steigern.":"Start at 3 km/h and increase to about 4 km/h after 1 minute.","Aufrecht gehen, Blick nach vorn, Arme locker mitschwingen.":"Walk upright, look ahead, let your arms swing loosely.","5–7 Minuten zügig gehen, bis dir warm ist und der Puls leicht erhöht ist.":"Walk briskly for 5–7 minutes until you feel warm and your pulse is slightly raised.","Langsam herunterregeln und danach direkt mit dem Training starten.":"Slowly reduce the speed and then start your workout right away.","Optional 2–5 % Steigung – macht schneller warm, ohne zu ermüden.":"Optionally 2–5 % incline – warms you up faster without tiring you.","Danach bei der ersten Übung 1–2 leichte Aufwärmsätze machen.":"Afterwards do 1–2 light warm-up sets for the first exercise.","Sich an den Griffen festhalten.":"Holding on to the handrails.","Zu schnell – das Aufwärmen soll nicht erschöpfen.":"Too fast – the warm-up shouldn't exhaust you.","Bankdrücken (Langhantel)":"Bench press (barbell)","Große Brustmuskeln":"Pectoralis major","Trizeps, vordere Schulter":"Triceps, front delts","Langhantel, Flachbank":"Barbell, flat bench","Leg dich auf die Bank, Augen unter der Stange, Füße fest auf dem Boden.":"Lie on the bench with your eyes under the bar and your feet firmly on the floor.","Greif die Stange etwas breiter als schulterbreit, Schulterblätter nach hinten-unten ziehen.":"Grip the bar slightly wider than shoulder width, pull your shoulder blades back and down.","Stange ausheben und über der Brust stabilisieren.":"Unrack the bar and stabilize it over your chest.","Kontrolliert zur unteren Brust absenken, Ellbogen ca. 45–70° vom Körper.":"Lower it under control to your lower chest, elbows about 45–70° from your body.","Kraftvoll nach oben drücken, ohne die Ellbogen ganz durchzuschlagen.":"Press up powerfully without locking out your elbows hard.","Leichtes Hohlkreuz ist okay – Po bleibt auf der Bank.":"A slight arch is okay – your glutes stay on the bench.","Bei schweren Gewichten immer mit Partner (Spotter) trainieren.":"With heavy weights always train with a partner (spotter).","Handgelenke gerade halten, Stange liegt im Handballen.":"Keep your wrists straight, the bar rests on the heel of your hand.","Stange auf der Brust abprallen lassen.":"Bouncing the bar off your chest.","Ellbogen 90° seitlich abspreizen – belastet die Schulter.":"Flaring the elbows out to 90° – stresses the shoulder.","Po hebt von der Bank ab.":"Lifting your glutes off the bench.","Schrägbankdrücken (Kurzhantel)":"Incline press (dumbbell)","Obere Brust":"Upper chest","Vordere Schulter, Trizeps":"Front delts, triceps","Kurzhanteln, Schrägbank 30–45°":"Dumbbells, incline bench 30–45°","Bank auf 30–45° stellen, Kurzhanteln auf den Oberschenkeln mitnehmen.":"Set the bench to 30–45°, bring the dumbbells up on your thighs.","Zurücklehnen, Hanteln seitlich auf Brusthöhe bringen.":"Lean back and bring the dumbbells to the sides at chest height.","Schulterblätter zusammenziehen, Brust raus.":"Squeeze your shoulder blades together, chest up.","Hanteln nach oben drücken, bis sie sich fast berühren.":"Press the dumbbells up until they almost touch.","Langsam wieder auf Brusthöhe absenken.":"Slowly lower them back to chest height.","Nicht steiler als 45° – sonst arbeitet vor allem die Schulter.":"Not steeper than 45° – otherwise mainly the shoulders work.","Unten eine gute Dehnung spüren, ohne Schmerz.":"Feel a good stretch at the bottom, without pain.","Hanteln oben laut zusammenschlagen.":"Banging the dumbbells together at the top.","Zu schnell absenken, Spannung verlieren.":"Lowering too fast and losing tension.","Kabel-Crossover / Butterfly":"Cable crossover / pec deck","Brust (innen)":"Chest (inner)","Vordere Schulter":"Front delts","Kabelzug oder Butterfly-Maschine":"Cable machine or pec deck machine","Griffe oben einstellen, mittig zwischen die Türme stellen, ein Fuß leicht vor.":"Set the handles high, stand in the middle between the towers, one foot slightly forward.","Oberkörper leicht nach vorn neigen, Arme weit geöffnet, Ellbogen leicht gebeugt.":"Lean your upper body slightly forward, arms wide open, elbows slightly bent.","Hände in einem Bogen vor dem Körper zusammenführen.":"Bring your hands together in an arc in front of your body.","Kurz die Brust anspannen.":"Briefly squeeze your chest.","Langsam in die Dehnung zurück öffnen.":"Slowly open back into the stretch.","Den Ellbogenwinkel während der ganzen Bewegung gleich lassen.":"Keep the elbow angle the same throughout the whole movement.","Stell dir vor, du umarmst einen großen Baum.":"Imagine you're hugging a big tree.","Arme beugen und strecken – dann wird es zum Drücken.":"Bending and straightening the arms – then it turns into a press.","Mit Schwung aus dem Rücken arbeiten.":"Using momentum from your back.","Liegestütze":"Push-ups","Brust":"Chest","Trizeps, Schulter, Rumpf":"Triceps, shoulders, core","Körpergewicht":"Bodyweight","3 × so viele wie sauber möglich":"3 × as many as you can do cleanly","Hände etwas breiter als schulterbreit auf den Boden, Arme gestreckt.":"Hands slightly wider than shoulder width on the floor, arms straight.","Körper bildet eine gerade Linie von Kopf bis Fersen, Bauch und Po fest.":"Your body forms a straight line from head to heels, abs and glutes tight.","Brust kontrolliert Richtung Boden senken, Ellbogen schräg nach hinten.":"Lower your chest under control towards the floor, elbows angled back.","Kurz über dem Boden stoppen.":"Stop just above the floor.","Explosiv wieder hochdrücken.":"Push back up explosively.","Zu schwer? Knie auf den Boden oder Hände auf eine Bank.":"Too hard? Knees on the floor or hands on a bench.","Zu leicht? Füße erhöht oder langsamer absenken.":"Too easy? Feet elevated or lower more slowly.","Hüfte hängt durch (Hohlkreuz).":"Sagging hips (arched lower back).","Po ragt nach oben.":"Glutes sticking up.","Kopf nach vorn strecken statt in Verlängerung der Wirbelsäule.":"Pushing the head forward instead of keeping it in line with the spine.","Dips am Barren":"Parallel bar dips","Untere Brust, Trizeps":"Lower chest, triceps","Dip-Barren":"Dip bars","Fortgeschritten":"Advanced","Auf den Barren stützen, Arme gestreckt, Schultern tief.":"Support yourself on the bars, arms straight, shoulders down.","Oberkörper leicht nach vorn neigen (mehr Brust) oder aufrecht (mehr Trizeps).":"Lean your upper body slightly forward (more chest) or stay upright (more triceps).","Langsam absenken, bis die Oberarme etwa parallel zum Boden sind.":"Lower slowly until your upper arms are roughly parallel to the floor.","Ellbogen zeigen nach hinten.":"Elbows point backwards.","Kraftvoll nach oben drücken.":"Press up powerfully.","Anfänger: Dip-Maschine oder Gummiband zur Unterstützung.":"Beginners: dip machine or resistance band for assistance.","Nicht tiefer gehen, als die Schulter angenehm mitmacht.":"Don't go deeper than your shoulders comfortably allow.","Zu tief absenken – Schulter wird überlastet.":"Going too deep – overloads the shoulders.","Schultern Richtung Ohren hochziehen.":"Shrugging the shoulders towards the ears.","Schulterdrücken (Kurzhantel)":"Shoulder press (dumbbell)","Vordere & seitliche Schulter":"Front & side delts","Trizeps, oberer Rücken":"Triceps, upper back","Kurzhanteln, Bank mit Lehne":"Dumbbells, bench with backrest","Aufrecht sitzen oder stehen, Hanteln auf Schulterhöhe, Handflächen nach vorn.":"Sit or stand upright, dumbbells at shoulder height, palms facing forward.","Bauch anspannen, Rücken gerade.":"Brace your abs, back straight.","Hanteln senkrecht nach oben drücken.":"Press the dumbbells straight up.","Oben fast strecken, Hanteln nähern sich über dem Kopf.":"Almost lock out at the top, the dumbbells come together over your head.","Kontrolliert zurück auf Ohr-/Kinnhöhe absenken.":"Lower under control back to ear/chin height.","Ellbogen leicht vor dem Körper führen – schont die Schulter.":"Keep the elbows slightly in front of your body – easier on the shoulders.","Im Sitzen mit Lehne kannst du dich besser stabilisieren.":"Seated with a backrest you can stabilize yourself better.","Starkes Hohlkreuz beim Drücken.":"Strongly arching the lower back while pressing.","Gewicht mit Schwung aus den Beinen hochwerfen.":"Throwing the weight up with momentum from the legs.","Seitheben (Kurzhantel)":"Lateral raise (dumbbell)","Seitliche Schulter":"Side delts","Trapez":"Trapezius","Kurzhanteln":"Dumbbells","Aufrecht stehen, Hanteln seitlich am Körper, Ellbogen leicht gebeugt.":"Stand upright, dumbbells at your sides, elbows slightly bent.","Schultern tief halten.":"Keep your shoulders down.","Arme seitlich anheben, bis sie etwa auf Schulterhöhe sind.":"Raise your arms to the sides until they're about shoulder height.","Kurz halten.":"Hold briefly.","Langsam wieder absenken.":"Lower slowly.","Lieber leichtes Gewicht und saubere Technik.":"Better a light weight and clean technique.","Denk daran, die Hanteln „nach außen“ statt nach oben zu schieben.":"Think of pushing the dumbbells “outwards” instead of up.","Schultern hochziehen (dann arbeitet der Nacken).":"Shrugging the shoulders (then the neck does the work).","Schwung holen mit dem Oberkörper.":"Swinging with the upper body.","Über Schulterhöhe hinaus anheben.":"Raising above shoulder height.","Frontheben":"Front raise","Kurzhanteln oder Hantelscheibe":"Dumbbells or weight plate","Aufrecht stehen, Hanteln vor den Oberschenkeln.":"Stand upright, dumbbells in front of your thighs.","Bauch fest, Ellbogen leicht gebeugt.":"Abs tight, elbows slightly bent.","Arm(e) nach vorn bis auf Schulterhöhe heben.":"Raise the arm(s) forward to shoulder height.","Kontrolliert absenken.":"Lower under control.","Abwechselnd links/rechts ist einfacher für Anfänger.":"Alternating left/right is easier for beginners.","Mit dem Oberkörper nach hinten lehnen.":"Leaning back with the upper body.","Arme zu schnell fallen lassen.":"Letting the arms drop too fast.","Face Pulls (Kabel)":"Face pulls (cable)","Hintere Schulter":"Rear delts","Oberer Rücken, Rotatorenmanschette":"Upper back, rotator cuff","Kabelzug mit Seil":"Cable machine with rope","Seil auf Gesichtshöhe einstellen, mit beiden Händen greifen.":"Set the rope to face height and grab it with both hands.","Einen Schritt zurück, Arme gestreckt, Körper stabil.":"Step back, arms straight, body stable.","Seil Richtung Gesicht ziehen, Ellbogen hoch und weit nach außen.":"Pull the rope towards your face, elbows high and wide.","Hände enden neben den Ohren, Schulterblätter zusammen.":"Your hands end up next to your ears, shoulder blades squeezed together.","Langsam zurück in die Streckung.":"Slowly return to the extended position.","Super Übung für gesunde Schultern und gute Haltung.":"Great exercise for healthy shoulders and good posture.","Leichtes Gewicht, viele Wiederholungen.":"Light weight, lots of reps.","Mit dem Körper nach hinten lehnen und reißen.":"Leaning back and yanking with the body.","Ellbogen fallen nach unten.":"Letting the elbows drop.","Shrugs (Schulterheben)":"Shrugs","Oberer Trapez (Nacken)":"Upper trapezius (neck)","Unterarme (Griff)":"Forearms (grip)","Kurzhanteln oder Langhantel":"Dumbbells or barbell","Aufrecht stehen, Hanteln seitlich, Arme gestreckt.":"Stand upright, dumbbells at your sides, arms straight.","Kopf neutral, Blick geradeaus.":"Head neutral, look straight ahead.","Schultern gerade nach oben Richtung Ohren ziehen.":"Pull your shoulders straight up towards your ears.","Oben 1–2 Sekunden halten.":"Hold for 1–2 seconds at the top.","Nur hoch und runter – nicht kreisen.":"Only up and down – don't roll.","Arme bleiben gestreckt, sie sind nur „Haken“.":"Your arms stay straight, they're just “hooks”.","Schultern kreisen lassen.":"Rolling the shoulders.","Kopf nach vorn schieben.":"Pushing the head forward.","Mit den Armen mitziehen.":"Pulling with the arms.","Aufrechtes Rudern":"Upright row","Trapez, seitliche Schulter":"Trapezius, side delts","Bizeps":"Biceps","Langhantel oder SZ-Stange":"Barbell or EZ bar","Stange schulterbreit im Obergriff vor den Oberschenkeln halten.":"Hold the bar shoulder-width with an overhand grip in front of your thighs.","Aufrecht stehen, Bauch fest.":"Stand upright, abs tight.","Stange nah am Körper nach oben ziehen, Ellbogen führen.":"Pull the bar up close to your body, leading with the elbows.","Bis etwa Brust- bzw. Schulterhöhe ziehen.":"Pull up to about chest or shoulder height.","Nicht zu eng greifen – schulterbreit schont die Schulter.":"Don't grip too narrow – shoulder width is easier on the shoulders.","Bei Schulterbeschwerden lieber Shrugs oder Face Pulls.":"With shoulder problems, better do shrugs or face pulls.","Stange bis unters Kinn reißen.":"Yanking the bar up under your chin.","Handgelenke stark abknicken.":"Bending the wrists strongly.","Nacken beugen & strecken":"Neck flexion & extension","Nackenmuskulatur vorn & hinten":"Front & back neck muscles","Körpergewicht (optional Hand als Widerstand)":"Bodyweight (optionally hand as resistance)","2–3 × 10–15 langsam":"2–3 × 10–15 slowly","Aufrecht sitzen oder stehen, Schultern locker.":"Sit or stand upright, shoulders relaxed.","Kinn langsam Richtung Brust senken.":"Slowly lower your chin towards your chest.","Kopf langsam wieder aufrichten und leicht nach hinten führen.":"Slowly raise your head again and tilt it slightly back.","Für mehr Widerstand die Hand an Stirn bzw. Hinterkopf legen und leicht dagegen drücken.":"For more resistance, place your hand on your forehead or the back of your head and push lightly against it.","Ruhig atmen, nichts ruckartig.":"Breathe calmly, no jerky movements.","Sehr langsam ausführen – der Nacken ist empfindlich.":"Do it very slowly – the neck is sensitive.","Gut als Aufwärmen und gegen Verspannungen.":"Good as a warm-up and against tension.","Ruckartige Bewegungen.":"Jerky movements.","Kopf weit in den Nacken werfen.":"Throwing the head far back.","Nacken seitlich neigen":"Neck side bend","Seitliche Nackenmuskulatur":"Side neck muscles","2 × 10 pro Seite":"2 × 10 per side","Aufrecht stehen, Schultern tief und locker.":"Stand upright, shoulders low and relaxed.","Kopf langsam zur rechten Schulter neigen (Ohr Richtung Schulter).":"Slowly tilt your head towards your right shoulder (ear towards shoulder).","Zurück zur Mitte.":"Back to the middle.","Zur linken Seite neigen.":"Tilt to the left side.","Optional mit der Hand leichten Gegendruck geben.":"Optionally apply light counter-pressure with your hand.","Schulter nicht zum Ohr hochziehen.":"Don't pull your shoulder up to your ear.","Am Ende der Bewegung kurz halten für eine sanfte Dehnung.":"Hold briefly at the end of the movement for a gentle stretch.","Kopf drehen statt neigen.":"Turning the head instead of tilting it.","Zu viel Druck mit der Hand.":"Too much pressure with the hand.","Gerader Bauchmuskel":"Rectus abdominis","Schräge Bauchmuskeln":"Obliques","Matte":"Mat","Auf den Rücken legen, Knie angewinkelt, Füße auf dem Boden.":"Lie on your back, knees bent, feet on the floor.","Arme vor der Brust kreuzen oder Fingerspitzen an die Schläfen.":"Cross your arms over your chest or put your fingertips on your temples.","Oberkörper einrollen, Schulterblätter vom Boden lösen.":"Curl up your upper body, lifting your shoulder blades off the floor.","Oben kurz den Bauch fest anspannen.":"Briefly squeeze your abs hard at the top.","Langsam zurückrollen, Kopf nicht ablegen.":"Roll back slowly without resting your head.","Es geht um das Einrollen, nicht ums Hochkommen.":"It's about curling up, not about getting up.","Blick schräg nach oben, Platz für eine Faust zwischen Kinn und Brust.":"Look diagonally up, room for a fist between chin and chest.","Am Kopf ziehen.":"Pulling on your head.","Mit Schwung hochreißen.":"Jerking up with momentum.","Hängendes Knie-/Beinheben":"Hanging knee/leg raise","Unterer Bauch":"Lower abs","Hüftbeuger, Griffkraft":"Hip flexors, grip strength","Klimmzugstange":"Pull-up bar","An die Stange hängen, Arme gestreckt, Schultern aktiv.":"Hang from the bar, arms straight, shoulders active.","Körper ruhig halten, nicht schaukeln.":"Keep your body still, don't swing.","Knie Richtung Brust ziehen, Becken leicht einrollen.":"Pull your knees towards your chest, tilting your pelvis slightly up.","Oben kurz halten.":"Hold briefly at the top.","Anfänger: erst Knie anziehen, später gestreckte Beine.":"Beginners: first raise your knees, later straight legs.","Alternative: Beinheben liegend auf der Matte.":"Alternative: lying leg raises on the mat.","Mit Schwung arbeiten.":"Using momentum.","Nur die Beine heben, ohne das Becken einzurollen.":"Only lifting the legs without curling the pelvis.","Unterarmstütz (Plank)":"Forearm plank","Gesamter Rumpf":"Whole core","Schultern, Po":"Shoulders, glutes","3 × 20–60 Sek.":"3 × 20–60 sec","Unterarme schulterbreit auflegen, Ellbogen unter den Schultern.":"Place your forearms shoulder-width apart, elbows under your shoulders.","Beine strecken, auf die Zehenspitzen.":"Straighten your legs, up on your toes.","Körper bildet eine gerade Linie.":"Your body forms a straight line.","Bauch und Po fest anspannen.":"Squeeze your abs and glutes.","Position halten und ruhig weiteratmen.":"Hold the position and keep breathing calmly.","Lieber kürzer und sauber als lang und durchhängend.":"Better shorter and clean than long and sagging.","Ziehe gedanklich die Ellbogen Richtung Füße – das erhöht die Spannung.":"Mentally pull your elbows towards your feet – that increases the tension.","Hüfte hängt durch.":"Sagging hips.","Po zu hoch.":"Glutes too high.","Luft anhalten.":"Holding your breath.","Mountain Climbers":"Mountain climbers","Bauch, Hüftbeuger":"Abs, hip flexors","Schultern, Ausdauer":"Shoulders, endurance","3 × 30 Sek.":"3 × 30 sec","Startposition wie beim Liegestütz oben.":"Starting position like the top of a push-up.","Ein Knie Richtung Brust ziehen.":"Pull one knee towards your chest.","Zurück und sofort das andere Knie anziehen.":"Back, and immediately pull in the other knee.","Im Wechsel zügig weiter.":"Keep alternating quickly.","Hüfte bleibt tief und stabil.":"Your hips stay low and stable.","Erst langsam für Technik, dann Tempo steigern.":"Slowly at first for technique, then increase the pace.","Po weit nach oben schieben.":"Pushing the glutes far up.","Hände wandern nach vorn.":"Hands creeping forward.","Langhantel-Curls":"Barbell curls","Unterarme":"Forearms","Aufrecht stehen, Stange schulterbreit im Untergriff.":"Stand upright, bar shoulder-width with an underhand grip.","Ellbogen eng am Körper fixieren.":"Keep your elbows fixed close to your body.","Stange in einem Bogen Richtung Schultern beugen.":"Curl the bar in an arc towards your shoulders.","Oben den Bizeps fest anspannen.":"Squeeze your biceps hard at the top.","Langsam bis zur fast vollen Streckung absenken.":"Lower slowly until almost fully extended.","SZ-Stange schont die Handgelenke.":"An EZ bar is easier on the wrists.","Absenken dauert ca. 2–3 Sekunden.":"Lowering takes about 2–3 seconds.","Ellbogen wandern nach vorn.":"Elbows drifting forward.","Oberkörper schwingt nach hinten.":"Upper body swinging back.","Kurzhantel-Curls":"Dumbbell curls","Aufrecht stehen, Hanteln seitlich, Handflächen nach vorn.":"Stand upright, dumbbells at your sides, palms facing forward.","Ellbogen am Körper lassen.":"Keep your elbows at your body.","Hantel(n) nach oben beugen.":"Curl the dumbbell(s) up.","Oben kurz anspannen.":"Squeeze briefly at the top.","Abwechselnd oder gleichzeitig – beides geht.":"Alternating or both at once – both work.","Für mehr Wirkung die Handfläche oben leicht nach außen drehen.":"For more effect, turn your palm slightly outwards at the top.","Gewicht mit Schwung hochwerfen.":"Throwing the weight up with momentum.","Nur halbe Bewegung.":"Only half the range of motion.","Hammer-Curls":"Hammer curls","Bizeps, Oberarmmuskel (Brachialis)":"Biceps, brachialis","Hanteln seitlich halten, Daumen zeigen nach vorn (wie ein Hammer).":"Hold the dumbbells at your sides, thumbs pointing forward (like a hammer).","Ellbogen fixieren.":"Fix your elbows.","Hantel nach oben beugen, Griff bleibt neutral.":"Curl the dumbbell up, the grip stays neutral.","Langsam absenken.":"Lower slowly.","Macht die Oberarme „dicker“ und stärkt den Griff.":"Makes the upper arms “thicker” and strengthens the grip.","Handgelenk dreht sich.":"Wrist rotating.","Schultern ziehen nach vorn.":"Shoulders pulling forward.","Konzentrationscurls":"Concentration curls","Bizeps (isoliert)":"Biceps (isolated)","Kurzhantel, Bank":"Dumbbell, bench","3 × 10–12 pro Arm":"3 × 10–12 per arm","Auf die Bank setzen, Beine gespreizt, leicht nach vorn lehnen.":"Sit on the bench, legs apart, lean slightly forward.","Ellbogen an die Innenseite des Oberschenkels legen.":"Rest your elbow against the inside of your thigh.","Hantel Richtung Schulter beugen.":"Curl the dumbbell towards your shoulder.","Oben stark anspannen.":"Squeeze hard at the top.","Langsam ganz absenken.":"Lower slowly all the way.","Nur der Unterarm bewegt sich – volle Konzentration auf den Muskel.":"Only the forearm moves – full focus on the muscle.","Ellbogen vom Bein lösen.":"Lifting the elbow off the leg.","Mit dem Oberkörper mithelfen.":"Helping with the upper body.","Trizepsdrücken am Kabel":"Cable triceps pushdown","Trizeps":"Triceps","Kabelzug mit Stange oder Seil":"Cable machine with bar or rope","Vor den Kabelzug stellen, Griff oben fassen.":"Stand in front of the cable machine and grab the handle at the top.","Ellbogen eng am Körper, Oberkörper leicht nach vorn.":"Elbows close to your body, upper body slightly forward.","Griff nach unten drücken, bis die Arme gestreckt sind.":"Push the handle down until your arms are straight.","Unten den Trizeps anspannen.":"Squeeze your triceps at the bottom.","Langsam zurück bis die Unterarme etwa waagerecht sind.":"Slowly return until your forearms are about horizontal.","Oberarme bleiben die ganze Zeit still.":"Your upper arms stay still the whole time.","Mit Seil kannst du unten die Hände auseinanderziehen.":"With a rope you can pull your hands apart at the bottom.","Ellbogen wandern nach vorn/hinten.":"Elbows drifting forward/back.","Mit Körpergewicht runterdrücken.":"Pushing down with your body weight.","Trizepsstrecken über Kopf":"Overhead triceps extension","Trizeps (langer Kopf)":"Triceps (long head)","Kurzhantel":"Dumbbell","Stehen oder sitzen, Hantel mit beiden Händen über den Kopf.":"Stand or sit, dumbbell above your head with both hands.","Oberarme neben dem Kopf, Ellbogen zeigen nach vorn-oben.":"Upper arms next to your head, elbows pointing forward and up.","Hantel hinter dem Kopf langsam absenken.":"Slowly lower the dumbbell behind your head.","Wieder nach oben strecken.":"Extend back up.","Bauch anspannen, kein Hohlkreuz.":"Brace your abs, no arched back.","Ellbogen nicht weit nach außen fallen lassen.":"Don't let your elbows flare far out.","Starkes Hohlkreuz.":"Strongly arched back.","Zu schweres Gewicht – belastet den Ellbogen.":"Weight too heavy – strains the elbow.","Bank-Dips":"Bench dips","Vordere Schulter, Brust":"Front delts, chest","Bank oder Stuhl":"Bench or chair","Hände schulterbreit hinter dir auf die Bankkante, Finger nach vorn.":"Hands shoulder-width behind you on the edge of the bench, fingers forward.","Beine nach vorn strecken (leichter: Knie beugen).":"Stretch your legs forward (easier: bend your knees).","Po nah an der Bank absenken, Ellbogen zeigen nach hinten.":"Lower your glutes close to the bench, elbows pointing back.","Bis die Oberarme etwa waagerecht sind.":"Until your upper arms are roughly horizontal.","Über den Trizeps wieder hochdrücken.":"Press back up using your triceps.","Gut für zu Hause – ein stabiler Stuhl reicht.":"Good for home – a sturdy chair is enough.","Zu tief gehen – Schulter überlastet.":"Going too deep – overloads the shoulder.","Po weit von der Bank weg.":"Glutes far away from the bench.","Enge Liegestütze":"Close-grip push-ups","Brust, Schulter":"Chest, shoulders","Liegestützposition, Hände eng unter der Brust.":"Push-up position, hands close together under your chest.","Körper gerade, Bauch fest.":"Body straight, abs tight.","Absenken, Ellbogen streifen eng am Körper nach hinten.":"Lower down, elbows brushing back close to your body.","Brust nah zum Boden.":"Chest close to the floor.","Hochdrücken.":"Push up.","Erleichterung: auf den Knien oder an einer Bank.":"Easier: on your knees or against a bench.","Ellbogen gehen weit nach außen.":"Elbows flaring far out.","Klimmzüge":"Pull-ups","Breiter Rückenmuskel (Latissimus)":"Latissimus dorsi (lats)","Bizeps, hintere Schulter":"Biceps, rear delts","Stange etwas breiter als schulterbreit im Obergriff fassen.":"Grab the bar slightly wider than shoulder width with an overhand grip.","Aktiv hängen: Schultern leicht nach unten ziehen.":"Hang actively: pull your shoulders slightly down.","Brust zur Stange ziehen, Ellbogen nach unten führen.":"Pull your chest to the bar, driving your elbows down.","Kinn über die Stange.":"Chin over the bar.","Kontrolliert bis zur Streckung absenken.":"Lower under control until your arms are straight.","Noch kein Klimmzug? Gummiband, Klimmzugmaschine oder nur langsames Herunterlassen üben.":"No pull-up yet? Practise with a resistance band, an assisted pull-up machine or just slow lowering.","Mit den Beinen schwingen (Kipping).":"Swinging with the legs (kipping).","Nur halbe Wiederholungen.":"Only half reps.","Latzug":"Lat pulldown","Latissimus":"Lats","Bizeps, mittlerer Rücken":"Biceps, mid back","Latzugmaschine":"Lat pulldown machine","Hinsetzen, Knie unter das Polster, Stange breit greifen.":"Sit down, knees under the pad, grab the bar wide.","Oberkörper leicht nach hinten neigen, Brust raus.":"Lean your upper body slightly back, chest up.","Stange zur oberen Brust ziehen, Ellbogen nach unten-hinten.":"Pull the bar to your upper chest, elbows down and back.","Schulterblätter zusammenziehen.":"Squeeze your shoulder blades together.","Langsam nach oben zurücklassen.":"Slowly let it go back up.","Denke „Ellbogen in die Hosentaschen“.":"Think “elbows into your trouser pockets”.","Stange in den Nacken ziehen.":"Pulling the bar behind your neck.","Weit zurücklehnen und reißen.":"Leaning far back and yanking.","Langhantelrudern vorgebeugt":"Bent-over barbell row","Mittlerer & oberer Rücken":"Mid & upper back","Latissimus, Bizeps, unterer Rücken":"Lats, biceps, lower back","Langhantel":"Barbell","Stange schulterbreit greifen, Knie leicht beugen.":"Grab the bar shoulder-width, bend your knees slightly.","Mit geradem Rücken nach vorn beugen (ca. 45°).":"Bend forward with a straight back (about 45°).","Stange Richtung Bauchnabel ziehen.":"Pull the bar towards your belly button.","Schulterblätter zusammendrücken.":"Squeeze your shoulder blades together.","Rücken bleibt die ganze Zeit gerade – Blick leicht nach vorn-unten.":"Your back stays straight the whole time – look slightly forward and down.","Runder Rücken.":"Rounded back.","Oberkörper richtet sich beim Ziehen auf.":"Upper body straightening up while pulling.","Kurzhantelrudern einarmig":"One-arm dumbbell row","Latissimus, mittlerer Rücken":"Lats, mid back","3 × 10–12 pro Seite":"3 × 10–12 per side","Ein Knie und eine Hand auf die Bank, Rücken gerade.":"One knee and one hand on the bench, back straight.","Hantel mit dem freien Arm hängen lassen.":"Let the dumbbell hang with your free arm.","Hantel Richtung Hüfte ziehen, Ellbogen nah am Körper.":"Pull the dumbbell towards your hip, elbow close to your body.","Ziehe eher Richtung Hüfte als Richtung Schulter.":"Pull towards your hip rather than towards your shoulder.","Oberkörper aufdrehen.":"Twisting the upper body open.","Mit Schwung reißen.":"Yanking with momentum.","Kreuzheben":"Deadlift","Unterer Rücken, Po, Beinbeuger":"Lower back, glutes, hamstrings","Oberschenkel, Trapez, Griff":"Thighs, trapezius, grip","Füße hüftbreit, Stange über der Fußmitte.":"Feet hip-width apart, bar over the middle of your feet.","Hüfte nach hinten, Knie beugen, Stange schulterbreit greifen.":"Hips back, bend your knees, grab the bar shoulder-width.","Rücken gerade, Brust raus, Schultern über der Stange.":"Back straight, chest up, shoulders over the bar.","Aus den Beinen drücken, Stange nah am Körper hochziehen.":"Push through your legs and pull the bar up close to your body.","Oben aufrecht stehen, dann kontrolliert wieder ablegen.":"Stand upright at the top, then lower it back down under control.","Technik zuerst mit leichtem Gewicht oder vom Trainer zeigen lassen.":"Learn the technique with a light weight first or have a trainer show you.","Vor dem Heben tief einatmen und den Bauch fest machen.":"Take a deep breath and brace your abs before lifting.","Runder Rücken – größtes Verletzungsrisiko!":"Rounded back – the biggest injury risk!","Stange weit vom Körper weg.":"Bar far away from your body.","Oben ins Hohlkreuz lehnen.":"Leaning back into an arch at the top.","Kniebeuge (Langhantel)":"Squat (barbell)","Oberschenkel vorn, Po":"Front thighs, glutes","Beinbeuger, Rumpf":"Hamstrings, core","Langhantel, Rack":"Barbell, rack","Stange auf den oberen Rücken (nicht auf den Nacken) legen.":"Place the bar on your upper back (not on your neck).","Füße etwa schulterbreit, Zehen leicht nach außen.":"Feet about shoulder-width, toes slightly out.","Tief einatmen, Bauch fest, Hüfte nach hinten und Knie beugen.":"Breathe in deeply, brace your abs, hips back and bend your knees.","So tief wie mit geradem Rücken möglich (Ideal: Oberschenkel waagerecht).":"As deep as you can with a straight back (ideal: thighs parallel to the floor).","Aus den Fersen kraftvoll hochdrücken.":"Drive up powerfully through your heels.","Knie zeigen in Richtung der Zehen.":"Knees point in the direction of your toes.","Anfänger: erst ohne Gewicht oder mit Kurzhantel vor der Brust (Goblet Squat).":"Beginners: first without weight or with a dumbbell in front of the chest (goblet squat).","Knie fallen nach innen.":"Knees caving in.","Fersen heben ab.":"Heels lifting off.","Runder Rücken unten.":"Rounded back at the bottom.","Ausfallschritte":"Lunges","Oberschenkel, Po":"Thighs, glutes","Beinbeuger, Gleichgewicht":"Hamstrings, balance","Kurzhanteln oder Körpergewicht":"Dumbbells or bodyweight","3 × 10 pro Bein":"3 × 10 per leg","Aufrecht stehen, Hanteln seitlich.":"Stand upright, dumbbells at your sides.","Großen Schritt nach vorn machen.":"Take a big step forward.","Hinteres Knie Richtung Boden absenken, Oberkörper aufrecht.":"Lower your back knee towards the floor, upper body upright.","Vorderes Knie über dem Fuß, nicht weit über die Zehen.":"Front knee over your foot, not far past your toes.","Über die vordere Ferse zurückdrücken, Bein wechseln.":"Push back through your front heel, switch legs.","Längerer Schritt = mehr Po, kürzerer = mehr Oberschenkel.":"Longer step = more glutes, shorter step = more thighs.","Vorderes Knie knickt nach innen.":"Front knee caving in.","Oberkörper fällt nach vorn.":"Upper body falling forward.","Rumänisches Kreuzheben":"Romanian deadlift","Beinbeuger, Po":"Hamstrings, glutes","Unterer Rücken":"Lower back","Langhantel oder Kurzhanteln":"Barbell or dumbbells","Aufrecht stehen, Stange vor den Oberschenkeln.":"Stand upright, bar in front of your thighs.","Knie leicht gebeugt und so lassen.":"Knees slightly bent and keep them that way.","Hüfte weit nach hinten schieben, Stange gleitet an den Beinen nach unten.":"Push your hips far back, the bar slides down along your legs.","Bis du eine starke Dehnung hinten im Oberschenkel spürst.":"Until you feel a strong stretch in the back of your thighs.","Hüfte nach vorn schieben und aufrichten.":"Push your hips forward and stand up.","Bewegung kommt aus der Hüfte – stell dir vor, du schließt eine Tür mit dem Po.":"The movement comes from the hips – imagine closing a door with your glutes.","Rücken rundet sich.":"Back rounding.","Knie zu stark beugen (wird zur Kniebeuge).":"Bending the knees too much (turns into a squat).","Wadenheben stehend":"Standing calf raise","Waden":"Calves","Stufe, optional Kurzhanteln":"Step, optionally dumbbells","Mit den Fußballen auf eine Stufe stellen, Fersen frei.":"Stand with the balls of your feet on a step, heels free.","Aufrecht stehen, ggf. irgendwo festhalten.":"Stand upright, hold on to something if needed.","Fersen so hoch wie möglich drücken.":"Push your heels up as high as possible.","Langsam unter die Stufe absenken für die Dehnung.":"Lower slowly below the step for the stretch.","Volle Bewegung ist wichtiger als viel Gewicht.":"Full range of motion is more important than heavy weight.","Wippen ohne Kontrolle.":"Bouncing without control.","Hip Thrust":"Hip thrust","Großer Gesäßmuskel":"Gluteus maximus","Beinbeuger":"Hamstrings","Bank, Langhantel (mit Polster)":"Bench, barbell (with pad)","Oberer Rücken an die Bankkante, Stange (mit Polster) auf der Hüfte.":"Upper back against the edge of the bench, bar (with pad) on your hips.","Füße hüftbreit, Knie etwa 90° wenn oben.":"Feet hip-width apart, knees at about 90° at the top.","Hüfte nach oben drücken, bis der Körper von Schultern bis Knie gerade ist.":"Push your hips up until your body is straight from shoulders to knees.","Oben den Po fest zusammenkneifen.":"Squeeze your glutes hard at the top.","Kinn leicht zur Brust – verhindert Hohlkreuz.":"Chin slightly towards your chest – prevents arching.","Ohne Gewicht auf dem Boden = Glute Bridge (Einsteiger).":"Without weight on the floor = glute bridge (beginners).","Oben ins Hohlkreuz drücken.":"Pushing into an arched back at the top.","Aus den Zehen statt aus den Fersen drücken.":"Pushing through your toes instead of your heels.","Brustpresse (Maschine)":"Chest press (machine)","Brustpresse-Maschine":"Chest press machine","Sitz so einstellen, dass die Griffe auf Höhe der mittleren Brust sind.":"Adjust the seat so the handles are at mid-chest height.","Rücken fest an die Lehne, Schulterblätter nach hinten-unten.":"Back firmly against the backrest, shoulder blades back and down.","Griffe nach vorn drücken, bis die Arme fast gestreckt sind.":"Push the handles forward until your arms are almost straight.","Langsam zurück, bis du eine leichte Dehnung in der Brust spürst.":"Slowly return until you feel a slight stretch in your chest.","Ideal, um sicher bis kurz vor Muskelversagen zu trainieren – kein Spotter nötig.":"Ideal for training safely close to failure – no spotter needed.","Ellbogen etwas unter Schulterhöhe führen.":"Keep the elbows slightly below shoulder height.","Sitz zu tief/hoch – dann arbeitet vor allem die Schulter.":"Seat too low/high – then mainly the shoulders work.","Gewicht zurückknallen lassen.":"Letting the weight slam back.","Schulterpresse (Maschine)":"Shoulder press (machine)","Schulterpresse-Maschine":"Shoulder press machine","Sitz so einstellen, dass die Griffe etwa auf Schulterhöhe sind.":"Adjust the seat so the handles are about at shoulder height.","Rücken an die Lehne, Bauch anspannen.":"Back against the backrest, brace your abs.","Griffe nach oben drücken, bis die Arme fast gestreckt sind.":"Press the handles up until your arms are almost straight.","Kontrolliert bis auf Kinnhöhe absenken.":"Lower under control to chin height.","Sicherer als freie Gewichte, wenn du allein trainierst.":"Safer than free weights when you train alone.","Po rutscht nach vorn, Hohlkreuz.":"Glutes sliding forward, arched back.","Arme oben komplett durchdrücken.":"Fully locking out the arms at the top.","Reverse Butterfly (Maschine)":"Reverse fly (machine)","Oberer Rücken, Trapez":"Upper back, trapezius","Butterfly-Maschine (umgekehrt) oder Kabel":"Pec deck machine (reversed) or cable","Mit der Brust zum Polster setzen, Griffe auf Schulterhöhe.":"Sit with your chest towards the pad, handles at shoulder height.","Arme vor dem Körper, Ellbogen leicht gebeugt.":"Arms in front of your body, elbows slightly bent.","Arme in einem Bogen weit nach hinten-außen führen.":"Move your arms in an arc far back and out.","Schulterblätter am Ende kurz zusammenziehen.":"Briefly squeeze your shoulder blades together at the end.","Langsam zurück nach vorn.":"Slowly return to the front.","Wichtig für breite Schultern und eine gute Haltung.":"Important for broad shoulders and good posture.","Leichtes Gewicht, sauber und kontrolliert.":"Light weight, clean and controlled.","Schultern zu den Ohren hochziehen.":"Shrugging the shoulders up to the ears.","Rudern am Kabel (sitzend)":"Seated cable row","Mittlerer Rücken, Latissimus":"Mid back, lats","Kabelzug mit V-Griff":"Cable machine with V-handle","Hinsetzen, Füße an die Platte, Knie leicht gebeugt.":"Sit down, feet on the platform, knees slightly bent.","V-Griff fassen, Oberkörper aufrecht, Brust raus.":"Grab the V-handle, upper body upright, chest up.","Griff zum Bauch ziehen, Ellbogen eng am Körper nach hinten.":"Pull the handle to your belly, elbows back close to your body.","Schulterblätter fest zusammenziehen.":"Squeeze your shoulder blades firmly together.","Arme langsam nach vorn strecken, Schultern dürfen leicht mitgehen.":"Slowly extend your arms forward, your shoulders may move slightly with them.","Oberkörper bleibt fast ruhig – kein Schaukeln.":"Your upper body stays almost still – no rocking.","Mit dem Oberkörper weit zurückwerfen.":"Throwing the upper body far back.","Runder Rücken beim Vorgehen.":"Rounded back when going forward.","Beinpresse":"Leg press","Beinbeuger, Waden":"Hamstrings, calves","Beinpresse (Maschine)":"Leg press (machine)","Hinsetzen, Rücken und Po fest an die Lehne.":"Sit down, back and glutes firmly against the backrest.","Füße schulterbreit mittig auf die Platte.":"Feet shoulder-width in the middle of the platform.","Sicherung lösen, Knie langsam Richtung Brust beugen.":"Release the safety, slowly bend your knees towards your chest.","So tief, wie der Po noch am Polster bleibt.":"As deep as your glutes still stay on the pad.","Über die ganze Fußsohle zurückdrücken, Knie nicht durchstrecken.":"Push back through your whole foot, don't lock your knees.","Füße höher = mehr Po & Beinbeuger, tiefer = mehr vorderer Oberschenkel.":"Feet higher = more glutes & hamstrings, lower = more front thighs.","Sehr gut, um die Beine schwer und sicher zu trainieren.":"Great for training the legs heavy and safely.","Knie oben ganz durchdrücken.":"Fully locking the knees at the top.","Po hebt unten vom Polster ab (runder unterer Rücken).":"Glutes lifting off the pad at the bottom (rounded lower back).","Beinstrecker (Maschine)":"Leg extension (machine)","Vorderer Oberschenkel":"Front thighs","Beinstrecker-Maschine":"Leg extension machine","Sitz so einstellen, dass das Knie auf Höhe des Drehpunkts ist.":"Adjust the seat so your knee is level with the pivot point.","Polster vorn am Schienbein, knapp über dem Fuß.":"Pad on the front of your shins, just above the feet.","Beine nach oben strecken.":"Extend your legs up.","Oben 1 Sekunde den Oberschenkel anspannen.":"Squeeze your thighs for 1 second at the top.","Gut als zweite Beinübung nach Beinpresse oder Kniebeuge.":"Good as a second leg exercise after leg press or squats.","Gewicht hochschleudern.":"Swinging the weight up.","Po hebt vom Sitz ab.":"Glutes lifting off the seat.","Beinbeuger sitzend (Maschine)":"Seated leg curl (machine)","Hinterer Oberschenkel":"Hamstrings","Beinbeuger-Maschine":"Leg curl machine","Sitz einstellen, Knie am Drehpunkt, Oberschenkelpolster fest.":"Adjust the seat, knees at the pivot point, thigh pad tight.","Polster hinten an die Unterschenkel, knapp über der Ferse.":"Pad behind your lower legs, just above the heels.","Beine nach unten-hinten beugen, so weit es geht.":"Bend your legs down and back as far as possible.","Die Rückseite der Beine wird oft vernachlässigt – wichtig für gesunde Knie.":"The back of the legs is often neglected – important for healthy knees.","Hüfte hebt ab.":"Hips lifting off.","Zu schnell zurückschnellen lassen.":"Letting it snap back too fast.","Bizeps-Curls am Kabel":"Cable biceps curls","Seilzug unten einstellen, Griff im Untergriff fassen.":"Set the cable low, grab the handle with an underhand grip.","Aufrecht stehen, Ellbogen eng am Körper.":"Stand upright, elbows close to your body.","Griff Richtung Schultern beugen.":"Curl the handle towards your shoulders.","Langsam wieder strecken.":"Slowly extend again.","Das Kabel hält die Spannung über die ganze Bewegung.":"The cable keeps the tension throughout the whole movement.","Mit dem Rücken nachhelfen.":"Helping with your back.","Kurzhantel-Bankdrücken":"Dumbbell bench press","Kurzhanteln, Flachbank":"Dumbbells, flat bench","Mit den Hanteln auf den Oberschenkeln hinsetzen und zurücklegen, Hanteln auf Brusthöhe.":"Sit down with the dumbbells on your thighs and lie back, dumbbells at chest height.","Schulterblätter zusammen, Füße fest am Boden.":"Shoulder blades together, feet firmly on the floor.","Hanteln nach oben drücken, oben leicht zueinander führen.":"Press the dumbbells up, bringing them slightly together at the top.","Langsam bis auf Brusthöhe absenken.":"Lower slowly to chest height.","Größere Bewegung als mit der Langhantel – gut für die Dehnung.":"Bigger range of motion than with a barbell – good for the stretch.","Ellbogen ca. 45° vom Körper.":"Elbows about 45° from your body.","Hanteln oben zusammenschlagen.":"Banging the dumbbells together at the top.","Ellbogen ganz seitlich abspreizen.":"Flaring the elbows fully to the sides.","Kurzhantel-Fliegende (flach)":"Dumbbell flyes (flat)","Große Brustmuskeln (innen & außen)":"Pectoralis major (inner & outer)","Auf die Flachbank legen, Hanteln über der Brust, Handflächen zueinander.":"Lie on the flat bench, dumbbells over your chest, palms facing each other.","Ellbogen leicht gebeugt fixieren.":"Fix your elbows slightly bent.","Arme in einem großen Bogen seitlich absenken, bis du die Dehnung in der Brust spürst.":"Lower your arms to the sides in a wide arc until you feel the stretch in your chest.","Im gleichen Bogen wieder nach oben „umarmen“.":"“Hug” back up along the same arc.","Leichtes Gewicht – es geht um die Dehnung, nicht ums Drücken.":"Light weight – it's about the stretch, not about pressing.","Wie beim Umarmen eines großen Baums.":"Like hugging a big tree.","Arme durchstrecken (Belastung fürs Ellbogengelenk).":"Locking out the arms (strains the elbow joint).","Zu tief absenken.":"Lowering too deep.","Kabel-Crossover von unten":"Low-to-high cable crossover","Kabelzug (beide Rollen unten)":"Cable machine (both pulleys low)","Beide Rollen ganz unten einstellen, Griffe fassen, in die Mitte stellen.":"Set both pulleys all the way down, grab the handles, stand in the middle.","Arme leicht gebeugt neben dem Körper.":"Arms slightly bent next to your body.","Griffe schräg nach oben vor der Brust zusammenführen.":"Bring the handles together diagonally upwards in front of your chest.","Oben kurz anspannen, langsam zurück.":"Squeeze briefly at the top, return slowly.","Trifft besonders die obere Brust.":"Especially targets the upper chest.","Oberkörper aufrecht, Brust raus.":"Upper body upright, chest up.","Mit dem Rücken mitziehen.":"Pulling with your back.","Ellbogen stark beugen (dann wird es ein Drücken).":"Bending the elbows a lot (then it turns into a press).","Kurzhantel-Pullover":"Dumbbell pullover","Brust & Latissimus":"Chest & lats","Trizeps, Sägezahnmuskel":"Triceps, serratus anterior","Eine Kurzhantel, Flachbank":"One dumbbell, flat bench","Auf die Bank legen, eine Hantel mit beiden Händen über der Brust halten.":"Lie on the bench, hold one dumbbell with both hands over your chest.","Arme fast gestreckt lassen.":"Keep your arms almost straight.","Hantel in einem Bogen hinter den Kopf absenken, bis die Oberarme neben den Ohren sind.":"Lower the dumbbell in an arc behind your head until your upper arms are next to your ears.","Im gleichen Bogen zurück über die Brust.":"Return along the same arc over your chest.","Langsam und mit Gefühl – große Dehnung.":"Slowly and with feeling – big stretch.","Bauch anspannen, kein starkes Hohlkreuz.":"Brace your abs, no strong arch.","Zu schweres Gewicht.":"Weight too heavy.","Ellbogen beugen und es zu Trizepsdrücken machen.":"Bending the elbows and turning it into a triceps press.","Schrägbankdrücken (Langhantel)":"Incline press (barbell)","Langhantel, Schrägbank":"Barbell, incline bench","Bank auf 30–45° stellen, Stange etwas breiter als schulterbreit greifen.":"Set the bench to 30–45°, grab the bar slightly wider than shoulder width.","Stange aus der Ablage heben, über die obere Brust bringen.":"Lift the bar off the rack and bring it over your upper chest.","Kontrolliert zur oberen Brust absenken.":"Lower it under control to your upper chest.","Mit Partner/Sicherung trainieren.":"Train with a partner/safety.","Füße fest auf dem Boden.":"Feet firmly on the floor.","Bank zu steil.":"Bench too steep.","Stange vom Brustkorb abprallen lassen.":"Bouncing the bar off your rib cage.","Fahrrad-Crunch":"Bicycle crunch","Gerader & schräger Bauchmuskel":"Rectus abdominis & obliques","Hüftbeuger":"Hip flexors","3 × 20 (10 je Seite)":"3 × 20 (10 per side)","Auf den Rücken legen, Hände an die Schläfen, Schultern leicht angehoben.":"Lie on your back, hands on your temples, shoulders slightly raised.","Ein Knie zur Brust ziehen, das andere Bein strecken.":"Pull one knee to your chest and extend the other leg.","Gegenüberliegenden Ellbogen Richtung Knie drehen.":"Rotate the opposite elbow towards the knee.","Seite wechseln wie beim Radfahren.":"Switch sides like riding a bike.","Langsam und kontrolliert – nicht strampeln.":"Slow and controlled – don't pedal wildly.","Unterer Rücken bleibt am Boden.":"Your lower back stays on the floor.","Nur die Ellbogen bewegen statt den Oberkörper zu drehen.":"Only moving the elbows instead of rotating the upper body.","Beinheben liegend":"Lying leg raise","Auf den Rücken legen, Arme neben dem Körper, Handflächen unten.":"Lie on your back, arms next to your body, palms down.","Beine gestreckt zusammen.":"Legs straight and together.","Beine langsam bis ca. 90° anheben.":"Slowly raise your legs to about 90°.","Langsam absenken, kurz vor dem Boden stoppen.":"Lower slowly, stop just above the floor.","Unteren Rücken in den Boden drücken.":"Press your lower back into the floor.","Zu schwer? Knie leicht beugen.":"Too hard? Bend your knees slightly.","Hohlkreuz beim Absenken.":"Arching the back when lowering.","Beine fallen lassen.":"Letting the legs drop.","Reverse Crunch":"Reverse crunch","Auf den Rücken legen, Knie 90° gebeugt anheben.":"Lie on your back, raise your knees bent at 90°.","Hände neben dem Körper am Boden.":"Hands next to your body on the floor.","Becken einrollen und Knie Richtung Brust ziehen, Po hebt leicht ab.":"Curl your pelvis and pull your knees towards your chest, your glutes lift slightly.","Langsam zurückrollen.":"Roll back slowly.","Bewegung kommt aus dem Bauch, nicht aus dem Schwung.":"The movement comes from your abs, not from momentum.","Ausatmen beim Einrollen.":"Breathe out while curling up.","Kopf und Schultern hochziehen.":"Lifting the head and shoulders.","Bauchroller (Ab-Wheel)":"Ab wheel rollout","Gesamter Bauch":"Whole abs","Latissimus, Schultern, unterer Rücken":"Lats, shoulders, lower back","Bauchroller":"Ab wheel","Auf die Knie, Bauchroller mit beiden Händen unter den Schultern.":"On your knees, ab wheel with both hands under your shoulders.","Bauch fest anspannen, Rücken leicht rund.":"Brace your abs hard, back slightly rounded.","Langsam nach vorn rollen, so weit du die Spannung halten kannst.":"Roll forward slowly as far as you can hold the tension.","Mit dem Bauch wieder zurückziehen.":"Pull back using your abs.","Anfangs nur kurze Strecken rollen.":"Roll only short distances at first.","Po nicht nach oben schieben beim Zurückrollen.":"Don't push your glutes up when rolling back.","Hohlkreuz – belastet den unteren Rücken.":"Arched back – strains the lower back.","Zu weit rollen.":"Rolling too far.","Kabel-Holzhacker":"Cable woodchopper","Gerader Bauch, Schultern":"Rectus abdominis, shoulders","Kabelzug (Rolle oben), Griff/Seil":"Cable machine (pulley high), handle/rope","3 × 12 je Seite":"3 × 12 per side","Seitlich zum Kabelzug stellen, Rolle oben, Griff mit beiden Händen.":"Stand sideways to the cable machine, pulley high, handle in both hands.","Füße schulterbreit, Knie leicht gebeugt.":"Feet shoulder-width, knees slightly bent.","Griff diagonal von oben nach unten zur anderen Hüfte ziehen, Oberkörper dreht mit.":"Pull the handle diagonally from top to bottom towards the opposite hip, rotating your upper body.","Kontrolliert zurück und Seite wechseln.":"Return under control and switch sides.","Kraft kommt aus der Rumpfdrehung, Arme bleiben fast gestreckt.":"The power comes from rotating the torso, the arms stay almost straight.","Hintere Ferse darf sich mitdrehen.":"Your back heel may pivot along.","Nur mit den Armen ziehen.":"Pulling only with the arms.","Rundrücken.":"Rounded back.","Arnold Press":"Arnold press","Hanteln vor der Brust halten, Handflächen zeigen zu dir.":"Hold the dumbbells in front of your chest, palms facing you.","Beim Hochdrücken die Hände nach außen drehen.":"Rotate your hands outwards while pressing up.","Oben zeigen die Handflächen nach vorn.":"At the top your palms face forward.","Beim Absenken wieder zurückdrehen.":"Rotate back while lowering.","Große Bewegung – trifft alle Schulterbereiche.":"Big movement – hits all parts of the shoulder.","Sitzend mit Lehne ist es rückenschonender.":"Seated with a backrest is easier on the back.","Hohlkreuz beim Drücken.":"Arched back while pressing.","Seitheben am Kabel":"Cable lateral raise","Kabelzug (Rolle unten), Griffe":"Cable machine (pulley low), handles","Rollen unten, Griffe fassen, aufrecht stehen.":"Pulleys low, grab the handles, stand upright.","Arme seitlich bis Schulterhöhe heben.":"Raise your arms to the sides up to shoulder height.","Langsam absenken – das Kabel hält die Spannung.":"Lower slowly – the cable keeps the tension.","Konstante Spannung über die ganze Bewegung.":"Constant tension throughout the whole movement.","Auch einarmig sehr effektiv.":"Also very effective one-armed.","Schultern hochziehen.":"Shrugging the shoulders.","Mit dem Körper schwingen.":"Swinging with the body.","Frontheben am Kabel":"Cable front raise","Kabelzug (Rolle unten), Griff oder Seil":"Cable machine (pulley low), handle or rope","Mit dem Rücken zum Kabelzug stehen, Griff zwischen den Beinen.":"Stand with your back to the cable machine, handle between your legs.","Arm(e) fast gestreckt.":"Arm(s) almost straight.","Griff nach vorn bis auf Schulterhöhe heben.":"Raise the handle forward to shoulder height.","Langsam zurückführen.":"Lower slowly.","Nicht höher als Schulterhöhe.":"Not higher than shoulder height.","Bauch fest.":"Abs tight.","Schwung aus dem Rücken.":"Momentum from the back.","Arme ganz durchstrecken.":"Fully locking out the arms.","Vorgebeugtes Seitheben (Kurzhantel)":"Bent-over lateral raise (dumbbell)","Oberkörper mit geradem Rücken weit nach vorn beugen.":"Bend your upper body far forward with a straight back.","Hanteln hängen unter der Brust, Arme leicht gebeugt.":"Dumbbells hang under your chest, arms slightly bent.","Arme seitlich nach oben führen, Schulterblätter zusammen.":"Raise your arms out to the sides, shoulder blades together.","Kleines Gewicht – die hintere Schulter ist schwach.":"Light weight – the rear delts are weak.","Kopf in Verlängerung der Wirbelsäule.":"Head in line with your spine.","Aufrichten mit Schwung.":"Straightening up with momentum.","Schulterdrücken stehend (Langhantel)":"Standing overhead press (barbell)","Trizeps, Rumpf":"Triceps, core","Stange auf Schulterhöhe vor dem Körper, schulterbreit greifen.":"Bar at shoulder height in front of your body, grip shoulder-width.","Stange gerade über den Kopf drücken, Kopf leicht zurück.":"Press the bar straight over your head, head slightly back.","Kontrolliert zur Schulter absenken.":"Lower it under control to your shoulders.","Klassische Kraftübung für breite Schultern.":"Classic strength exercise for broad shoulders.","Unterarme senkrecht unter der Stange.":"Forearms vertical under the bar.","Mit den Beinen Schwung holen.":"Using momentum from the legs.","Aufrechtes Rudern am Kabel":"Cable upright row","Seitliche Schulter, Trapez":"Side delts, trapezius","Kabelzug (Rolle unten), Stange/Seil":"Cable machine (pulley low), bar/rope","Rolle unten, Stange oder Seil fassen, aufrecht stehen.":"Pulley low, grab the bar or rope, stand upright.","Griff nah am Körper nach oben ziehen.":"Pull the handle up close to your body.","Ellbogen führen, bis etwa Brusthöhe.":"Lead with the elbows, up to about chest height.","Nicht höher als Brust ziehen – schont die Schulter.":"Don't pull higher than your chest – easier on the shoulders.","Etwas breiter greifen ist angenehmer.":"A slightly wider grip is more comfortable.","Zu hoch ziehen.":"Pulling too high.","Schwung holen.":"Using momentum.","Skull Crusher (French Press)":"Skull crusher (French press)","SZ-Stange oder Langhantel, Flachbank":"EZ bar or barbell, flat bench","Auf die Bank legen, Stange mit gestreckten Armen über der Brust.":"Lie on the bench, bar over your chest with straight arms.","Oberarme bleiben senkrecht und fest.":"Your upper arms stay vertical and fixed.","Nur die Unterarme beugen, Stange Richtung Stirn/hinter den Kopf.":"Bend only your forearms, bar towards your forehead/behind your head.","Langsam ablassen – Stirn schützen!":"Lower slowly – protect your forehead!","Ellbogen gehen weit auseinander.":"Elbows flaring wide apart.","Oberarme bewegen sich mit.":"Upper arms moving along.","Kurzhantel-Kickbacks":"Dumbbell kickbacks","Kurzhantel(n), evtl. Bank":"Dumbbell(s), possibly a bench","3 × 12 je Arm":"3 × 12 per arm","Oberkörper nach vorn beugen, Rücken gerade, evtl. auf Bank abstützen.":"Bend your upper body forward, back straight, possibly supported on a bench.","Oberarm parallel zum Körper fixieren.":"Fix your upper arm parallel to your body.","Unterarm nach hinten strecken, bis der Arm gerade ist.":"Extend your forearm backwards until your arm is straight.","Kurz halten, langsam zurück.":"Hold briefly, return slowly.","Oben den Trizeps fest anspannen.":"Squeeze your triceps hard at the top.","Lieber leichter und sauber.":"Better lighter and clean.","Oberarm schwingt mit.":"Upper arm swinging along.","Trizepsdrücken über Kopf am Seil":"Overhead cable triceps extension (rope)","Kabelzug, Seil":"Cable machine, rope","Rolle unten, Seil fassen, mit dem Rücken zum Kabelzug stellen.":"Pulley low, grab the rope, stand with your back to the cable machine.","Seil hinter den Kopf führen, Ellbogen zeigen nach oben.":"Bring the rope behind your head, elbows pointing up.","Arme über dem Kopf strecken.":"Extend your arms over your head.","Langsam wieder hinter den Kopf.":"Slowly back behind your head.","Großer Dehnreiz für den Trizeps.":"Big stretch stimulus for the triceps.","Ein Fuß vor dem anderen für Stabilität.":"One foot in front of the other for stability.","Ellbogen weit auseinander.":"Elbows wide apart.","Hohlkreuz.":"Arched back.","Trizepsdrücken einarmig am Kabel":"One-arm cable pushdown","Kabelzug (Rolle oben), Einhandgriff":"Cable machine (pulley high), single handle","Rolle oben, Einhandgriff fassen.":"Pulley high, grab the single handle.","Ellbogen eng am Körper.":"Elbow close to your body.","Griff nach unten drücken, bis der Arm gestreckt ist.":"Push the handle down until your arm is straight.","Langsam zurück bis Brusthöhe.":"Slowly back up to chest height.","Gut, um Seitenunterschiede auszugleichen.":"Good for evening out differences between sides.","Auch im Untergriff möglich.":"Also possible with an underhand grip.","Ellbogen wandert nach vorn.":"Elbow drifting forward.","Oberkörper drückt mit.":"Upper body pushing along.","Enges Bankdrücken":"Close-grip bench press","Innere Brust, vordere Schulter":"Inner chest, front delts","Auf die Bank legen, Stange etwa schulterbreit greifen.":"Lie on the bench, grab the bar about shoulder-width.","Ellbogen beim Absenken nah am Körper.":"Keep your elbows close to your body when lowering.","Stange zur unteren Brust absenken.":"Lower the bar to your lower chest.","Kraftvoll hochdrücken.":"Press up powerfully.","Eine der besten Übungen für Trizeps-Masse.":"One of the best exercises for triceps mass.","Nicht zu eng greifen – schont die Handgelenke.":"Don't grip too narrow – easier on the wrists.","Ellbogen weit seitlich.":"Elbows far out to the sides.","Zu enger Griff.":"Grip too narrow.","Scott-Curls (Preacher Curls)":"Preacher curls","Bizeps (unterer Teil)":"Biceps (lower part)","SZ-Stange oder Kurzhantel, Scottbank":"EZ bar or dumbbell, preacher bench","Auf die Scottbank setzen, Oberarme flach auf das Polster.":"Sit on the preacher bench, upper arms flat on the pad.","Stange im Untergriff, Arme fast gestreckt.":"Bar in an underhand grip, arms almost straight.","Stange nach oben beugen.":"Curl the bar up.","Langsam ablassen, nicht ganz durchstrecken.":"Lower slowly, don't lock out fully.","Kein Schwung möglich – sehr gezielt.":"No momentum possible – very targeted.","Unten kontrolliert, das schützt die Sehne.":"Controlled at the bottom, that protects the tendon.","Ellbogen hebt vom Polster ab.":"Elbow lifting off the pad.","Unten fallen lassen.":"Dropping it at the bottom.","Schrägbank-Curls":"Incline dumbbell curls","Bizeps (langer Kopf)":"Biceps (long head)","Kurzhanteln, Schrägbank":"Dumbbells, incline bench","Bank auf ca. 45–60°, zurücklehnen, Arme hängen nach unten.":"Bench at about 45–60°, lean back, arms hanging down.","Handflächen zeigen nach vorn.":"Palms facing forward.","Hanteln nach oben beugen, Oberarme bleiben hinten.":"Curl the dumbbells up, your upper arms stay back.","Langsam ablassen bis zur vollen Dehnung.":"Lower slowly to a full stretch.","Durch die Dehnung sehr effektiv.":"Very effective because of the stretch.","Leichter beginnen als bei normalen Curls.":"Start lighter than with normal curls.","Schultern nach vorn schieben.":"Pushing the shoulders forward.","Halbe Bewegung.":"Half range of motion.","Hammer-Curls am Seil":"Rope hammer curls","Bizeps, Oberarmmuskel":"Biceps, brachialis","Kabelzug (Rolle unten), Seil":"Cable machine (pulley low), rope","Rolle unten, Seil mit neutralem Griff (Daumen oben).":"Pulley low, rope with a neutral grip (thumbs up).","Ellbogen am Körper.":"Elbows at your body.","Seil nach oben beugen, Enden oben leicht auseinander.":"Curl the rope up, ends slightly apart at the top.","Langsam ablassen.":"Lower slowly.","Konstante Spannung durch das Kabel.":"Constant tension thanks to the cable.","Gut für dicke Oberarme.":"Good for thick upper arms.","Ellbogen nach vorn.":"Elbows moving forward.","Oberkörper lehnt zurück.":"Upper body leaning back.","Zottman-Curls":"Zottman curls","Bizeps & Unterarme":"Biceps & forearms","Oberarmmuskel":"Brachialis","Hanteln im Untergriff hochbeugen wie beim Curl.":"Curl the dumbbells up with an underhand grip like a normal curl.","Oben die Hände drehen (Handrücken nach oben).":"Rotate your hands at the top (backs of the hands up).","Im Obergriff langsam absenken.":"Lower slowly with an overhand grip.","Unten zurückdrehen.":"Rotate back at the bottom.","Trainiert Bizeps und Unterarm in einer Übung.":"Trains biceps and forearms in one exercise.","Absenken langsam (3 Sek.).":"Lower slowly (3 sec).","Zu schweres Gewicht beim Absenken.":"Weight too heavy when lowering.","Schwung.":"Momentum.","Handgelenk-Curls":"Wrist curls","Unterarm-Beuger":"Forearm flexors","Griffkraft":"Grip strength","Kurzhantel(n), Bank":"Dumbbell(s), bench","Hinsetzen, Unterarme auf die Oberschenkel, Handgelenke über die Knie.":"Sit down, forearms on your thighs, wrists over your knees.","Hantel im Untergriff (Handfläche oben).":"Dumbbell in an underhand grip (palm up).","Nur das Handgelenk nach oben beugen.":"Bend only your wrist upwards.","Langsam absenken, Hantel darf in die Finger rollen.":"Lower slowly, the dumbbell may roll into your fingers.","Hohe Wiederholungen, leichtes Gewicht.":"High reps, light weight.","Stärkt Griff und Handgelenke.":"Strengthens grip and wrists.","Unterarme heben vom Oberschenkel ab.":"Forearms lifting off the thighs.","Zu schwer – das belastet die Sehnen.":"Too heavy – that strains the tendons.","Reverse Handgelenk-Curls":"Reverse wrist curls","Unterarm-Strecker":"Forearm extensors","Handgelenk-Stabilität":"Wrist stability","Wie Handgelenk-Curls, aber Hantel im Obergriff (Handrücken oben).":"Like wrist curls, but with the dumbbell in an overhand grip (back of the hand up).","Unterarme auf den Oberschenkeln.":"Forearms on your thighs.","Handrücken nach oben ziehen.":"Pull the back of your hand up.","Sehr leichtes Gewicht nehmen.":"Use a very light weight.","Gut gegen Ellbogen-/Handgelenksschmerzen durch Ausgleich.":"Good for balancing things out against elbow/wrist pain.","Zu schwer.":"Too heavy.","Reverse Curls (Obergriff)":"Reverse curls (overhand grip)","Unterarme, Oberarmspeichenmuskel":"Forearms, brachioradialis","SZ-Stange oder Langhantel":"EZ bar or barbell","Stange im Obergriff schulterbreit halten.":"Hold the bar shoulder-width with an overhand grip.","Stange nach oben beugen, Handrücken bleiben oben.":"Curl the bar up, the backs of your hands stay on top.","Weniger Gewicht als bei normalen Curls.":"Less weight than with normal curls.","Handgelenke knicken ab.":"Wrists bending.","Farmer’s Walk (Hanteln tragen)":"Farmer's walk (carrying dumbbells)","Griffkraft, Unterarme":"Grip strength, forearms","Trapez, Rumpf, Beine":"Trapezius, core, legs","Schwere Kurzhanteln":"Heavy dumbbells","Zwei schwere Hanteln greifen, aufrecht hinstellen.":"Grab two heavy dumbbells and stand upright.","Schultern unten und hinten, Bauch fest.":"Shoulders down and back, abs tight.","Mit kurzen, schnellen Schritten gehen.":"Walk with short, quick steps.","Am Ziel kontrolliert absetzen.":"Set them down under control at the finish.","Einfach, aber extrem effektiv für den Griff.":"Simple but extremely effective for your grip.","Blick nach vorn.":"Look ahead.","Schultern hängen nach vorn.":"Shoulders slumping forward.","Hanteln pendeln lassen.":"Letting the dumbbells swing.","Handgelenk-Roller":"Wrist roller","Unterarm-Beuger & -Strecker":"Forearm flexors & extensors","Vordere Schulter (halten)":"Front delts (holding)","Handgelenk-Roller (Stab mit Seil und Gewicht)":"Wrist roller (bar with rope and weight)","3 × 2–3 Durchgänge":"3 × 2–3 rounds","Roller mit gestreckten Armen vor dem Körper halten.":"Hold the roller in front of your body with straight arms.","Durch Drehen der Handgelenke das Seil aufwickeln.":"Wind up the rope by turning your wrists.","Gewicht ganz nach oben drehen.":"Roll the weight all the way up.","Langsam wieder abwickeln.":"Slowly unwind it again.","Brennt stark – Pausen sind normal.":"Burns a lot – breaks are normal.","Auch rückwärts drehen für die Strecker.":"Also roll backwards for the extensors.","Arme sinken ab.":"Arms sinking.","Hängen an der Stange (Dead Hang)":"Dead hang","Latissimus, Schultern":"Lats, shoulders","3 × 20–45 Sek.":"3 × 20–45 sec","Stange schulterbreit im Obergriff greifen.":"Grab the bar shoulder-width with an overhand grip.","Arme gestreckt, ruhig hängen.":"Arms straight, hang calmly.","Schultern leicht nach unten ziehen.":"Pull your shoulders slightly down.","Zeit halten, dann kontrolliert loslassen.":"Hold for the time, then let go under control.","Super für Griff und Schulter-Beweglichkeit.":"Great for grip and shoulder mobility.","Gute Vorbereitung für Klimmzüge.":"Good preparation for pull-ups.","Schwingen.":"Swinging.","Nur mit den Fingerspitzen halten.":"Holding only with your fingertips.","Butterfly an der Maschine":"Pec deck machine","Große Brustmuskeln (innen)":"Pectoralis major (inner)","Butterfly-Maschine":"Pec deck machine","Sitz so einstellen, dass die Griffe/Polster auf Brusthöhe sind.":"Adjust the seat so the handles/pads are at chest height.","Rücken fest an die Lehne, Unterarme an die Polster oder Griffe fassen.":"Back firmly against the backrest, forearms against the pads or grab the handles.","Arme in einem Bogen vor der Brust zusammenführen.":"Bring your arms together in an arc in front of your chest.","Kurz anspannen, langsam zurück bis zur leichten Dehnung.":"Squeeze briefly, return slowly to a light stretch.","Einsteiger: mit einer niedrigen Gewichtsstufe (1–3) beginnen und erst steigern, wenn 15 saubere Wiederholungen gehen.":"Beginners: start with a low weight setting (1–3) and only increase once you can do 15 clean reps.","Sehr gelenkschonend – ideal statt Kurzhantel-Fliegende.":"Very easy on the joints – ideal instead of dumbbell flyes.","Zu weit nach hinten öffnen.":"Opening too far back.","Schultern nach vorn rollen.":"Rolling the shoulders forward.","Schräg-Brustpresse (Maschine)":"Incline chest press (machine)","Schrägbank-Brustpresse":"Incline chest press machine","Sitz so einstellen, dass die Griffe auf Höhe der oberen Brust sind.":"Adjust the seat so the handles are at upper chest height.","Rücken und Kopf an das Polster.":"Back and head against the pad.","Griffe schräg nach oben drücken, Arme fast strecken.":"Press the handles diagonally up, arms almost straight.","Langsam zurück, bis die Brust leicht gedehnt ist.":"Slowly return until your chest is slightly stretched.","Geführte Bewegung – sicher ohne Partner.":"Guided movement – safe without a partner.","Rücken vom Polster lösen.":"Lifting the back off the pad.","Ellbogen ganz durchdrücken.":"Fully locking out the elbows.","Dips an der Maschine (unterstützt)":"Assisted dip machine","Trizeps, untere Brust":"Triceps, lower chest","Dip-/Klimmzug-Maschine mit Kniepolster":"Dip/pull-up machine with knee pad","Gegengewicht einstellen – mehr Gewicht = mehr Hilfe.":"Set the counterweight – more weight = more assistance.","Knie auf das Polster, Griffe fassen, Arme gestreckt.":"Knees on the pad, grab the handles, arms straight.","Langsam absenken, bis die Oberarme etwa waagerecht sind.":"Lower slowly until your upper arms are about horizontal.","Viel Unterstützung zu Beginn ist völlig okay – nach und nach reduzieren.":"Lots of assistance at the start is totally fine – reduce it bit by bit.","Oberkörper aufrecht = mehr Trizeps.":"Upper body upright = more triceps.","Latzug eng (V-Griff)":"Close-grip lat pulldown (V-handle)","Latzugmaschine, V-Griff":"Lat pulldown machine, V-handle","V-Griff einhängen, Oberschenkel unter das Polster.":"Attach the V-handle, thighs under the pad.","Leicht zurücklehnen, Brust raus.":"Lean back slightly, chest up.","Griff zur oberen Brust ziehen, Ellbogen eng nach unten.":"Pull the handle to your upper chest, elbows close and down.","Langsam nach oben, bis die Arme gestreckt sind.":"Slowly back up until your arms are straight.","Gut für einen dicken, starken Rücken.":"Good for a thick, strong back.","Mit dem Oberkörper weit nach hinten reißen.":"Yanking the upper body far back.","Latzug im Untergriff":"Underhand lat pulldown","Latzugmaschine, gerade Stange":"Lat pulldown machine, straight bar","Stange schulterbreit im Untergriff (Handflächen zu dir).":"Bar shoulder-width with an underhand grip (palms facing you).","Oberschenkel fixieren, leicht zurücklehnen.":"Fix your thighs, lean back slightly.","Stange zur Brust ziehen.":"Pull the bar to your chest.","Kontrolliert nach oben.":"Back up under control.","Leichter als der breite Latzug – guter Einstieg für Klimmzüge.":"Easier than the wide pulldown – a good start towards pull-ups.","Mit Schwung ziehen.":"Pulling with momentum.","Rudermaschine (Brust gestützt)":"Chest-supported row machine","Hintere Schulter, Bizeps":"Rear delts, biceps","Rudermaschine mit Brustpolster":"Row machine with chest pad","Sitz so einstellen, dass die Griffe auf Brusthöhe sind.":"Adjust the seat so the handles are at chest height.","Brust fest ans Polster.":"Chest firmly against the pad.","Griffe nach hinten ziehen, Schulterblätter zusammen.":"Pull the handles back, shoulder blades together.","Langsam nach vorn, bis die Arme gestreckt sind.":"Slowly forward until your arms are straight.","Das Brustpolster schont den unteren Rücken – ideal für Einsteiger.":"The chest pad protects the lower back – ideal for beginners.","Brust vom Polster lösen.":"Lifting the chest off the pad.","Klimmzüge an der Maschine (unterstützt)":"Assisted pull-up machine","Klimmzug-Maschine mit Gegengewicht":"Pull-up machine with counterweight","Gegengewicht wählen – mehr Gewicht = mehr Hilfe.":"Choose the counterweight – more weight = more assistance.","Knie auf das Polster, Griffe weit fassen.":"Knees on the pad, grab the handles wide.","Hochziehen, bis das Kinn über den Griffen ist.":"Pull up until your chin is above the handles.","Perfekter Weg zum ersten echten Klimmzug.":"The perfect path to your first real pull-up.","Jede Woche etwas weniger Unterstützung.":"A little less assistance every week.","Rückenstrecker-Maschine":"Back extension machine","Po, Beinbeuger":"Glutes, hamstrings","Sitz einstellen, Polster liegt am oberen Rücken.":"Adjust the seat, the pad rests on your upper back.","Füße fest, Arme vor der Brust verschränkt.":"Feet firm, arms crossed in front of your chest.","Oberkörper langsam nach hinten strecken.":"Slowly extend your upper body backwards.","Kontrolliert nach vorn zurück.":"Return forward under control.","Stärkt den unteren Rücken – gut gegen Rückenschmerzen.":"Strengthens the lower back – good against back pain.","Ruckartig nach hinten werfen.":"Throwing yourself back jerkily.","Zu weit überstrecken.":"Overextending too far.","Hyperextension (Rückenstrecken)":"Hyperextension (back extension)","45°-Hyperextension-Bank":"45° hyperextension bench","Polster knapp unter dem Hüftknochen einstellen, Füße fixieren.":"Set the pad just below your hip bones, fix your feet.","Arme vor der Brust verschränken.":"Cross your arms in front of your chest.","Oberkörper mit geradem Rücken absenken.":"Lower your upper body with a straight back.","Bis zur geraden Linie aufrichten – nicht überstrecken.":"Come up to a straight line – don't overextend.","Langsam und kontrolliert.":"Slow and controlled.","Für mehr Po: Rücken leicht rund, Po fest anspannen.":"For more glutes: back slightly rounded, squeeze your glutes.","Hohlkreuz oben.":"Arched back at the top.","Seitheben an der Maschine":"Lateral raise machine","Seitheben-Maschine":"Lateral raise machine","Sitz so einstellen, dass die Schultern auf Höhe des Drehpunkts sind.":"Adjust the seat so your shoulders are level with the pivot point.","Arme an die Polster legen.":"Place your arms against the pads.","Geführt – perfekt für schöne, runde Schultern.":"Guided – perfect for nice, round shoulders.","Schulterdrücken an der Smith-Maschine":"Smith machine shoulder press","Smith-Maschine, Bank mit Lehne":"Smith machine, bench with backrest","Bank unter die Stange stellen, Lehne fast senkrecht.":"Place the bench under the bar, backrest almost vertical.","Stange etwas breiter als schulterbreit greifen und aushaken.":"Grab the bar slightly wider than shoulder width and unhook it.","Stange vom Kinn nach oben drücken.":"Press the bar up from your chin.","Langsam bis Kinnhöhe absenken, Haken drehen zum Ablegen.":"Lower slowly to chin height, rotate the hooks to rack it.","Die Führung sorgt für Sicherheit ohne Partner.":"The guide rails keep you safe without a partner.","Stange in den Nacken absenken.":"Lowering the bar behind your neck.","Abduktoren-Maschine (Beine auseinander)":"Hip abductor machine (legs apart)","Seitlicher Po (Gluteus medius)":"Side glutes (gluteus medius)","Hüfte":"Hips","Abduktoren-Maschine":"Abductor machine","Hinsetzen, Polster außen an den Knien.":"Sit down, pads on the outside of your knees.","Rücken an die Lehne, Griffe fassen.":"Back against the backrest, grab the handles.","Beine kontrolliert nach außen drücken.":"Push your legs outwards under control.","Langsam zurück, Gewicht nicht absetzen.":"Return slowly without setting the weight down.","Für einen runden, straffen Po – ein Klassiker im Frauentraining.":"For round, firm glutes – a classic in women's training.","Gewichte zurückfallen lassen.":"Letting the weights drop back.","Adduktoren-Maschine (Beine zusammen)":"Hip adductor machine (legs together)","Innenschenkel (Adduktoren)":"Inner thighs (adductors)","Adduktoren-Maschine":"Adductor machine","Hinsetzen, Polster innen an den Knien.":"Sit down, pads on the inside of your knees.","Startweite so wählen, dass es angenehm dehnt.":"Choose a starting width that stretches comfortably.","Beine kontrolliert zusammendrücken.":"Squeeze your legs together under control.","Langsam öffnen.":"Open slowly.","Strafft die Innenseite der Oberschenkel.":"Tones the inner thighs.","Zu weite Startposition.":"Starting position too wide.","Po-Kickback am Kabel":"Cable glute kickback","Großer Po-Muskel":"Gluteus maximus","Kabelzug (Rolle unten), Fußschlaufe":"Cable machine (pulley low), ankle strap","3 × 12–15 je Bein":"3 × 12–15 per leg","Fußschlaufe am Knöchel, mit Blick zum Kabelzug stellen.":"Ankle strap on your ankle, stand facing the cable machine.","Oberkörper leicht nach vorn, am Gerät festhalten.":"Upper body slightly forward, hold on to the machine.","Bein gestreckt nach hinten-oben drücken, Po fest anspannen.":"Push your straight leg back and up, squeeze your glutes.","Langsam zurück, Seite wechseln.":"Return slowly, switch sides.","Oben 1 Sekunde halten – da arbeitet der Po am meisten.":"Hold for 1 second at the top – that's where the glutes work the most.","Ins Hohlkreuz gehen.":"Arching the back.","Mit Schwung kicken.":"Kicking with momentum.","Beinbeuger liegend":"Lying leg curl","Hintere Oberschenkel":"Hamstrings","Waden, Po":"Calves, glutes","Beinbeuger-Maschine (liegend)":"Leg curl machine (lying)","Bäuchlings auf die Maschine legen, Polster über den Fersen.":"Lie face down on the machine, pad over your heels.","Griffe vorne festhalten, Hüfte bleibt auf dem Polster.":"Hold the handles in front, your hips stay on the pad.","Fersen Richtung Po ziehen.":"Pull your heels towards your glutes.","Hüfte unten lassen – dann arbeiten die Beinbeuger richtig.":"Keep your hips down – then the hamstrings really work.","Gewicht fallen lassen.":"Dropping the weight.","Kennwort":"Password","Profil":"Profile","Übung suchen, z. B. Bankdrücken":"Search exercise, e.g. bench press","Dein Name":"Your name","Übung suchen":"Search exercise","Muskel-Coach – Übungen mit Vorführung":"Muskel-Coach – exercises with demos","Diese App ist geschützt.":"This app is protected.","Bitte Zugangs-Kennwort eingeben.":"Please enter the access password.","Öffnen":"Open","Start":"Home","Schnellzugriff":"Quick access","Training starten":"Start workout","Heutigen Plan öffnen":"Open today's plan","Übungen":"Exercises","Alle mit Vorführung":"All with demos","Fortschritt":"Progress","Statistik, Körper, Abzeichen":"Stats, body, badges","Mein Bedarf":"My needs","Kalorien, Eiweiß, Kreatin":"Calories, protein, creatine","🏆 Meine Rekorde":"🏆 My records","Teilen":"Share","📲 Muskel-Coach teilen":"📲 Share Muskel-Coach","Schick die App an Freunde oder Familie – sie öffnen den Link einfach im Browser.":"Send the app to friends or family – they simply open the link in their browser.","🔗 Link kopieren":"🔗 Copy link","Hinweis: Die Anleitungen ersetzen keine Trainer- oder Arztberatung. Wärm dich vorher auf, beginne mit leichtem Gewicht und hör bei Schmerzen sofort auf.":"Note: These instructions do not replace advice from a trainer or doctor. Warm up first, start with a light weight and stop immediately if you feel pain.","Übungen nach Muskelgruppe":"Exercises by muscle group","Profil & Tagesbedarf":"Profile & daily needs","Geschlecht":"Sex","Mann":"Male","Frau":"Female","Alter (Jahre)":"Age (years)","Größe (cm)":"Height (cm)","Gewicht (kg)":"Weight (kg)","Arbeit":"Work","Sitzend (Büro, Fahrer)":"Seated (office, driver)","Stehend / viel unterwegs":"Standing / on the move a lot","Körperlich schwer (Bau, Lager)":"Physically demanding (construction, warehouse)","Keine Arbeit / Rente":"No work / retired","Schritte pro Tag (Durchschnitt, inkl. Arbeit)":"Steps per day (average, incl. work)","Schritte":"Steps","Tipp: Den Wert zeigt dir dein Handy (iPhone: Health-App, Android: Google Fit / Samsung Health) – nimm den Wochendurchschnitt.":"Tip: Your phone shows this value (iPhone: Health app, Android: Google Fit / Samsung Health) – use the weekly average.","Ziel":"Goal","Muskelaufbau":"Build muscle","Halten":"Maintain","Definieren":"Cut","Abnehmen":"Lose weight","Tempo":"Speed","0,25 kg":"0.25 kg","0,5 kg":"0.5 kg","0,75 kg":"0.75 kg","pro Woche · 0,5 kg ist ideal, um Muskeln zu erhalten":"per week · 0.5 kg is ideal to keep your muscle","Zielgewicht (kg, optional)":"Target weight (kg, optional)","Speichern":"Save","So wird gerechnet: Grundumsatz nach Mifflin-St Jeor (Alter, Größe, Gewicht, Geschlecht). Gesamtumsatz = Grundumsatz × 1,2 für den Alltag + deine Schritte (Schrittlänge ≈ 41,5 % der Körpergröße, Gehen ≈ 0,55 kcal pro kg und km) + Arbeit + dein Krafttraining laut Plan. Für Muskelaufbau kommen +300 kcal dazu, zum Definieren werden 400 kcal abgezogen, beim Abnehmen das gewählte Defizit (1 kg Fett ≈ 7.700 kcal). Eiweiß: 2,0 g pro kg beim Aufbau (empfohlen 1,6–2,2 g). Kreatin: 1 g pro 10 kg Körpergewicht (übliche Standardmenge sind 3–5 g). Schritte und Training sind im Gesamtumsatz schon enthalten – die Kalorien aus dem Kalorien-Rechner also nicht zusätzlich essen. Das sind Richtwerte, keine ärztliche oder Ernährungsberatung. Bei Nieren- oder anderen Erkrankungen vorher mit dem Arzt sprechen.":"How it's calculated: basal metabolic rate (BMR) using Mifflin-St Jeor (age, height, weight, sex). Total expenditure = BMR × 1.2 for daily life + your steps (stride ≈ 41.5 % of body height, walking ≈ 0.55 kcal per kg and km) + work + your strength training according to your plan. For building muscle +300 kcal are added, for cutting 400 kcal are subtracted, for weight loss the chosen deficit (1 kg of fat ≈ 7,700 kcal). Protein: 2.0 g per kg when building (recommended 1.6–2.2 g). Creatine: 1 g per 10 kg of body weight (the usual standard amount is 3–5 g). Steps and training are already included in the total – so don't eat the calories from the calorie calculator on top. These are guidelines, not medical or nutritional advice. If you have kidney or other conditions, talk to your doctor first.","Entwickler © by":"Developer © by","Kalender":"Calendar","← Zurück":"← Back","☆ Merken":"☆ Save","‹ Minimieren":"‹ Minimize","🏋️ Training":"🏋️ Workout","Pause":"Rest","Weiter ›":"Next ›","🏋️ Training läuft · fortsetzen ›":"🏋️ Workout running · continue ›","← Fertig":"← Done","Alle 75 Übungen":"All 75 exercises","statt 28 – inkl. Unterarme, Kabel- & Freihantel-Übungen":"instead of 28 – incl. forearms, cable & free-weight exercises","3D-Bodybuilder":"3D bodybuilder","drehbar, Muskeln leuchten, 14 Looks – Männer, Frauen & Anatomie":"rotatable, muscles light up, 14 looks – men, women & anatomy","Rekord-Speicher":"Record tracker","merkt sich dein schwerstes Gewicht & feiert jeden neuen Rekord":"remembers your heaviest weight & celebrates every new record","Statistik, Körper & Maße, Fortschrittsfotos, 21 Abzeichen":"Stats, body & measurements, progress photos, 21 badges","Grenztest & Profi-Helfer":"Max test & pro tools","Maximalkraft testen, Scheiben-Rechner, Aufwärmsätze im Training":"Test your max strength, plate calculator, warm-up sets during workouts","Diese Funktion gehört zur":"This feature is part of the","Vollversion":"full version","– einmalig nur":"– one-time payment of only",", danach für immer frei.":", then free forever.","Vollversion holen":"Get the full version","Zügig gehen · ca. 4 km/h":"Brisk walk · approx. 4 km/h","Aufwärmen":"Warm-up","Schultern":"Shoulders","Nacken":"Neck","Bauch":"Abs","Rücken":"Back","Beine":"Legs","Po":"Glutes","💪 Muskel-Coach – Trainings-App mit 3D-Übungen, Trainingsplan, Kalender und Kalorienrechner. 10 Tage kostenlos testen:":"💪 Muskel-Coach – workout app with 3D exercises, training plan, calendar and calorie calculator. Try it free for 10 days:","Kopiert ✓ – jetzt in WhatsApp einfügen":"Copied ✓ – now paste it into WhatsApp","Maschinen":"Machines","Alle":"All","Gemerkt":"Saved","Alle Übungen":"All exercises","Gemerkte Übungen":"Saved exercises","🔒 Vollversion":"🔒 Full version","NEU":"NEW","Noch nichts gemerkt – öffne eine Übung und tippe auf „☆ Merken“.":"Nothing saved yet – open an exercise and tap “☆ Save”.","Keine Übung gefunden.":"No exercise found.","richtige Ausführung":"correct form","Minuten":"Minutes","Sekunden":"Seconds","Wiederholungen":"Reps","Sätze":"Sets","Ø letzte 5 Trainings":"Ø last 5 workouts","Ø Gewicht":"Ø weight","Ø Wiederholungen":"Ø reps","Ø Volumen / Training":"Ø volume / workout","🏋️ Schau dir diese Übung an:":"🏋️ Check out this exercise:","Zeitlupe":"Slow motion","Sätze × Wdh.":"Sets × reps","Geräte":"Equipment","🔥 Kalorien-Rechner":"🔥 Calorie calculator","📈 Dein Fortschritt":"📈 Your progress","Trainierte Muskeln":"Muscles worked","So geht's":"How to do it","Tipps":"Tips","Häufige Fehler":"Common mistakes","Echtes Video ansehen":"Watch a real video","öffnet YouTube-Videos zu dieser Übung":"opens YouTube videos for this exercise","🔗 Übung teilen":"🔗 Share exercise","– Muskel-Coach":"– Muskel-Coach","Schau dir diese Übung an:":"Check out this exercise:","Link kopiert ✓":"Link copied ✓","Profil unter „Mein Bedarf“ anlegen":"Create your profile under “My needs”","für genaue Werte.":"for accurate values.","Mehrere Sätze verschieden? z. B.":"Different sets? e.g.","▶ Abspielen":"▶ Play","Ausatmen – Kraftphase":"Breathe out – power phase","Kurz halten":"Hold briefly","Einatmen – kontrolliert zurück":"Breathe in – controlled return","Startposition":"Starting position","Spannung halten, ruhig atmen":"Keep tension, breathe calmly","★ Gemerkt":"★ Saved","5–7 Min · 4 km/h":"5–7 min · 4 km/h","Tag 1 – Rücken, Schultern, Bizeps":"Day 1 – Back, shoulders, biceps","Tag 2 – Brust, Trizeps, Nacken, Bauch":"Day 2 – Chest, triceps, neck, abs","Tag 3 – Beine & Bauch":"Day 3 – Legs & abs","10 pro Bein":"10 per leg","Tag 1 – Ganzkörper A":"Day 1 – Full body A","Tag 2 – Ganzkörper B":"Day 2 – Full body B","Tag 3 – Ganzkörper C":"Day 3 – Full body C","3er-Split":"3-day split","3 Tage · z. B. Mo / Mi / Fr":"3 days · e.g. Mon / Wed / Fri","Tag 1 Rücken, Schultern, Bizeps – Tag 2 Brust, Trizeps, Nacken, Bauch – Tag 3 Beine & Bauch. Jede Muskelgruppe bekommt viele Sätze und eine Woche Erholung.":"Day 1 back, shoulders, biceps – Day 2 chest, triceps, neck, abs – Day 3 legs & abs. Every muscle group gets lots of sets and a week to recover.","2er-Split Ober/Unter":"2-day split upper/lower","4 Tage · z. B. Mo / Di / Do / Fr":"4 days · e.g. Mon / Tue / Thu / Fri","Oberkörper und Beine im Wechsel (A/B). Jeder Muskel wird 2× pro Woche trainiert – sehr effektiv für Muskelaufbau.":"Upper body and legs alternating (A/B). Every muscle is trained 2× per week – very effective for building muscle.","Tag 1 – Oberkörper A":"Day 1 – Upper body A","Tag 2 – Unterkörper A":"Day 2 – Lower body A","Tag 3 – Oberkörper B":"Day 3 – Upper body B","Tag 4 – Unterkörper B":"Day 4 – Lower body B","4er-Split":"4-day split","Brust & Trizeps – Rücken & Bizeps – Beine – Schultern, Nacken & Bauch. Mehr Volumen pro Muskelgruppe, ideal ab ca. 6 Monaten Training.":"Chest & triceps – back & biceps – legs – shoulders, neck & abs. More volume per muscle group, ideal after about 6 months of training.","Tag 1 – Brust & Trizeps":"Day 1 – Chest & triceps","Tag 2 – Rücken & Bizeps":"Day 2 – Back & biceps","Tag 3 – Beine":"Day 3 – Legs","Tag 4 – Schultern, Nacken & Bauch":"Day 4 – Shoulders, neck & abs","5er-Split":"5-day split","5 Tage · Mo – Fr":"5 days · Mon – Fri","Jeden Tag eine Muskelgruppe: Brust – Rücken – Beine – Schultern & Nacken – Arme & Bauch. Für Fortgeschrittene mit viel Zeit.":"One muscle group per day: chest – back – legs – shoulders & neck – arms & abs. For advanced lifters with plenty of time.","Tag 1 – Brust":"Day 1 – Chest","Tag 2 – Rücken":"Day 2 – Back","Tag 3 – Beine & Po":"Day 3 – Legs & glutes","Tag 4 – Schultern & Nacken":"Day 4 – Shoulders & neck","Tag 5 – Arme & Bauch":"Day 5 – Arms & abs","Push / Pull / Beine":"Push / Pull / Legs","3 oder 6 Tage · 1× oder 2× durchlaufen":"3 or 6 days · run through 1× or 2×","Push = Drücken (Brust, Schultern, Trizeps), Pull = Ziehen (Rücken, Bizeps, Nacken), dann Beine. Bei 6 Tagen einfach 2× pro Woche durchlaufen.":"Push = pressing (chest, shoulders, triceps), Pull = pulling (back, biceps, neck), then legs. With 6 days simply run through it twice a week.","Tag 1 – Push":"Day 1 – Push","Tag 2 – Pull":"Day 2 – Pull","Ganzkörper 3×":"Full body 3×","Jeder Muskel 3× pro Woche mit wenigen Sätzen – ideal für Einsteiger und wenig Zeit.":"Every muscle 3× per week with few sets – ideal for beginners and little time.","Trainingsplan":"Training plan","Profil & Einstellungen":"Profile & settings","Fortschritt: Statistik, Körper & Abzeichen":"Progress: stats, body & badges","Eigener Plan":"Custom plan","Jeder Tag startet mit":"Every day starts with","5–7 Min. zügigem Gehen":"5–7 min of brisk walking","auf dem Laufband (4 km/h).":"on the treadmill (4 km/h).","Klimmzüge 10 / 7 / 5:":"Pull-ups 10 / 7 / 5:","Schaffst du in Satz 2 und 3 mehr, steigere die Zahlen. Bei 3 × 10 mit Zusatzgewicht trainieren.":"If you manage more in sets 2 and 3, increase the numbers. At 3 × 10, train with extra weight.","Tag":"Day","▶ Testlauf fortsetzen":"▶ Continue test run","▶ Laufendes Training fortsetzen":"▶ Continue current workout","▶ Training starten":"▶ Start workout","👀 Testlauf – Übungen nur ansehen":"👀 Test run – just look at the exercises","(wird nicht gespeichert)":"(not saved)","🏆 Rekord":"🏆 Record","am Stück":"in a row","Sätze ×":"sets ×","Wdh. ·":"reps ·","🔗 Supersatz mit der nächsten Übung – ohne Pause hintereinander (antippen zum Lösen)":"🔗 Superset with the next exercise – back to back without rest (tap to unlink)","＋ 🔗 Als Supersatz mit nächster Übung verbinden":"＋ 🔗 Link as superset with next exercise","Noch keine Übungen an diesem Tag.":"No exercises on this day yet.","✅ Heute erledigt – zum Kalender":"✅ Done today – go to calendar","✅ Training heute erledigt":"✅ Workout done today","Sicher? Nochmal tippen":"Sure? Tap again","🗑 Tag":"🗑 Day","⚠️ Nochmal tippen zum Laden":"⚠️ Tap again to load","⚠️ Nochmal tippen zum Leeren":"⚠️ Tap again to clear","Gleiche Anzahl Tage, alle Übungen entfernt. Mit ＋ weitere Tage anlegen.":"Same number of days, all exercises removed. Add more days with ＋.","💡 So holst du mit dem Plan das Maximum raus":"💡 How to get the most out of your plan","Jede Muskelgruppe braucht":"Every muscle group needs","48–72 Std. Pause":"48–72 hours of rest",", bevor sie wieder dran ist.":"before it's trained again.","Letzter Satz 1–2 Wiederholungen vor dem Muskelversagen":"Last set 1–2 reps short of failure","– nur dann wächst der Muskel.":"– that's the only way the muscle grows.","Steigerung:":"Progression:","Schaffst du in allen Sätzen die obere Wiederholungszahl, nimm nächstes Mal mehr Gewicht (+2,5 kg bzw. eine Stufe an der Maschine). Trag dein Gewicht unten bei „kg“ ein.":"If you hit the top rep number in all sets, use more weight next time (+2.5 kg or one step on the machine). Enter your weight below under “kg”.","Pausen:":"Rest:","2–3 Min. bei Bankdrücken, Beinpresse & Co., 60–90 Sek. bei kleinen Übungen.":"2–3 min for bench press, leg press & co., 60–90 sec for small exercises.","Bei der ersten schweren Übung 1–2 leichte Aufwärmsätze machen.":"Do 1–2 light warm-up sets before the first heavy exercise.","Aktueller Plan:":"Current plan:","＋ Übung hinzufügen":"＋ Add exercise","Split-Vorlagen":"Split templates","Antippen und bestätigen – ersetzt deinen aktuellen Plan.":"Tap and confirm – replaces your current plan.","🧩 Eigener Plan":"🧩 Custom plan","Leer – frei zusammenstellen":"Empty – build it yourself","🔥 ca.":"🔥 approx.","🔗 Supersatz: beide Übungen direkt hintereinander, Pause erst danach":"🔗 Superset: both exercises back to back, rest only afterwards","Zum Plan:":"To the plan:","Hinzufügen zu Tag":"Add to day","Mo":"Mon","Di":"Tue","Mi":"Wed","Do":"Thu","Fr":"Fri","Sa":"Sat","So":"Sun","Januar":"January","Februar":"February","März":"March","Mai":"May","Juni":"June","Juli":"July","Oktober":"October","Dezember":"December","🏋️ Training läuft:":"🏋️ Workout running:","✅ Heute erledigt:":"✅ Done today:","📅 Heute dran:":"📅 Due today:","😴 Ruhetag · nächstes Training":"😴 Rest day · next workout","✅ Erledigt!":"✅ Done!","Nächstes Training:":"Next workout:","✓ Erledigt":"✓ Done","😴 Ruhetag":"😴 Rest day","Muskeln wachsen in der Pause.":"Muscles grow during rest.","Trotzdem trainiert? Eintragen":"Trained anyway? Log it","weiter, es fällt nichts weg.":"continues, nothing gets lost.","noch nicht":"not yet","(heute)":"(today)","Löschen":"Delete","Geplant, aber nicht eingetragen":"Planned, but not logged","Kein Training geplant":"No workout planned","＋ Eintragen":"＋ Log","Automatisch passend zu deinem Split gewählt.":"Chosen automatically to match your split.","Von dir angepasst.":"Adjusted by you.","↺ Automatisch passend zum Split":"↺ Automatically match the split","Tagen":"days","Noch kein Training eingetragen. Tippe nach dem Training auf „✓ Erledigt“.":"No workout logged yet. Tap “✓ Done” after your workout.","diese Woche":"this week","Wochen-Serie":"week streak","kcal diese Woche":"kcal this week","T1 = Tag 1 deines Plans":"D1 = day 1 of your plan","Trainingstage pro Woche":"Training days per week","Muskel-Erholung":"Muscle recovery","🟠 unter 48 Std. – erholt sich · 🟡 fast bereit · 🟢 bereit für das nächste Training":"🟠 under 48 h – recovering · 🟡 almost ready · 🟢 ready for the next workout","Zuletzt trainiert":"Last trained","Sek.":"sec","Wdh.":"reps","🔥 Grenztest":"🔥 Max test","🔒 Teste deine Maximalkraft und sieh, wie viel stärker du wirst – in der Vollversion.":"🔒 Test your max strength and see how much stronger you get – in the full version.","🏆 Geschätzte Maximalkraft:":"🏆 Estimated max strength:","🏆 Bestwert:":"🏆 Best:","Kraft · 3–4 Wdh.":"Strength · 3–4 reps","Aufbau · 8 Wdh.":"Hypertrophy · 8 reps","Aufbau · 12 Wdh.":"Hypertrophy · 12 reps","Ausdauer · 15+":"Endurance · 15+","🔥 Grenztest (Maximalkraft)":"🔥 Max test (max strength)","Gut aufwärmen, dann ein Gewicht wählen, das du ca. 3–10× schaffst, und so viele":"Warm up well, then choose a weight you can do about 3–10×, and do as many","Wiederholungen wie möglich machen. Bei schweren Übungen mit Partner/Sicherung!":"reps as possible. With heavy exercises use a partner/safety!","Max. Wdh.":"Max reps","Test speichern":"Save test","Bitte die geschafften Wiederholungen eintragen":"Please enter the reps you completed","Neue Maximalkraft! 🔥":"New max strength! 🔥","Grenztest gespeichert ✓":"Max test saved ✓","Antippen zum Schließen":"Tap to close","⏰ Pause vorbei – nächster Satz!":"⏰ Rest over – next set!","Testlauf":"Test run","– schau dir alles in Ruhe an, es wird nichts gespeichert.":"– take your time to look at everything, nothing is saved.","🔗 Supersatz A":"🔗 Superset A","🔗 Supersatz B":"🔗 Superset B","🏆 Dein Rekord:":"🏆 Your record:","– schaffst du mehr?":"– can you do more?","⬆️ Stark! Letztes Mal alle Wiederholungen geschafft – heute":"⬆️ Strong! Last time you hit all reps – today","＋ Satz":"＋ Set","Tempo & Dauer eintragen, dann abhaken.":"Enter speed & duration, then tick it off.","Gewicht & Wiederholungen anpassen, dann Satz abhaken ✓ – die Pause startet automatisch. Ohne Gewicht (Körpergewicht) kg leer lassen.":"Adjust weight & reps, then tick off the set ✓ – the rest timer starts automatically. Without weight (bodyweight) leave kg empty.","Nächste Übung ›":"Next exercise ›","🏁 Training beenden":"🏁 Finish workout","↩ Übung wieder aufnehmen":"↩ Resume exercise","⏭ Übung überspringen":"⏭ Skip exercise","(Gerät belegt/defekt, geht gerade nicht …)":"(machine busy/broken, not possible right now …)","Training jetzt beenden & speichern":"Finish & save workout now","✕ Testlauf beenden":"✕ End test run","✕ Training abbrechen …":"✕ Cancel workout …","ⓘ Anleitung":"ⓘ How-to","Satz":"Set","‹ Zurück":"‹ Back","🔗 Supersatz: ohne Pause direkt weiter mit Übung B!":"🔗 Superset: go straight to exercise B without rest!","🔗 Supersatz geschafft – jetzt Pause, danach wieder Übung A.":"🔗 Superset done – rest now, then back to exercise A.","Du bist stärker geworden! 💪":"You got stronger! 💪","Zum ersten Mal":"For the first time","Stark – die App hat ihn gespeichert.":"Strong – the app has saved it.","Wiederholungs-Rekord:":"Rep record:","💪 Übung geschafft! Nach der Pause weiter zur nächsten.":"💪 Exercise done! After the rest, on to the next one.","🏁 Letzte Übung geschafft – Training beenden!":"🏁 Last exercise done – finish the workout!","⏭ Übung übersprungen – du kannst sie jederzeit oben über die Nummer wieder aufrufen.":"⏭ Exercise skipped – you can reopen it anytime via its number at the top.","Training abbrechen?":"Cancel workout?","Dein Trainingsplan bleibt in jedem Fall erhalten.":"Your training plan is kept in any case.","🗑 Verwerfen – nichts speichern":"🗑 Discard – save nothing","Weiter trainieren":"Keep training","Training verworfen – Plan bleibt erhalten":"Workout discarded – plan is kept","Testlauf beendet":"Test run finished","Es wurde nichts gespeichert – kein Kalender-Eintrag, keine Rekorde, dein Plan ist unverändert.":"Nothing was saved – no calendar entry, no records, your plan is unchanged.","Fertig":"Done","Bewegtes Gewicht:":"Weight moved:","🏆 Du bist stärker geworden!":"🏆 You got stronger!","Tipp: Steigere dich nächstes Mal um eine Wiederholung oder 2,5 kg – die App zeigt dir den Vorschlag.":"Tip: Next time add one rep or 2.5 kg – the app shows you the suggestion.","🏁 Training geschafft:":"🏁 Workout done:","Min · 🔥":"min · 🔥","kg bewegt":"kg moved","🏆 Neue Rekorde:":"🏆 New records:","Mit Muskel-Coach 💪":"With Muskel-Coach 💪","Training geschafft!":"Workout done!","Fertig – zum Kalender":"Done – go to calendar","Noch keine Daten – starte ein Training im Plan mit „▶ Training starten“, dann siehst du hier deine Entwicklung.":"No data yet – start a workout in the plan with “▶ Start workout”, then you'll see your progress here.","Bestes:":"Best:","Zuletzt:":"Last:","Kurve zeigt deine Bestleistung je Training (Gewicht und Wiederholungen zusammengerechnet).":"The curve shows your best performance per workout (weight and reps combined).","stehend / viel unterwegs":"standing / on the move a lot","körperlich schwer":"physically demanding","Grundumsatz × 1,2":"BMR × 1.2","nicht mehr als die Grundbewegung":"no more than basic movement","💼 Arbeit:":"💼 Work:","an 5 Tagen, auf die Woche verteilt":"on 5 days, spread over the week","laut deinem Plan, auf alle 7 Tage verteilt":"according to your plan, spread over all 7 days","+ Überschuss Muskelaufbau":"+ surplus for building muscle","− Defizit":"− deficit","± Ziel halten":"± maintain goal","So setzt sich dein Bedarf zusammen":"How your needs add up","= Gesamtumsatz":"= total expenditure","= Dein Tagesziel":"= your daily target","Gesamtumsatz bei anderen Schrittzahlen:":"Total expenditure at other step counts:","🎯 Ziel":"🎯 Goal","– etwa":"– about","die Waage steht – nimm ca. 150 kcal weniger oder bewege dich mehr.":"the scale isn't moving – eat about 150 kcal less or move more.","etwas langsamer als geplant. Dranbleiben – Schwankungen durch Wasser sind normal.":"a bit slower than planned. Keep going – water fluctuations are normal.","schneller als geplant – iss ruhig etwas mehr, damit du keine Muskeln verlierst.":"faster than planned – feel free to eat a bit more so you don't lose muscle.","genau im Plan, super! 💪":"exactly on plan, great! 💪","📉 Tatsächlich laut Waage:":"📉 Actual according to the scale:","Dein Abnehm-Plan":"Your weight-loss plan","Einmal pro Woche wiegen (gleicher Tag, morgens, nüchtern) und im Reiter „Fortschritt“ eintragen – die App passt die Kalorien automatisch an dein neues Gewicht an.":"Weigh yourself once a week (same day, in the morning, before eating) and log it in the “Progress” tab – the app automatically adjusts the calories to your new weight.","Die ersten 1–2 Wochen geht es oft schneller (Wasser), danach pendelt es sich ein.":"The first 1–2 weeks often go faster (water), then it levels out.","Trag Alter, Größe und Gewicht ein – die Werte erscheinen sofort.":"Enter your age, height and weight – the values appear instantly.","Muskelaufbau (+300 kcal Überschuss)":"Build muscle (+300 kcal surplus)","Definieren (−400 kcal Defizit)":"Cut (−400 kcal deficit)","Gewicht halten":"Maintain weight","⚠️ Unter 18: Kreatin und eine gezielte Kalorien-Planung bitte nur nach Rücksprache mit Arzt oder Eltern.":"⚠️ Under 18: please only use creatine and targeted calorie planning after talking to a doctor or your parents.","Hinweis: Die Zielkalorien liegen unter deinem Grundumsatz – das Defizit lieber etwas kleiner halten.":"Note: The target calories are below your BMR – better keep the deficit a little smaller.","Tagesbedarf für":"Daily needs for","Dein Tagesbedarf":"Your daily needs","Realistische Zunahme beim Aufbau":"Realistic gain when building","Nimmst du mehr zu, eher etwas weniger essen. Steht die Waage 3 Wochen still, ~150 kcal mehr.":"If you gain more, eat a little less. If the scale stays still for 3 weeks, ~150 kcal more.","Eiweiß / Tag":"Protein / day","Kreatin / Tag":"Creatine / day","1 g pro 10 kg · täglich, auch an Ruhetagen":"1 g per 10 kg · every day, also on rest days","Grundumsatz":"BMR","kcal in völliger Ruhe":"kcal at complete rest","Gesamtumsatz":"Total expenditure","kcal inkl. Alltag & Training":"kcal incl. daily life & training","Wasser / Tag":"Water / day","mit Kreatin eher etwas mehr":"a bit more with creatine","bei viel Muskelmasse nur bedingt aussagekräftig":"of limited value with a lot of muscle mass","Kreatin richtig einnehmen":"Taking creatine correctly","Bei Magen-Darm-Problemen die Menge auf 2 Portionen aufteilen oder auf 3–5 g (Standardmenge) reduzieren.":"If you have stomach problems, split the amount into 2 servings or reduce it to 3–5 g (standard amount).","Die Uhrzeit ist egal – am einfachsten mit einer Mahlzeit oder dem Shake nach dem Training.":"The time of day doesn't matter – easiest with a meal or your post-workout shake.","Eine Ladephase ist nicht nötig – nach etwa 2–4 Wochen sind die Speicher voll.":"A loading phase isn't necessary – after about 2–4 weeks your stores are full.","1–2 kg mehr auf der Waage am Anfang sind normal – das ist Wasser im Muskel, kein Fett.":"1–2 kg more on the scale at the start is normal – that's water in the muscle, not fat.","Eiweiß über den Tag verteilen":"Spread protein over the day","Gute Quellen: Hähnchen, Pute, Fisch, Eier, Magerquark, Skyr, Hüttenkäse, Linsen, Tofu, Whey.":"Good sources: chicken, turkey, fish, eggs, low-fat quark, skyr, cottage cheese, lentils, tofu, whey.","Disziplin schlägt Motivation.":"Discipline beats motivation.","Stärker als gestern – das ist das einzige Ziel.":"Stronger than yesterday – that's the only goal.","Jede Wiederholung bringt dich näher ans Ziel.":"Every rep brings you closer to your goal.","Ausreden bauen keine Muskeln.":"Excuses don't build muscle.","Du trainierst für dich in 6 Monaten.":"You're training for yourself in 6 months.","Heute ist ein guter Tag für einen neuen Rekord.":"Today is a good day for a new record.","Klein anfangen. Dranbleiben. Groß werden.":"Start small. Keep going. Grow big.","Der härteste Satz ist der, der dich verändert.":"The hardest set is the one that changes you.","Komm nicht nur zum Training – komm, um besser zu werden.":"Don't just come to train – come to get better.","Muskeln wachsen durch Geduld und Konstanz.":"Muscles grow through patience and consistency.","Kein Shortcut. Nur harte Arbeit.":"No shortcut. Just hard work.","Der Wille ist der stärkste Muskel.":"Willpower is the strongest muscle.","– merkt sich dein schwerstes Gewicht und feiert jeden neuen Rekord. In der Vollversion.":"– remembers your heaviest weight and celebrates every new record. In the full version.","Noch keine Rekorde. Starte im Plan „▶ Training starten“ und trag deine Kilo ein – die App merkt sich automatisch dein schwerstes Gewicht pro Übung und feiert jeden neuen Rekord mit dir. 🏆":"No records yet. Start “▶ Start workout” in the plan and enter your kilos – the app automatically remembers your heaviest weight per exercise and celebrates every new record with you. 🏆","Los geht's,":"Let's go,","Champion!":"champion!","Eiweiß":"Protein","Kreatin":"Creatine","Wasser":"Water","Antippen für Details ›":"Tap for details ›","👤 Antippen und Profil anlegen ›":"👤 Tap to create your profile ›","💪 Motivation des Tages":"💪 Motivation of the day","Hallo":"Hello","– dein":"– your","Dein":"Your","Antippen für Details oder zum Ändern":"Tap for details or to change","👤 Profil anlegen":"👤 Create profile","Name, Alter, Größe und Gewicht eintragen – Kalorien, Eiweiß und Kreatin werden automatisch berechnet.":"Enter your name, age, height and weight – calories, protein and creatine are calculated automatically.","Gespeichert ✓":"Saved ✓","kein WebGL":"no WebGL","3D nicht verfügbar":"3D not available","Seite":"Side","Vorne":"Front","Hinten":"Back","👆 Wischen zum Drehen · 2 Finger zoomen":"👆 Swipe to rotate · 2 fingers to zoom","Tolle · Vollbart":"Quiff · full beard","Zurückgegelt · rasiert":"Slicked back · shaved","Buzzcut · 3-Tage-Bart":"Buzz cut · stubble","Locken":"Curls","Locken · Kinnbart":"Curls · chin beard","Glatze & Bart":"Bald & beard","Glatze · Vollbart":"Bald · full beard","Haarknoten · Vollbart":"Man bun · full beard","Pferdeschwanz · pink":"Ponytail · pink","Blond":"Blonde","Lange Haare · Leggings":"Long hair · leggings","Bob · rot":"Bob · red","Dutt":"Bun","Dutt · Leggings":"Bun · leggings","Zopf":"Braid","Rote Haare · grün":"Red hair · green","Kurzhaar · schwarz":"Short hair · black","Der Anfang":"The beginning","Erstes Training abgeschlossen":"First workout completed","Dranbleiber":"Sticking with it","5 Trainings":"5 workouts","Zweistellig":"Double digits","10 Trainings":"10 workouts","Gewohnheit":"Habit","25 Trainings":"25 workouts","Maschine":"Machine","50 Trainings":"50 workouts","Legende":"Legend","100 Trainings":"100 workouts","Am Ball":"On the ball","2 Wochen am Stück trainiert":"Trained 2 weeks in a row","Ein Monat stark":"One strong month","4 Wochen am Stück":"4 weeks in a row","Unaufhaltsam":"Unstoppable","8 Wochen am Stück":"8 weeks in a row","Eiserner Wille":"Iron will","12 Wochen am Stück":"12 weeks in a row","Wochenziel":"Weekly goal","Alle geplanten Trainings einer Woche":"All planned workouts of a week","Erste Tonne":"First ton","1.000 kg bewegt":"1,000 kg moved","10 Tonnen":"10 tons","10.000 kg bewegt":"10,000 kg moved","50 Tonnen":"50 tons","50.000 kg bewegt":"50,000 kg moved","100 Tonnen":"100 tons","100.000 kg bewegt":"100,000 kg moved","Stärker geworden":"Got stronger","Erster persönlicher Rekord":"First personal record","Rekordjäger":"Record hunter","10 persönliche Rekorde":"10 personal records","Kraftpaket":"Powerhouse","25 persönliche Rekorde":"25 personal records","Frühaufsteher":"Early bird","Training vor 8 Uhr beendet":"Workout finished before 8 am","Körper im Blick":"Body in focus","4× Gewicht eingetragen":"Weight logged 4×","Gut gesichert":"Well backed up","Erstes Backup erstellt":"First backup created","🎖 Neues Abzeichen!":"🎖 New badge!","keine Scheiben":"no plates","Gewicht":"Weight","Oberarm":"Upper arm","Oberschenkel":"Thigh","Noch keine Trainings – starte im Plan mit „▶ Training starten“.":"No workouts yet – start in the plan with “▶ Start workout”.","Trainings pro Woche":"Workouts per week","💡 Zuletzt nicht trainiert:":"💡 Not trained recently:","Gewichtsverlauf":"Weight history","Trag regelmäßig (z. B. jeden Montag morgens) dein Gewicht ein – das neueste Gewicht wird automatisch für deinen Kalorien- und Eiweißbedarf übernommen.":"Log your weight regularly (e.g. every Monday morning) – your latest weight is used automatically for your calorie and protein needs.","📊 Statistik":"📊 Stats","Trainings":"Workouts","bewegt gesamt":"moved in total","Trainingsvolumen pro Woche":"Training volume per week","kg × Wdh., letzte 8 Wochen":"kg × reps, last 8 weeks","Sätze pro Muskelgruppe":"Sets per muscle group","letzte 30 Tage":"last 30 days","⚖️ Körper & Maße":"⚖️ Body & measurements","Datum":"Date","Eintragen":"Log","📸 Fortschrittsfotos":"📸 Progress photos","Lade …":"Loading …","📷 Foto aufnehmen / auswählen":"📷 Take / choose photo","Fotos bleiben nur auf deinem Handy (und in deinem Backup). Tipp: immer gleiches Licht, gleiche Pose.":"Photos stay only on your phone (and in your backup). Tip: always the same light, the same pose.","🎖 Abzeichen":"🎖 Badges","🧮 Rechner":"🧮 Calculators","Scheiben-Rechner":"Plate calculator","Was kommt auf jede Seite?":"What goes on each side?","Zielgewicht (kg)":"Target weight (kg)","Stange":"Bar","20 kg (Langhantel)":"20 kg (barbell)","10 kg (SZ)":"10 kg (EZ bar)","ohne Stange":"no bar","Maximalkraft (1RM)":"Max strength (1RM)","Wie viel schaffst du für 1 Wiederholung?":"How much can you lift for 1 rep?","Bitte mindestens einen Wert eintragen":"Please enter at least one value","Eingetragen ✓":"Logged ✓","Eintrag löschen?":"Delete entry?","Zielgewicht ist leichter als die Stange.":"Target weight is lighter than the bar.","Pro Seite:":"Per side:","Geschätztes Maximum:":"Estimated max:","Foto gespeichert ✓":"Photo saved ✓","Foto konnte nicht gespeichert werden":"Photo could not be saved","Noch keine Fotos. Mach heute dein Vorher-Bild – in ein paar Wochen siehst du den Unterschied!":"No photos yet. Take your “before” picture today – in a few weeks you'll see the difference!","Schließen":"Close","Foto löschen?":"Delete photo?","🔒 3D-Coach mit 12 Looks (Männer & Frauen) gibt es in der":"🔒 3D coach with 12 looks (men & women) is included in the","👩 Frauen":"👩 Women","Leg Muskel-Coach als App auf deinen Startbildschirm – mit eigenem Icon, Vollbild und offline nutzbar.":"Put Muskel-Coach on your home screen as an app – with its own icon, full screen and usable offline.","Als App installieren":"Install as app","noch nie":"never","💬 Fragen & Kontakt":"💬 Questions & contact","💬 Chat öffnen":"💬 Open chat","🧍 Dein Coach-Look":"🧍 Your coach look","👨 Männer":"👨 Men","So sieht deine 3D-Figur in allen Übungen aus.":"This is how your 3D figure looks in all exercises.","⚙️ Trainings-Optionen":"⚙️ Training options","📊 Durchschnitt im Training":"📊 Averages during workouts","Ø Gewicht und Ø Wiederholungen bei jeder Übung anzeigen":"Show Ø weight and Ø reps for every exercise","Supersätze":"Supersets","stellst du im Plan ein: zwischen zwei Übungen auf „Als Supersatz verbinden“ tippen.":"are set up in the plan: tap “Link as superset” between two exercises.","⏰ Trainings-Erinnerung":"⏰ Workout reminder","Deine Trainingstage:":"Your training days:","(änderbar im Kalender)":"(change in the calendar)","Uhrzeit":"Time","Erinnern":"Remind me","zur Trainingszeit":"at workout time","15 Min. vorher":"15 min before","30 Min. vorher":"30 min before","1 Std. vorher":"1 hour before","2 Std. vorher":"2 hours before","📅 In Handy-Kalender eintragen":"📅 Add to phone calendar","Google Kalender (Android) öffnen":"Open Google Calendar (Android)","Es werden wöchentlich wiederkehrende Termine mit Erinnerung angelegt. iPhone: Datei öffnen → „Alle hinzufügen“. Hast du deine Trainingstage geändert, einfach nochmal eintragen (alte Termine vorher im Kalender löschen).":"Weekly recurring events with a reminder are created. iPhone: open the file → “Add all”. If you changed your training days, just add them again (delete the old events in the calendar first).","💾 Datensicherung":"💾 Data backup","Letzte Sicherung:":"Last backup:","Sichert Trainings, Rekorde, Plan, Profil, Körperwerte und Fotos in einer Datei. Speichere sie in „Dateien“/iCloud oder schick sie dir per WhatsApp. Damit kannst du alles auf ein neues Handy übertragen.":"Backs up workouts, records, plan, profile, body values and photos in one file. Save it in “Files”/iCloud or send it to yourself via WhatsApp. This lets you move everything to a new phone.","💾 Backup erstellen":"💾 Create backup","📂 Backup laden":"📂 Load backup","Durchschnitt wird angezeigt":"Average is shown","Durchschnitt ausgeblendet":"Average hidden","Look übernommen ✓":"Look applied ✓","Muskel-Coach Trainingstermine":"Muskel-Coach workouts","SUMMARY:💪 Training – Muskel-Coach":"SUMMARY:💪 Workout – Muskel-Coach","DESCRIPTION:Zeit für dein Training! Öffne Muskel-Coach:":"DESCRIPTION:Time for your workout! Open Muskel-Coach:","DESCRIPTION:Gleich Training! 💪":"DESCRIPTION:Workout soon! 💪","💪 Training – Muskel-Coach":"💪 Workout – Muskel-Coach","Öffne Muskel-Coach:":"Open Muskel-Coach:","Muskel-Coach Backup":"Muskel-Coach backup","Backup erstellt ✓":"Backup created ✓","Backup vom":"Load backup from","laden? Die aktuellen Daten auf diesem Handy werden ersetzt.":"? The current data on this phone will be replaced.","Backup geladen ✓ – die App startet neu.":"Backup loaded ✓ – the app restarts.","Das ist keine gültige Muskel-Coach-Sicherung.":"This is not a valid Muskel-Coach backup.","= Stange 20 kg + pro Seite":"= bar 20 kg + per side","Aufwärmsätze:":"Warm-up sets:","Letzte Sicherung ist über 2 Wochen alt":"Last backup is more than 2 weeks old","Deine Daten sind noch nicht gesichert":"Your data isn't backed up yet","Jetzt Backup erstellen, damit nichts verloren geht ›":"Create a backup now so nothing gets lost ›","Vollversion per Chat":"Full version via chat","Direkt in der App „Vollversion“ schreiben → PayPal-Adresse kommt → persönlicher Code, der nur einmal gilt":"Write “full version” right in the app → you get the PayPal address → personal code that works only once","6 Frauen-Figuren":"6 female figures","Im Profil unter „Coach-Look“: Pferdeschwanz, Blond, Bob, Dutt, Zopf, Pixie – mit Sport-BH, Shorts oder Leggings":"In the profile under “Coach look”: ponytail, blonde, bob, bun, braid, pixie – with sports bra, shorts or leggings","Zwei Übungen im Plan verbinden – im Training ohne Pause hintereinander, Pause erst danach":"Link two exercises in the plan – back to back without rest during the workout, rest only afterwards","Durchschnittswerte":"Averages","Ø Gewicht & Ø Wiederholungen im Training und bei jeder Übung (im Profil abschaltbar)":"Ø weight & Ø reps during workouts and for every exercise (can be turned off in the profile)","Grenztest":"Max test","Maximalkraft testen, Verlauf sehen und passende Trainingsgewichte (60–90 %) bekommen":"Test your max strength, see your history and get matching training weights (60–90 %)","15 neue Maschinen-Übungen":"15 new machine exercises","Butterfly, Latzug eng & Untergriff, Rudermaschine, Rückenstrecker, Abduktor/Adduktor, Po-Kickback … – ideal für Einsteiger":"Pec deck, close-grip & underhand lat pulldown, rowing machine, back extension, abductor/adductor, glute kickback … – ideal for beginners","Neue Gruppe „Maschinen“":"New group “Machines”","Alle geführten Übungen auf einen Blick – mit Tipps zur passenden Gewichtsstufe":"All guided exercises at a glance – with tips on the right weight setting","Übung überspringen":"Skip exercise","Gerät belegt oder defekt? Einzelne Übung im Training überspringen – der Rest läuft weiter":"Machine busy or broken? Skip a single exercise during the workout – the rest continues","Abbrechen ohne Verlust":"Cancel without loss","Beim Abbrechen wählen: Bisher Geschafftes speichern oder verwerfen – der Plan bleibt immer erhalten":"When cancelling, choose: save what you've done so far or discard it – the plan is always kept","Training nur ansehen und ausprobieren – es wird nichts gespeichert":"Just look at and try out the workout – nothing is saved","31 neue Übungen":"31 new exercises","Brust, Bauch, Schultern, Trizeps, Bizeps – mit Kurzhantel, Langhantel & Seilzug":"Chest, abs, shoulders, triceps, biceps – with dumbbell, barbell & cable","Neue Gruppe „Unterarme“":"New group “Forearms”","Handgelenk-Curls, Farmer’s Walk, Handgelenk-Roller, Dead Hang u. v. m.":"Wrist curls, farmer's walk, wrist roller, dead hang and more","Menschlichere 3D-Figur":"More human 3D figure","Glatte Haut, echtes Gesicht – und im Profil 6 Coach-Looks zur Auswahl":"Smooth skin, a real face – and 6 coach looks to choose from in the profile","Deine Pläne bleiben gleich":"Your plans stay the same","Neue Übungen kannst du im Plan über „Übung hinzufügen“ einbauen":"You can add new exercises to your plan via “Add exercise”","Neu in Muskel-Coach":"New in Muskel-Coach","Alles klar 💪":"Got it 💪","Tippen für alle Neuigkeiten":"Tap for all news","✅ App installiert – du findest sie jetzt auf dem Startbildschirm":"✅ App installed – you'll now find it on your home screen","Tippe oben rechts auf":"Tap at the top right on","bzw. das Kompass-Symbol":"or the compass icon","Wähle":"Choose","Dann hier nochmal auf":"Then tap here again on","„Als App installieren“":"“Install as app”","Du hast den Link in":"You opened the link in","geöffnet. Dort kann man keine Apps installieren.":". You can't install apps there.","Mit einem Tipp landet Muskel-Coach als":"With one tap Muskel-Coach lands on your home screen as a","echte App":"real app","auf deinem Startbildschirm – mit eigenem Icon, im Vollbild und auch offline.":"– with its own icon, full screen and offline too.","📲 Jetzt installieren":"📲 Install now","Unten in Safari auf":"At the bottom of Safari tap","Neuere iPhones: erst auf":"Newer iPhones: first tap","(unten rechts), dann auf":"(bottom right), then","Nach unten wischen und":"Swipe down and","„Zum Home-Bildschirm“":"“Add to Home Screen”","wählen":"choose","ggf. „Als Web-App öffnen“ eingeschaltet lassen":"leave “Open as Web App” turned on if shown","Oben rechts auf":"At the top right tap","„Hinzufügen“":"“Add”","tippen – fertig! 🎉":"– done! 🎉","So kommt Muskel-Coach als":"This is how Muskel-Coach gets onto your home screen as an","App":"app","auf deinen Home-Bildschirm (dauert 10 Sekunden):":"(takes 10 seconds):","Apple erlaubt Websites nicht, das automatisch zu machen – deshalb diese 3 Tipps.":"Apple doesn't let websites do this automatically – hence these 3 steps.","Link kopieren und in":"Copy the link and open it in","öffnen (oder in Chrome: Teilen-Symbol oben rechts)":"(or in Chrome: share icon at the top right)","Auf dem iPhone geht das am besten in":"On iPhone this works best in","Oben rechts im Browser auf":"At the top right of the browser tap","„App installieren“":"“Install app”","„Zum Startbildschirm hinzufügen“":"“Add to Home screen”","Mit":"Confirm with","„Installieren“":"“Install”","bestätigen – fertig! 🎉":"– done! 🎉","auf deinen Startbildschirm:":"to your home screen:","Öffne diesen Link auf deinem":"Open this link on your","Handy":"phone","– dort kannst du Muskel-Coach als App auf den Startbildschirm legen. Am Computer: im Chrome/Edge-Adressfeld auf das":"– there you can put Muskel-Coach on your home screen as an app. On a computer: in the Chrome/Edge address bar, click the","Installieren-Symbol":"install icon","Muskel-Coach · kostenlos · ohne App Store":"Muskel-Coach · free · no App Store","Später":"Later","Ein Tipp – fertig":"One tap – done","Mit eigenem Icon auf den Startbildschirm":"On your home screen with its own icon","📲 Als App installieren":"📲 Install as app","Entwickler-Modus":"Developer mode","Nur für den Entwickler":"Developer only","Falsches Passwort":"Wrong password","✅ eingelöst":"✅ redeemed","⏳ offen":"⏳ open","🔄 Status aller Codes prüfen":"🔄 Check status of all codes","Noch keine Codes erzeugt.":"No codes created yet.","🛠️ Entwickler":"🛠️ Developer","🔒 Sperren":"🔒 Lock","📊 Nutzer":"📊 Users","Nutzer gesamt":"Total users","heute aktiv":"active today","Codes eingelöst":"Codes redeemed","Lade Verlauf …":"Loading history …","Zählt anonym jedes Gerät einmal (ohne Namen oder persönliche Daten). Wer alle Website-Daten löscht, wird neu gezählt.":"Counts every device once, anonymously (no names or personal data). Anyone who deletes all website data is counted again.","🎟️ Freischalt-Code erzeugen":"🎟️ Create unlock code","Für wen? (optional)":"For whom? (optional)","🎲 Neuen lokalen Testcode erzeugen":"🎲 Create new 6-digit code","Jeder Code funktioniert":"Every code works","genau einmal":"exactly once","– danach ist er verbraucht. Der Testcode gilt nur in diesem Browserprofil.":"– after that it's used up. Create a new code for every buyer.","📋 Vergebene Codes":"📋 Issued codes","🧪 Test-Werkzeuge":"🧪 Test tools","Demo neu starten (nur dieses Gerät)":"Restart demo (this device only)","Demo als abgelaufen simulieren":"Simulate expired demo","„Was ist neu“ erneut zeigen":"Show “What's new” again","Entwickler-Modus gesperrt":"Developer mode locked","💬 Per WhatsApp senden":"💬 Send via WhatsApp","📋 Kopieren":"📋 Copy","Kopiert ✓":"Copied ✓","⏳ Prüfe …":"⏳ Checking …","Status aktualisiert":"Status updated","Demo-Daten gelöscht – gilt erst, wenn das Gerät nicht freigeschaltet ist":"Demo data deleted – only takes effect if the device isn't unlocked","Demo-Start auf vor 11 Tagen gesetzt":"Demo start set to 11 days ago","⚠️ Zähldienst nicht erreichbar – Internet prüfen.":"⚠️ Counter service unreachable – check your internet.","Aktive Nutzer – letzte 7 Tage":"Active users – last 7 days","Chat gerade nicht erreichbar – bitte Internet prüfen":"Chat unavailable right now – please check your internet","Chat wird geöffnet …":"Opening chat …","Chat lädt nicht – bitte später nochmal versuchen":"Chat isn't loading – please try again later","Tage":"days","Bald vorbei!":"Ending soon!","Vollversion gratis":"Full version free","Du testest gerade die":"You're currently testing the",". Danach geht es mit der kostenlosen Basis-Version weiter – oder du behältst alles für einmalig":". After that you continue with the free basic version – or keep everything for a one-time","gehört zur Vollversion.":"is part of the full version.","Deine 10-Tage-Demo ist vorbei.":"Your 10-day demo has ended.","Du nutzt jetzt die kostenlose Basis-Version.":"You're now using the free basic version.","Hol dir alles für einmalig":"Get everything for a one-time","im Chat":"in the chat","per WhatsApp":"via WhatsApp","💬 Jetzt im Chat schreiben":"💬 Write in the chat now","oder per WhatsApp":"or via WhatsApp","💬 „Vollversion“ per WhatsApp senden":"💬 Send “full version” via WhatsApp","Weiter testen ›":"Keep testing ›","Mit Basis-Version weiter ›":"Continue with basic version ›","Schreib":"Write","„Vollversion“":"“full version”","Du bekommst die":"You'll get the","PayPal-Adresse":"PayPal address","und zahlst":"and pay","persönlicher Freischalt-Code":"personal unlock code","Schon gekauft? Code einmal eingeben:":"Already bought? Enter your code once:","Freischalten":"Unlock","freigeschaltet!":"unlocked!","Danke! Die App startet neu …":"Thank you! The app is restarting …","⏳ Code wird geprüft …":"⏳ Checking code …","Dieser Code wurde schon verwendet. Jeder Code gilt nur einmal – bitte neuen Code anfragen.":"This code has already been used. Each code only works once – please request a new code.","Keine Internetverbindung – bitte Internet einschalten und nochmal versuchen.":"No internet connection – please turn on the internet and try again.","Falscher Code – bitte nochmal prüfen.":"Wrong code – please check again.","🎁 Vollversion-Demo · noch":"🎁 Full version demo ·","🔓 Basis-Version ·":"🔓 Basic version ·","Chat mit Dr. Muskel Coach":"Chat with Dr. Muskel Coach","Jetzt auch auf Englisch":"Now also in English","Im Profil unter „Sprache“ zwischen Deutsch und Englisch umschalten – Übungen, Pläne und alle Texte":"Switch between German and English in the profile under “Language” – exercises, plans and all texts","Tag hinzufügen":"Add day","Dauer und Tempo":"Duration and pace","nach oben":"move up","nach unten":"move down","Übung per WhatsApp teilen":"Share exercise via WhatsApp","Erfolg per WhatsApp teilen":"Share your success via WhatsApp","Mehrere Sätze verschieden?":"Different sets?","z. B.":"e.g.","Name des Trainingstags":"Name of the training day","entfernen":"remove","↓ Ziehen zum Aktualisieren":"↓ Pull to refresh","↻ Loslassen zum Aktualisieren":"↻ Release to refresh","⟳ Aktualisiere …":"⟳ Refreshing …","Profil, Kalorien, Eiweiß":"Profile, calories, protein","Profilbild":"Profile picture","📷 Bild wählen":"📷 Choose photo","Entfernen":"Remove","Bleibt nur auf deinem Handy.":"Stays only on your phone.","Profilbild gespeichert ✓":"Profile picture saved ✓","Bild konnte nicht gespeichert werden":"Picture could not be saved","Profilbild entfernt":"Profile picture removed","Anatomie":"Anatomy","Muskel-Ansicht · Rot = Hauptmuskel":"Muscle view · red = main muscle","🔬 Anatomie-Ansicht":"🔬 Anatomy view","Hauptmuskeln":"Main muscles","Hilfsmuskeln":"Assisting muscles","🔒 3D-Coach mit 14 Looks (Männer, Frauen & Anatomie) gibt es in der":"🔒 3D coach with 14 looks (men, women & anatomy) is included in the","Neuer Look: Anatomie":"New look: anatomy","Muskelfigur wie im Anatomie-Atlas – Hauptmuskeln rot, Hilfsmuskeln rosa. Im Profil unter „Coach-Look“":"Muscle figure like in an anatomy atlas – main muscles red, assisting muscles pink. In the profile under “Coach look”","Beteiligte Muskeln":"Muscles involved","nach Rolle eingefärbt":"colored by role","Andere":"Other","neutral · nicht hervorgehoben":"neutral · not highlighted","Farben zeigen die Rolle des Muskels, keine gemessene Kraft.":"Colors show the muscle's role, not measured force.","Läuft":"Playing","Pausiert":"Paused","Manuell":"Manual","Bewegungsablauf":"Movement","↺ Neu starten":"↺ Restart","Schräg":"Oblique","👆 Wischen zum Drehen · 2 Finger zoomen · vereinfachte Bewegungsdarstellung":"👆 Swipe to rotate · 2 fingers to zoom · simplified motion","Ausführen – ausatmen":"Lift – breathe out","Kontrolliert zurück – einatmen":"Controlled return – breathe in","Neue 3D-Ansicht":"New 3D view","Wie ein Bewegungslabor: Muskel-Karte, Ablauf mit Schieberegler zum Vor- und Zurückspulen, Tempo, Kamera schräg/seitlich/hinten":"Like a movement lab: muscle card, movement slider to scrub back and forth, speed, oblique/side/back camera","⏸ Pause":"⏸ Pause","Bewegungen überarbeitet":"Movements reworked","Alle 90 Übungen geprüft: Dips, Butterfly, Kabel-Crossover, Sitz-Maschinen, Klimmzüge u. a. jetzt realistischer und besser nachzumachen":"All 90 exercises checked: dips, flyes, cable crossover, seated machines, pull-ups and more are now more realistic and easier to follow","Tage<br>Vollversion":"Days<br>full version","Deine Vollversion ist abgelaufen.":"Your full version has expired.","Sie gilt jeweils 1 Jahr. Du nutzt jetzt die kostenlose Basis-Version – mit einem neuen Code hast du wieder ein Jahr alles für":"It is valid for 1 year at a time. You're now using the free basic version – with a new code you get everything again for a year for","Deine Vollversion läuft noch bis":"Your full version runs until","Mit einem neuen Code verlängerst du um":"A new code extends it by","1 Jahr":"1 year","– die Resttage bleiben erhalten.":"– your remaining days are kept.","Danach ist die Vollversion":"After that the full version is","lang freigeschaltet.":"unlocked.","Gültig bis":"Valid until","Unbegrenzt (Master-Code)":"Unlimited (master code)","⭐ Vollversion · noch":"⭐ Full version ·","🔑 Verlängern":"🔑 Renew","⭐ Vollversion":"⭐ Full version","Freigeschaltet –":"Unlocked –","unbegrenzt":"unlimited","(Master-Code).":"(master code).","Die Vollversion gilt jeweils 1 Jahr.":"The full version is valid for 1 year at a time.","Abgelaufen.":"Expired.","Mit einem neuen Code hast du wieder 1 Jahr die Vollversion.":"With a new code you get the full version for another year.","Demo – noch":"Demo –","Die Vollversion gilt danach jeweils 1 Jahr.":"After that the full version is valid for 1 year at a time.","Basis-Version. Die Vollversion gilt jeweils 1 Jahr.":"Basic version. The full version is valid for 1 year at a time.","🔑 Mit neuem Code verlängern":"🔑 Renew with a new code","Vollversion: noch 5 Tage simulieren":"Full version: simulate 5 days left","Vollversion als abgelaufen simulieren":"Simulate expired full version","Gesetzt – App neu laden":"Set – reload the app","Vollversion jetzt 1 Jahr":"Full version now 1 year","Die Vollversion gilt 365 Tage ab Freischaltung. Im Profil siehst du, bis wann – verlängern geht jederzeit mit einem neuen Code.":"The full version is valid for 365 days from unlocking. Your profile shows until when – you can renew anytime with a new code.","– 1 Jahr alles für nur":"– everything for 1 year for only","behältst alles 1 Jahr lang für":"keep everything for 1 year for","Hol dir alles für 1 Jahr – nur":"Get everything for 1 year – only","Noch":"Still","Zu viele falsche Versuche – bitte in":"Too many wrong attempts – please try again in","Min. erneut versuchen.":"min.","Falscher Code – bitte nochmal prüfen. (noch":"Wrong code – please check again. (","Versuche)":"attempts left)","Versuch)":"attempt left)","Glückwunsch!":"Congratulations!","Du hast jetzt":"You now have","die Vollversion":"of the full version","Deine Vollversion ist":"Your full version is","freigeschaltet":"unlocked","alle Übungen, Trainingsplan, 3D-Coach & mehr":"all exercises, training plan, 3D coach & more","💪 Los geht's":"💪 Let's go","👁 Vorschau:":"👁 Preview:","zurück zur Vollversion":"back to full version","Demo (noch 7 Tage)":"Demo (7 days left)","Vollversion abgelaufen":"Full version expired","Vollversion – noch 5 Tage":"Full version – 5 days left","So sieht die App für Kunden aus – nur zum Ansehen. Deine eigene Freischaltung bleibt erhalten.":"How the app looks for customers – preview only. Your own unlock stays.","🔓 Basis-Version":"🔓 Basic version","🎁 Demo":"🎁 Demo","⏳ Noch 5 Tage":"⏳ 5 days left","⌛ Abgelaufen":"⌛ Expired","⚠️ Erst auf diesem Handy freischalten (z. B. Master-Code), dann funktioniert die Vorschau.":"⚠️ Unlock this phone first (e.g. master code), then the preview works.","Erst auf diesem Handy freischalten":"Unlock this phone first","🎉 Glückwunsch-Fenster ansehen":"🎉 Show congratulations popup","· noch":"·","Sicher bezahlen mit":"Pay securely with","Karte, Apple Pay oder Google Pay":"card, Apple Pay or Google Pay","für 1 Jahr":"for 1 year","E-Mail":"email","an die Adresse, die du beim Bezahlen angibst (meist innerhalb weniger Stunden)":"to the address you enter when paying (usually within a few hours)","Code einmal eingeben – fertig ✅":"Enter the code once – done ✅","Deine Bestellnummer:":"Your order number:","Bestellnummer:":"Order number:","💳 Jetzt kaufen ·":"💳 Buy now ·","💬 Fragen? Im Chat schreiben":"💬 Questions? Write in the chat","Einfach bezahlen":"Easy payment","Vollversion jetzt direkt mit Karte, Apple Pay oder Google Pay kaufen – der Freischalt-Code kommt per E-Mail":"Buy the full version directly with card, Apple Pay or Google Pay – the unlock code arrives by email","kommt per":"arrives by","🌍 Länder":"🌍 Countries","Lade Länder …":"Loading countries …","Noch keine Länder gezählt.":"No countries counted yet.","✓ Aktuell":"✓ Up to date","Ermittelt aus Zeitzone und Spracheinstellung des Handys – ohne IP-Adresse, anonym. Zählt jedes Gerät einmal ab diesem Update (frühere Nutzer erst beim nächsten Öffnen).":"Determined from the phone's time zone and language setting – no IP address, anonymous. Counts every device once from this update on.","Pro Athlet":"Pro athlete","Cap · Rot leuchtende Muskeln":"Cap · glowing red muscles","🔬 Anatomie & Pro":"🔬 Anatomy & pro","Neuer Look: Pro Athlet":"New look: pro athlete","Graue Profi-Figur mit Cap und rot leuchtenden Muskeln – dazu Beschriftung am Muskel mit Fachnamen (z. B. Pectoralis major)":"Grey pro figure with cap and glowing red muscles – plus a label on the muscle with its anatomical name (e.g. pectoralis major)","Seitl. Bauch":"Obliques","Breiter Rücken":"Lats","Oberer Rücken":"Upper back","Schulter":"Shoulder","Unterarm":"Forearm","Wade":"Calf","Hals":"Neck","Besserer Körper":"Better body","Mehr Muskeldetails (Brust, Schultern, Sägezahn, Rücken, Oberschenkel, Waden), feinere Oberfläche, natürlicheres Licht – und die 3D-Figur lädt schneller":"More muscle detail (chest, shoulders, serratus, back, thighs, calves), finer surface, more natural lighting – and the 3D figure loads faster","🧍 3D":"🧍 3D","📷 Bild":"📷 Image","Bild-Modus für Übungen":"Image mode for exercises","Übungen können jetzt als realistische Bilder (Start · Mitte · Ende) mit flüssiger Überblendung laufen – mit Muskel-Beschriftung. Oben rechts wechselst du jederzeit zwischen Bild und 3D.":"Exercises can now play as realistic images (start · middle · end) with smooth crossfades and muscle labels. Switch between image and 3D any time at the top right.","Pro Athlet ist Standard":"Pro Athlete is now default","Die 3D-Figur startet jetzt im Look „Pro Athlet“. Andere Looks kannst du weiter im Profil wählen.":"The 3D figure now starts in the “Pro Athlete” look. You can still pick other looks in your profile.","gerade online (letzte 5 Min.)":"online now (last 5 min)","Sprache der Mail:":"Email language:","Alle 90 Übungen":"All 90 exercises","360° drehbar aus jeder Perspektive, Muskeln leuchten, 14 Looks – Männer, Frauen, Anatomie & Pro Athlet":"360° rotatable from every angle, muscles light up, 14 looks – men, women, anatomy & pro athlete","Verlängert bis 02.12.: Vollversion nur 4,99 € statt 9,99 € – auch schon während der 10-Tage-Demo sichtbar":"Extended until 2 Dec: full version only €4.99 instead of €9.99 – visible during the 10-day demo too","90 Übungen mit 3D-Vorführung":"90 exercises with 3D demo","Neue Startseite":"New home screen","3D-Pro-Athlet als Motivation, Black-Friday-Angebot mit Countdown, Wochen-Statistik (Trainings, Serie, Rekorde) und neue Schnellzugriff-Kacheln":"3D pro athlete as motivation, Black Friday offer with countdown, weekly stats (workouts, streak, records) and new quick-access tiles"};
const I18N_P=[["^Danke\\ für\\ deinen\\ Kauf!\\ 💪\\ Dein\\ persönlicher\\ Freischalt\\-Code\\ für\\ Muskel\\-Coach:\\ \\*(.*?)\\*\\ So\\ geht's:\\ App\\ öffnen\\ →\\ „Vollversion“\\ antippen\\ →\\ Code\\ eingeben\\ →\\ fertig\\.\\ Der\\ Code\\ gilt\\ nur\\ einmal\\.\\ (.*?)$","Thanks for your purchase! 💪 Your personal unlock code for Muskel-Coach: *{}* How it works: open the app → tap “full version” → enter the code → done. The code only works once. {}"],["^(.*?)\\ Termine\\ pro\\ Woche\\ ·\\ Plan\\ hat\\ (.*?)\\ Tage\\.\\ (.*?)\\ Die\\ Reihenfolge\\ läuft\\ einfach\\ weiter\\ –\\ verpasst\\ du\\ einen\\ Termin,\\ rückt\\ das\\ nächste\\ Training\\ nach\\.$","{} sessions per week · plan has {} days. {} The order just keeps going – if you miss a session, the next workout moves up."],["^Für\\ (.*?)\\ kg/Woche\\ müsstest\\ du\\ unter\\ (.*?)\\ kcal\\ essen\\ –\\ das\\ ist\\ zu\\ wenig\\.\\ Die\\ App\\ rechnet\\ deshalb\\ mit\\ (.*?)\\ kcal\\ \\(≈\\ (.*?)\\ kg/Woche\\)\\.$","For {} kg/week you'd have to eat under {} kcal – that's too little. The app therefore uses {} kcal (≈ {} kg/week)."],["^⏰\\ Letztes\\ Training\\ vor\\ (.*?)\\ Tagen\\ –\\ heute\\ wäre\\ ein\\ guter\\ Tag,\\ um\\ wieder\\ einzusteigen\\.\\ Es\\ geht\\ mit$","⏰ Last workout {} days ago – today would be a good day to get back into it. Continuing with"],["^Eiweiß\\ hoch\\ halten\\ \\((.*?)\\ g\\)\\ und\\ weiter\\ Krafttraining\\ machen\\ –\\ so\\ verlierst\\ du\\ Fett\\ statt\\ Muskeln\\.$","Keep protein high ({} g) and keep strength training – that way you lose fat instead of muscle."],["^(.*?)\\ g\\ Kreatin\\-Monohydrat\\ jeden\\ Tag\\ \\(1\\ g\\ pro\\ 10\\ kg:\\ (.*?)\\ kg\\ ÷\\ 10\\ =\\ (.*?)\\ g,\\ auf\\ 0,5\\ g\\ gerundet\\)\\.$","{} g creatine monohydrate every day (1 g per 10 kg: {} kg ÷ 10 = {} g, rounded to 0.5 g)."],["^Fragen\\ zur\\ App,\\ Vollversion\\ kaufen\\ oder\\ Ideen\\?\\ Schreib\\ (.*?)\\ direkt\\ hier\\ im\\ Chat\\.$","Questions about the app, buying the full version or ideas? Write {} right here in the chat."],["^(.*?)\\ kcal\\ ×\\ 7\\ Tage\\ =\\ (.*?)\\ kcal\\ pro\\ Woche\\.\\ 1\\ kg\\ Körperfett\\ ≈\\ 7\\.700\\ kcal\\ →$","{} kcal × 7 days = {} kcal per week. 1 kg of body fat ≈ 7,700 kcal →"],["^Körper\\ in\\ Ruhe\\ (.*?)\\ kcal\\ \\+\\ Alltag\\ \\(Essen,\\ Sitzen,\\ \\~2\\.500\\ Schritte\\)$","Body at rest {} kcal + daily life (eating, sitting, ~2,500 steps)"],["^Training\\ am\\ (.*?)\\ verpasst\\?\\ Kein\\ Problem\\ –\\ die\\ App\\ macht\\ einfach\\ mit$","Missed the workout on {}? No problem – the app simply continues with"],["^(.*?)\\ km\\ zusätzlich\\ gegangen\\ ·\\ ca\\.\\ (.*?)\\ kcal\\ pro\\ 1\\.000\\ Schritte$","{} km extra walked · approx. {} kcal per 1,000 steps"],["^10\\ ×\\ (.*?)\\ kg\\ ·\\ 5\\ ×\\ (.*?)\\ kg\\ ·\\ 3\\ ×\\ (.*?)\\ kg\\ –\\ dann\\ Arbeitssätze$","10 × {} kg · 5 × {} kg · 3 × {} kg – then working sets"],["^🔒\\ (.*?)\\ Pro\\-Übung(.*?)\\ übersprungen\\ –\\ in\\ der\\ Vollversion\\ dabei$","🔒 {} pro exercise{} skipped – included in the full version"],["^3–5\\ Mahlzeiten\\ mit\\ je\\ ca\\.\\ (.*?)\\ g\\ Eiweiß\\ sind\\ ideal\\.$","3–5 meals with approx. {} g protein each are ideal."],["^Geschätzt\\ für\\ (.*?)\\ kg\\ Körpergewicht\\ inkl\\.\\ Satzpausen\\.$","Estimated for {} kg body weight incl. rest between sets."],["^(.*?)\\ Übungen\\ ·\\ Tag\\ (.*?)\\ deines\\ Plans\\ ·\\ 🔥\\ ca\\.\\ (.*?)\\ kcal$","{} exercises · day {} of your plan · 🔥 approx. {} kcal"],["^(.*?)\\.\\ Stark\\ –\\ jetzt\\ Eiweiß\\ tanken\\ und\\ erholen\\.$","{}. Strong – now refuel with protein and recover."],["^Abnehmen\\ \\(−(.*?)\\ kcal\\ Defizit\\ ·\\ ca\\.\\ (.*?)\\ kg/Woche\\)$","Lose weight (−{} kcal deficit · approx. {} kg/week)"],["^Rest\\ (.*?)\\ kg\\ nicht\\ mit\\ Standard\\-Scheiben\\ möglich$","Remaining {} kg not possible with standard plates"],["^(.*?):\\ zum\\ ersten\\ Mal\\ (.*?)\\ am\\ Stück\\ \\(bisher\\ (.*?)\\)$","{}: {} in a row for the first time (previously {})"],["^(.*?):\\ zum\\ ersten\\ Mal\\ (.*?)\\ kg\\ \\(bisher\\ (.*?)\\ kg\\)$","{}: {} kg for the first time (previously {} kg)"],["^(.*?)\\ Übungen\\ ·\\ (.*?)\\ Sätze\\ ·\\ ca\\.\\ (.*?)\\ Min\\.\\ ·$","{} exercises · {} sets · approx. {} min ·"],["^💾\\ Bisher\\ Geschafftes\\ speichern\\ \\((.*?)\\ (.*?)\\)$","💾 Save progress so far ({} {})"],["^kommt\\ (.*?)\\ –\\ einmal\\ eingeben,\\ fertig\\ ✅$","arrives {} – enter it once, done ✅"],["^Deine\\ geschätzte\\ Maximalkraft\\ bei\\ (.*?):$","Your estimated max strength for {}:"],["^\\+\\ (.*?)\\ weitere\\ Neuerung(.*?)\\ anzeigen$","+ show {} more update{}"],["^\\(aus\\ (.*?)\\ Sätzen\\ ·\\ (.*?)\\ Training(.*?)\\)$","(from {} sets · {} workout{})"],["^🏋️\\ Krafttraining\\ (.*?)×\\ pro\\ Woche$","🏋️ Strength training {}× per week"],["^(.*?)\\ Erfolg\\ per\\ WhatsApp\\ teilen$","{} Share success via WhatsApp"],["^Neu:\\ (.*?)\\ \\&\\ (.*?)\\ weitere\\ Neuerung(.*?)$","New: {} & {} more update{}"],["^(.*?)\\ Übung\\ per\\ WhatsApp\\ teilen$","{} Share exercise via WhatsApp"],["^(.*?)\\ g\\ pro\\ kg\\ ·\\ Spanne\\ (.*?)–(.*?)\\ g$","{} g per kg · range {}–{} g"],["^am\\ Stück\\ bei\\ (.*?)\\ geschafft!$","in a row at {}!"],["^Satz\\ (.*?)\\ ✓\\ –\\ Pause\\ läuft\\.$","Set {} ✓ – rest running."],["^(.*?)\\ kg\\ ×\\ (.*?)\\ \\(bisher\\ ×\\ (.*?)\\)$","{} kg × {} (previously × {})"],["^Ø\\ (.*?)\\ Min\\.\\ pro\\ Training$","Ø {} min per workout"],["^mit\\ (.*?)\\ Trainingstagen\\.$","with {} training days."],["^Kalorien\\ pro\\ Tag\\ ·\\ (.*?)$","Calories per day · {}"],["^\\&\\ (.*?)\\ weitere\\ Neuerung(.*?)$","& {} more update{}"],["^ca\\.\\ (.*?)\\ kg\\ pro\\ Woche$","approx. {} kg per week"],["^🎖\\ Neues\\ Abzeichen:\\ (.*?)$","🎖 New badge: {}"],["^Neuer\\ Rekord:\\ (.*?)\\ kg!$","New record: {} kg!"],["^\\(−(.*?)\\ kg\\):\\ in\\ ca\\.$","(−{} kg): in approx."],["^Alle\\ Einträge\\ \\((.*?)\\)$","All entries ({})"],["^Letztes\\ Mal\\ \\((.*?)\\):$","Last time ({}):"],["^Bisher:\\ (.*?)\\ kg\\ am\\ (.*?)$","Previous: {} kg on {}"],["^Kohlenhydrate\\ (.*?)\\ g$","Carbs {} g"],["^bei\\ (.*?)\\ geschafft!$","done at {}!"],["^Neuer\\ Rekord:\\ (.*?)!$","New record: {}!"],["^−(.*?)\\ kcal\\ pro\\ Tag$","−{} kcal per day"],["^Update\\ vom\\ (.*?)\\.(.*?)\\.(.*?)$","Update from {}.{}.{}"],["^(.*?)\\ Min\\ ·\\ (.*?)\\ km/h$","{} min · {} km/h"],["^·\\ zuletzt\\ (.*?)\\ kg$","· last {} kg"],["^🔥\\ ca\\.\\ (.*?)\\ kcal$","🔥 approx. {} kcal"],["^Bisher:\\ (.*?)\\ am\\ (.*?)$","Previous: {} on {}"],["^(.*?)–(.*?)\\ kg\\ /\\ Monat$","{}–{} kg / month"],["^Heute\\ dran:\\ (.*?)$","Due today: {}"],["^Übung\\ (.*?)\\ von\\ (.*?)$","Exercise {} of {}"],["^💪\\ (.*?)\\ Tagesziel$","💪 {} daily goal"],["^„In\\ (.*?)\\ öffnen“$","“Open in {}”"],["^📅\\ Geplant:\\ (.*?)$","📅 Planned: {}"],["^Vorher:\\ (.*?)\\ kg$","Before: {} kg"],["^🚶\\ (.*?)\\ Schritte$","🚶 {} steps"],["^Vollversion\\ (.*?)$","Full version {}"],["^in\\ (.*?)\\ Wochen$","in {} weeks"],["^Eiweiß\\ (.*?)\\ g$","Protein {} g"],["^Vorher\\ ·\\ (.*?)$","Before · {}"],["^Heute\\ ·\\ (.*?)$","Today · {}"],["^(.*?)(.*?)\\ kg/Woche$","{}{} kg/week"],["^Jetzt\\ ·\\ (.*?)$","Now · {}"],["^z\\.\\ B\\.\\ (.*?)$","e.g. {}"],["^(.*?)\\ Übungen$","{} exercises"],["^·\\ (.*?)\\ Tage$","· {} days"],["^Fett\\ (.*?)\\ g$","Fat {} g"],["^\\~(.*?)\\ Wdh\\.$","~{} reps"],["^Haupt:\\ (.*?)$","Primary: {}"],["^Neben:\\ (.*?)$","Secondary: {}"],["^(.*?)/(.*?)\\ Sätze$","{}/{} sets"],["^(.*?)\\ Wochen$","{} weeks"],["^(.*?)\\ Sek\\.$","{} sec"],["^(.*?)\\ Wdh\\.$","{} reps"],["^(.*?)(.*?)\\ Wdh\\.$","{}{} reps"],["^Seit\\ (.*?):$","Since {}:"],["^\\((.*?)\\):\\ (.*?)$","({}): {}"],["^Neu:\\ (.*?)$","New: {}"],["^(.*?)\\ an\\ (.*?)$","{} to {}"],["^(.*?)Tag\\ (.*?)$","{}Day {}"],["^im\\ (.*?)$","in {}"]];
const tr=(function(){
  if(LANG!=='en') return s=>s;
  const pats=I18N_P.map(p=>[new RegExp(p[0]),p[1]]);
  const cache=new Map(); const L=/[A-Za-zÄÖÜäöüß]/; const NL='A-Za-zÄÖÜäöüß';
  let loose=null;
  function looseRe(){ if(loose) return loose;
    const keys=Object.keys(I18N_D).filter(k=>k.length>=2&&k.length<=48&&!/[()[\]{}*+?.\\^$|]/.test(k)).sort((a,b)=>b.length-a.length);
    loose=new RegExp('(^|[^'+NL+'])('+keys.map(k=>k.replace(/[-\/\\^$*+?.()|[\]{}]/g,'\\$&')).join('|')+')(?=[^'+NL+']|$)','g'); return loose; }
  function num(s){ return /\d/.test(s)? s.replace(/\b\d{1,3}(?:\.\d{3})+\b/g,m=>m.replace(/\./g,'\u0003')).replace(/(\d),(\d)/g,(m,a,b)=>a+'.'+b).replace(/\u0003/g,',') : s; }
  function core(c){
    let r=I18N_D[c]; if(r!==undefined) return r;
    const m2=c.match(/^(.*?)([:!?…]+)$/); if(m2&&I18N_D[m2[1]]!==undefined) return I18N_D[m2[1]]+m2[2];
    const q=c.match(/^([„“"»«(]+)(.+?)([“”"»«)]+[.!]?)$/); if(q){ const r=core(q[2]); if(r!==null) return q[1].replace(/„/g,'“')+r+q[3].replace(/“/g,'”'); }
    for(const [re,en] of pats){ const m=c.match(re); if(!m) continue; let i=1;
      return en.replace(/\{\}/g,(x,off)=>{ let g=m[i++]||''; const prevLetter=/[A-Za-z]$/.test(en.slice(0,off));
        if(prevLetter&&/^(en|e|n|s)$/.test(g)) return 's'; if(prevLetter&&g==='') return '';
        return L.test(g)?tr0(g):g; }); }
    if(c.includes(' · ')){ const parts=c.split(' · '); const t=parts.map(tr0); if(t.some((x,i)=>x!==parts[i])) return t.join(' · '); }
    const nm=c.match(/^(\d+[.)]\s+)(.+)$/); if(nm){ const r=core(nm[2]); if(r!==null) return nm[1]+r; }
    const cz=c.replace(/z\. ?B\./g,'\u0002');
    const ss=cz.match(/[^.!?…:]+(?:[.!?…:]+|$)\s*/g);
    if(ss&&ss.length>1){ const t=ss.map(x=>{ const m=x.match(/^([\s\S]*?)(\s*)$/); const raw=m[1].replace(/\u0002/g,'z. B.'); const r=tr0(raw); return (r===raw&&m[1].includes('\u0002')?raw.replace(/z\. B\./g,'e.g.'):r)+m[2]; });
      if(t.join('')!==ss.join('').replace(/\u0002/g,'z. B.')) return t.join('').replace(/\u0002/g,'e.g.'); }
    for(const d of [' – ',' — ',' / ']){ if(!c.includes(d)) continue; const parts=c.split(d); const t=parts.map(tr0); if(t.some((x,i)=>x!==parts[i])) return t.join(d); }
    return null; }
  function tr0(s){ const c=s.replace(/\s+/g,' ').trim(); if(!c||!L.test(c)) return s; let r=core(c); if(r===null){ r=c.replace(looseRe(),(x,pre,w)=>pre+I18N_D[w]); if(r===c) r=null; } return r===null?s:r; }
  return function tr(s,isLoose){
    if(typeof s!=='string'||!s) return s;
    const k=(isLoose?'\u0001':'')+s; if(cache.has(k)) return cache.get(k);
    let out=s; const m=s.match(/^(\s*)([\s\S]*?)(\s*)$/); const c=m[2].replace(/\s+/g,' ');
    if(c&&L.test(c)){ let r=core(c);
      if(r===null){ r=c.replace(looseRe(),(x,pre,w)=>pre+I18N_D[w]); if(r===c) r=null; }
      if(r!==null) out=m[1]+r+m[3]; }
    out=num(out); cache.set(k,out); return out; };
})();
/* längere Nachrichten (Teilen, Kopieren): Zeile für Zeile übersetzen */
const trMsg=s=>LANG==='en'&&typeof s==='string'? s.split('\n').map(l=>tr(l)).join('\n') : s;
if(LANG==='en'){
  const ATTR=['placeholder','title','aria-label','alt'];
  const SKIP={SCRIPT:1,STYLE:1,TEXTAREA:1,NOSCRIPT:1};
  const done=new WeakMap();
  const doText=n=>{ const p=n.parentNode; if(!p||SKIP[p.nodeName]||p.isContentEditable) return; const v=n.data; if(done.get(n)===v) return; const t=tr(v); if(t!==v) n.data=t; done.set(n,n.data); };
  const doEl=el=>{ for(const a of ATTR){ const v=el.getAttribute&&el.getAttribute(a); if(v){ const t=tr(v); if(t!==v) el.setAttribute(a,t); } }
    if(el.nodeName==='INPUT'&&el.value){ if(/^(button|submit)$/i.test(el.type)){ const t=tr(el.value); if(t!==el.value) el.value=t; }
      else if(/^(text|search)$/i.test(el.type)&&document.activeElement!==el){ const k=el.value.replace(/\s+/g,' ').trim(); if(I18N_D[k]!==undefined) el.value=I18N_D[k]; } } };
  const walk=root=>{ if(root.nodeType===3) return doText(root); if(root.nodeType!==1||SKIP[root.nodeName]) return; doEl(root);
    const w=document.createTreeWalker(root,5); let n; while(n=w.nextNode()){ if(n.nodeType===3) doText(n); else if(!SKIP[n.nodeName]) doEl(n); } };
  walk(document.body||document.documentElement);
  new MutationObserver(ms=>{ for(const m of ms){
      if(m.type==='characterData') doText(m.target);
      else if(m.type==='attributes') doEl(m.target);
      else m.addedNodes.forEach(walk); } })
    .observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['placeholder','title','aria-label','alt']});
  const oc=window.confirm.bind(window), oa=window.alert.bind(window);
  window.confirm=m=>oc(trMsg(String(m))); window.alert=m=>oa(trMsg(String(m)));
  document.title=tr(document.title);
}


;

/* ===== Demo / Basis / Vollversion ===== */
const MC=(function(){ const H='muskel-coach-test-unlock-v1', TRIAL=10, D=864e5;
  /* Vollversion gilt 365 Tage ab Freischaltung (Master-Code: unbegrenzt) */
  const YEAR=365; let has=false, until=0, kind='';
  try{ has=testLocal.getItem('mc_unlock')===H; until=+testLocal.getItem('mc_unlock_until')||0; kind=testLocal.getItem('mc_unlock_kind')||''; }catch(e){}
  const ck2=(document.cookie.match(/(?:^|; )muskel_coach_test_uu=(\d+)/)||[])[1]; if(has&&ck2&&(!until||+ck2<until)) until=+ck2;
  if(has&&!until&&kind!=='master'){ until=Date.now()+YEAR*D; kind=kind||'code'; try{ testLocal.setItem('mc_unlock_until',String(until)); testLocal.setItem('mc_unlock_kind',kind); }catch(e){} }
  if(has&&until) try{ document.cookie='muskel_coach_test_uu='+until+';max-age=315360000;path='+testCookiePath+';SameSite=Strict;Secure'; }catch(e){}
  const unlocked=has&&(kind==='master'||Date.now()<until);
  const expired=has&&!unlocked;
  const daysLeft=kind==='master'?Infinity:Math.max(0,Math.ceil((until-Date.now())/D));
  let st=0; try{ st=+testLocal.getItem('mc_trial')||0; }catch(e){}
  const ck=(document.cookie.match(/(?:^|; )muskel_coach_test_trial=(\d+)/)||[])[1]; if(ck&&(!st||+ck<st)) st=+ck;
  if(!st) st=Date.now();
  const left=Math.max(0,TRIAL-Math.floor((Date.now()-st)/D));
  const o={H,TRIAL,YEAR,unlocked,expired,until,kind,daysLeft,start:st,left,trial:!unlocked&&!expired&&left>0,pro:unlocked||(!expired&&left>0)};
  /* Entwickler-Vorschau: nur auf freigeschalteten Geräten, nur zum Ansehen (kann nichts freischalten) */
  let pv=''; try{ pv=testLocal.getItem('mc_dev_view')||''; }catch(e){}
  o.real={unlocked,kind,until,daysLeft}; o.preview='';
  if(unlocked&&['basic','trial','expired','renew'].includes(pv)){ o.preview=pv;
    if(pv==='renew'){ o.kind='code'; o.daysLeft=5; o.until=Date.now()+5*D; }
    else { o.unlocked=false; o.expired=pv==='expired'; o.left=pv==='trial'?7:0; o.trial=pv==='trial'; o.pro=pv==='trial'; } }
  o.grant=(k)=>{ try{ testLocal.removeItem('mc_dev_view'); }catch(e){} const now=Date.now(); let u=k==='master'?0:Math.max(now,(unlocked&&kind!=='master'?until:0))+YEAR*D;
    try{ testLocal.setItem('mc_unlock',H); testLocal.setItem('mc_unlock_kind',k); if(u) testLocal.setItem('mc_unlock_until',String(u)); else testLocal.removeItem('mc_unlock_until'); testLocal.removeItem('mc_renew_pop'); testLocal.removeItem('mc_exp_seen'); }catch(e){}
    try{ document.cookie='muskel_coach_test_uu='+(u||'')+';max-age='+(u?315360000:0)+';path='+testCookiePath+';SameSite=Strict;Secure'; }catch(e){} return u; };
  const idbPut=v=>{ try{ const r=indexedDB.open(testKey('mc_meta'),1); r.onupgradeneeded=()=>r.result.createObjectStore('kv'); r.onsuccess=()=>{ try{ r.result.transaction('kv','readwrite').objectStore('kv').put(v,'trial'); }catch(e){} }; }catch(e){} };
  o.persist=(v,idb)=>{ try{ testLocal.setItem('mc_trial',String(v)); }catch(e){} try{ document.cookie='muskel_coach_test_trial='+v+';max-age=315360000;path='+testCookiePath+';SameSite=Strict;Secure'; }catch(e){} if(idb) idbPut(v); };
  o.persist(st,false);
  // Datenbank kann einen früheren Start kennen (z. B. wenn nur ein Teil gelöscht wurde)
  try{ const r=indexedDB.open(testKey('mc_meta'),1); r.onupgradeneeded=()=>r.result.createObjectStore('kv');
    r.onsuccess=()=>{ try{ const q=r.result.transaction('kv').objectStore('kv').get('trial'); q.onsuccess=()=>{ const v=+q.result||0;
      if(!v||v>st){ idbPut(st); return; }
      if(v<st){ o.persist(v,false); const nl=Math.max(0,TRIAL-Math.floor((Date.now()-v)/D)); if(!unlocked&&(nl>0)!==(left>0)) location.reload(); } }; }catch(e){} }; }catch(e){}
  return o; })();

/* ===== Nutzer-Zähler (anonym) & Einmal-Codes ===== */
let CNT_ERR='';
async function cntGet(key){ return Number(testLocal.getItem('counter/'+key))||0; }
async function cntHit(key){
  const value=(Number(testLocal.getItem('counter/'+key))||0)+1;
  testLocal.setItem('counter/'+key,String(value));
  return value;
}
function validCode(value){ return /^TEST-\d{6}$/.test(value); }
function makeCode(){
  const number=crypto.getRandomValues(new Uint32Array(1))[0]%1000000;
  return 'TEST-'+String(number).padStart(6,'0');
}
async function redeemCode(code){
  if(!validCode(code)||!navigator.locks) return 'invalid';
  return navigator.locks.request(testKey('redeem-code'),async()=>{
    const issued=JSON.parse(testLocal.getItem('mc_dev_codes')||'[]');
    if(!issued.some(entry=>entry.code===code)) return 'invalid';
    if(await cntGet('c-'+code)) return 'used';
    await cntHit('c-'+code);
    return 'ok';
  });
}
/* Land ermitteln – ohne IP-Adresse, nur aus Zeitzone/Spracheinstellung des Handys */
const CC_LIST=['DE','AT','CH','NL','BE','LU','FR','IT','ES','PT','PL','CZ','DK','SE','NO','FI','GB','IE','US','CA','TR','GR','HR','RS','BA','RO','HU','BG','UA','RU','AE','SA','MA','EG','IN','AU','BR','MX'];
const CC_NAMES={DE:'Deutschland',AT:'Österreich',CH:'Schweiz',NL:'Niederlande',BE:'Belgien',LU:'Luxemburg',FR:'Frankreich',IT:'Italien',ES:'Spanien',PT:'Portugal',PL:'Polen',CZ:'Tschechien',DK:'Dänemark',SE:'Schweden',NO:'Norwegen',FI:'Finnland',GB:'Großbritannien',IE:'Irland',US:'USA',CA:'Kanada',TR:'Türkei',GR:'Griechenland',HR:'Kroatien',RS:'Serbien',BA:'Bosnien',RO:'Rumänien',HU:'Ungarn',BG:'Bulgarien',UA:'Ukraine',RU:'Russland',AE:'VAE',SA:'Saudi-Arabien',MA:'Marokko',EG:'Ägypten',IN:'Indien',AU:'Australien',BR:'Brasilien',MX:'Mexiko',XX:'Andere'};
function myCountry(){ let tz=''; try{ tz=Intl.DateTimeFormat().resolvedOptions().timeZone||''; }catch(e){}
  const TZ={'Europe/Berlin':'DE','Europe/Busingen':'DE','Europe/Vienna':'AT','Europe/Zurich':'CH','Europe/Amsterdam':'NL','Europe/Brussels':'BE','Europe/Luxembourg':'LU','Europe/Paris':'FR','Europe/Rome':'IT','Europe/Madrid':'ES','Atlantic/Canary':'ES','Europe/Lisbon':'PT','Europe/Warsaw':'PL','Europe/Prague':'CZ','Europe/Copenhagen':'DK','Europe/Stockholm':'SE','Europe/Oslo':'NO','Europe/Helsinki':'FI','Europe/London':'GB','Europe/Dublin':'IE','Europe/Istanbul':'TR','Asia/Istanbul':'TR','Europe/Athens':'GR','Europe/Zagreb':'HR','Europe/Belgrade':'RS','Europe/Sarajevo':'BA','Europe/Bucharest':'RO','Europe/Budapest':'HU','Europe/Sofia':'BG','Europe/Kyiv':'UA','Europe/Kiev':'UA','Europe/Moscow':'RU','Asia/Dubai':'AE','Asia/Riyadh':'SA','Africa/Casablanca':'MA','Africa/Cairo':'EG','Asia/Kolkata':'IN','Asia/Calcutta':'IN'};
  let c=TZ[tz]; if(!c&&/^America\/(New_York|Chicago|Denver|Los_Angeles|Phoenix|Anchorage|Detroit|Indiana|Boise)/.test(tz)) c='US';
  if(!c&&/^America\/(Toronto|Vancouver|Edmonton|Winnipeg|Halifax|Regina|St_Johns|Montreal)/.test(tz)) c='CA';
  if(!c&&/^Australia\//.test(tz)) c='AU'; if(!c&&/^America\/(Sao_Paulo|Fortaleza|Recife|Bahia|Manaus|Belem)/.test(tz)) c='BR'; if(!c&&/^America\/(Mexico_City|Cancun|Monterrey|Tijuana|Merida)/.test(tz)) c='MX';
  if(!c){ const m=(navigator.language||'').match(/-([A-Z]{2})$/i); if(m&&CC_LIST.includes(m[1].toUpperCase())) c=m[1].toUpperCase(); }
  return c&&CC_LIST.includes(c)?c:'XX'; }
const ccFlag=c=>c==='XX'?'🌍':String.fromCodePoint(...[...c].map(x=>127397+x.charCodeAt(0)));
const ON_W=300000; let onLast=-1;
function onBucket(){ return Math.floor(Date.now()/ON_W); }
function onlinePing(){ try{ if(document.visibilityState!=='visible'||!navigator.onLine) return; const b=onBucket(); if(b===onLast) return; onLast=b; cntHit('on-'+b).then(v=>{ if(v===null) onLast=-1; }); }catch(e){} }
setTimeout(onlinePing,1500); setInterval(onlinePing,30000); document.addEventListener('visibilitychange',onlinePing);
(function trackCC(){ try{ if(!testLocal.getItem('mc_cc')){ const c=myCountry(); cntHit('cc-'+c).then(v=>{ if(v!==null) testLocal.setItem('mc_cc',c); }); } }catch(e){} })();
(function track(){ const today=new Date().toISOString().slice(0,10).replace(/-/g,'');
  try{ if(!testLocal.getItem('mc_counted')){ cntHit('users').then(v=>{ if(v!==null) testLocal.setItem('mc_counted','1'); }); }
    if(testLocal.getItem('mc_day')!==today){ cntHit('d-'+today).then(v=>{ if(v!==null) testLocal.setItem('mc_day',today); }); }
    if(MC.unlocked&&!testLocal.getItem('mc_cnt_pro')){ cntHit('pro-users').then(v=>{ if(v!==null) testLocal.setItem('mc_cnt_pro','1'); }); }
  }catch(e){} })();
/* Basis-Version (nach der 10-Tage-Demo): nur diese 3 Übungen, kein Trainingsplan, kein Training, kein Kalender */
const FREE_EX=['bankdruecken','kh-curls','kniebeuge'];
const PRO_FEATURES=[['🏋️','Alle 90 Übungen','statt nur 3 – inkl. Maschinen, Kabel- & Freihantel-Übungen'],['📋','Trainingsplan & Training','eigener Plan, geführtes Training mit Satz-Timer und Pausen'],['📅','Kalender','Trainingstage planen und abhaken'],['🧍','3D-Bodybuilder','360° drehbar aus jeder Perspektive, Muskeln leuchten, 14 Looks – Männer, Frauen, Anatomie & Pro Athlet'],
  ['🏆','Rekord-Speicher','merkt sich dein schwerstes Gewicht & feiert jeden neuen Rekord'],['📈','Fortschritt','Statistik, Körper & Maße, Fortschrittsfotos, 21 Abzeichen'],
  ['🔥','Grenztest & Profi-Helfer','Maximalkraft testen, Scheiben-Rechner, Aufwärmsätze im Training']];
const isLocked=e=>!MC.pro&&!!e&&!FREE_EX.includes(e.id);
function upsell(why){ if(window.MC_GATE) window.MC_GATE.show(MC.trial?'trial':'basic',why); }
/* Glückwunsch-Fenster mit Konfetti nach dem Freischalten */
function celebrateUnlock(until,reload){
  const ov=document.createElement('div'); ov.className='confpop';
  const dt=until?new Date(until).toLocaleDateString(LANG==='en'?'en-GB':'de-DE'):'';
  const days=until?Math.max(1,Math.round((until-Date.now())/864e5)):0;
  ov.innerHTML=`<canvas></canvas><div class="confbox"><div class="confem">🎉</div><h2>Glückwunsch!</h2>
    <p class="confbig">${until?`Du hast jetzt <b>${days} Tage</b> die Vollversion`:'Deine Vollversion ist <b>unbegrenzt</b> freigeschaltet'}</p>
    ${until?`<p class="confsub">Gültig bis <b>${dt}</b> · alle Übungen, Trainingsplan, 3D-Coach & mehr</p>`:''}
    <button class="savebtn" type="button">💪 Los geht's</button></div>`;
  document.body.appendChild(ov); document.body.style.overflow='hidden';
  const cv=ov.querySelector('canvas'), cx=cv.getContext('2d'), dpr=Math.min(2,devicePixelRatio||1);
  const fit=()=>{ cv.width=innerWidth*dpr; cv.height=innerHeight*dpr; }; fit();
  const COL=['#c6ff3d','#ff6a1f','#7fe0c4','#ffd23f','#ff4d6d','#8b6cff','#ffffff'];
  const P=[]; const burst=(n)=>{ for(let i=0;i<n;i++) P.push({x:innerWidth*(0.15+Math.random()*0.7),y:-20-Math.random()*innerHeight*0.4,vx:(Math.random()-.5)*3,vy:2+Math.random()*3,
    r:Math.random()*6.28,vr:(Math.random()-.5)*0.3,w:6+Math.random()*6,h:8+Math.random()*8,c:COL[i%COL.length]}); };
  burst(170); setTimeout(()=>burst(110),900);
  let run=true, t0=performance.now();
  (function tick(){ if(!run) return; cx.setTransform(dpr,0,0,dpr,0,0); cx.clearRect(0,0,innerWidth,innerHeight);
    for(const q of P){ q.vy+=0.05; q.vx*=0.99; q.x+=q.vx+Math.sin((q.y+q.r*40)/40)*0.6; q.y+=q.vy; q.r+=q.vr;
      if(q.y<innerHeight+30){ cx.save(); cx.translate(q.x,q.y); cx.rotate(q.r); cx.fillStyle=q.c; cx.fillRect(-q.w/2,-q.h/2,q.w,q.h*Math.abs(Math.cos(q.r*1.7))+1); cx.restore(); } }
    if(performance.now()-t0<7000) requestAnimationFrame(tick); else cx.clearRect(0,0,innerWidth,innerHeight); })();
  try{ navigator.vibrate&&navigator.vibrate([60,40,120]); }catch(e){}
  ov.querySelector('button').onclick=()=>{ run=false; if(reload) location.reload(); else { ov.remove(); document.body.style.overflow=''; } };
}
function proTeaser(title){ return `<div class="teaser"><div class="tlock">🔒</div><h3>${title}</h3><p>Diese Funktion gehört zur <b>Vollversion</b> – 1 Jahr alles für nur ${typeof priceTag==="function"?priceTag():"<b>4,99 €</b>"}.</p>
  <ul>${PRO_FEATURES.map(f=>`<li><i>${f[0]}</i><div><b>${f[1]}</b><small>${f[2]}</small></div></li>`).join('')}</ul><button class="savebtn" onclick="upsell()">Vollversion holen</button></div>`; }
/* ============ Figuren-Engine ============ */
const S = {hd:[100,46],sh:[100,64],el:[101,90],ha:[102,115],hp:[100,115],kn:[101,150],ft:[100,184],to:[113,184]};
const F = {hd:[100,44],nk:[100,60],shL:[85,64],shR:[115,64],elL:[81,90],haL:[79,114],elR:[119,90],haR:[121,114],
           pv:[100,113],hpL:[91,115],hpR:[109,115],knL:[90,150],knR:[110,150],ftL:[89,184],ftR:[111,184]};
const SIDE = [['hd','sh'],['sh','hp'],['hp','kn'],['kn','ft'],['ft','to'],['sh','el'],['el','ha']];
const FRONT = [['hd','nk'],['shL','shR'],['nk','pv'],['hpL','hpR'],['hpL','knL'],['knL','ftL'],['hpR','knR'],['knR','ftR'],['shL','elL'],['elL','haL'],['shR','elR'],['elR','haR']];
const LUNGE = [['hd','sh'],['sh','hp'],['hp','kn2'],['kn2','ft2'],['ft2','to2'],['hp','kn'],['kn','ft'],['ft','to'],['sh','el'],['el','ha']];

const cp = o => JSON.parse(JSON.stringify(o));
const P = (base,o) => Object.assign(cp(base), o||{});
const arms = (el,ha) => ({elL:el,haL:ha,elR:[200-el[0],el[1]],haR:[200-ha[0],ha[1]]});
/* Arme mit Tiefe (3. Wert = wie weit vor dem Körper) + leicht nach vorn geneigter Oberkörper */
const armsZ = (el,ha) => ({elL:el,haL:ha,elR:[200-el[0],el[1],el[2]||0],haR:[200-ha[0],ha[1],ha[2]||0]});
const LEAN = {hd:[100,45,12],nk:[100,60,9],shL:[85,64,7],shR:[115,64,7]};
const shift = (pose,dy,keep=[]) => { const r=cp(pose); for(const k in r) if(!keep.includes(k)) r[k][1]+=dy; return r; };

const benchFlat = '<rect x="44" y="128" width="98" height="7" rx="3" fill="#3b4249"/><path d="M56 135V184M130 135V184" stroke="#3b4249" stroke-width="5"/>';
const benchLow  = '<rect x="48" y="120" width="44" height="7" rx="3" fill="#3b4249"/><path d="M54 127V184M86 127V184" stroke="#3b4249" stroke-width="5"/>';
const benchSeat = '<rect x="58" y="128" width="54" height="7" rx="3" fill="#3b4249"/><path d="M66 135V184M104 135V184" stroke="#3b4249" stroke-width="5"/>';
const benchIncl = '<path d="M56 92L112 140H150" stroke="#3b4249" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M120 142V184M146 142V184" stroke="#3b4249" stroke-width="5"/>';
const pullbar = y => `<path d="M40 ${y}H160" stroke="#8a949b" stroke-width="5" stroke-linecap="round"/><path d="M44 ${y}V0M156 ${y}V0" stroke="#3b4249" stroke-width="4"/>`;
const dipbars = '<path d="M94 74H132" stroke="#8a949b" stroke-width="6" stroke-linecap="round"/><path d="M126 74V184" stroke="#3b4249" stroke-width="5"/>';
const tower = x => `<rect x="${x}" y="0" width="10" height="184" fill="#3a4146"/>`;
const hipBench = '<rect x="26" y="120" width="48" height="8" rx="3" fill="#3b4249"/><path d="M34 128V184M66 128V184" stroke="#3b4249" stroke-width="5"/>';

const T = {
  bench:{view:'s', statics:benchFlat,
    A:P(S,{hd:[48,117],sh:[64,122],hp:[122,124],kn:[148,112],ft:[160,184],to:[172,184],el:[76,142],ha:[70,113]}),
    B:P(S,{hd:[48,117],sh:[64,122],hp:[122,124],kn:[148,112],ft:[160,184],to:[172,184],el:[66,96],ha:[66,70]})},
  incline:{view:'s', statics:benchIncl,
    A:P(S,{hd:[64,88],sh:[76,104],hp:[116,134],kn:[146,124],ft:[156,184],to:[168,184],el:[92,124],ha:[86,98]}),
    B:P(S,{hd:[64,88],sh:[76,104],hp:[116,134],kn:[146,124],ft:[156,184],to:[168,184],el:[80,78],ha:[82,52]})},
  flyF:{view:'f', cables:[[8,18],[192,18]], statics:tower(0)+tower(190),
    eqZ:-0.38, A:P(F,Object.assign({},LEAN,armsZ([64,63,3],[44,60,9]))), B:P(F,Object.assign({},LEAN,armsZ([82,78,26],[97,84,44])))},
  pushup:{view:'s',
    A:P(S,{hd:[152,120],sh:[138,128],el:[139,155],ha:[140,183],hp:[90,147],kn:[64,161],ft:[40,177],to:[34,184]}),
    B:P(S,{hd:[152,152],sh:[138,160],el:[116,158],ha:[140,183],hp:[90,170],kn:[64,175],ft:[40,180],to:[34,184]})},
  climber:{view:'s',
    A:P(S,{hd:[152,120],sh:[138,128],el:[139,155],ha:[140,183],hp:[90,147],kn:[64,161],ft:[40,177],to:[34,184]}),
    B:P(S,{hd:[152,120],sh:[138,128],el:[139,155],ha:[140,183],hp:[92,145],kn:[116,160],ft:[98,176],to:[92,184]})},
  dip:{view:'s', statics:dipbars,
    A:P(S,{hd:[106,4],sh:[108,22],el:[110,48],ha:[112,74],hp:[100,74],kn:[112,107],ft:[92,135],to:[86,140]}),
    B:P(S,{hd:[112,34],sh:[113,52],el:[88,62],ha:[112,74],hp:[102,102],kn:[114,135],ft:[94,163],to:[88,168]})},
  benchdip:{view:'s', statics:benchLow,
    A:P(S,{hd:[84,52],sh:[84,70],el:[84,95],ha:[84,120],hp:[90,122],kn:[130,128],ft:[160,184],to:[166,175]}),
    B:P(S,{hd:[88,80],sh:[88,98],el:[62,104],ha:[84,120],hp:[92,150],kn:[130,146],ft:[160,184],to:[166,175]})},
  ohpF:{view:'f', A:P(F,arms([68,80],[70,56])), B:P(F,arms([78,38],[82,14]))},
  latF:{view:'f', A:P(F,arms([80,90],[77,114])), B:P(F,arms([60,66],[36,64]))},
  frontS:{view:'s', A:P(S,{el:[102,90],ha:[104,115]}), B:P(S,{el:[126,62],ha:[152,60]})},
  facepull:{view:'s', cable:[188,60], statics:tower(188),
    A:P(S,{el:[126,64],ha:[150,62]}), B:P(S,{el:[76,58],ha:[98,42]})},
  shrugF:{view:'f', A:P(F), B:P(F,{nk:[100,56],shL:[85,55],shR:[115,55],elL:[81,81],haL:[79,105],elR:[119,81],haR:[121,105]})},
  uprowF:{view:'f', A:P(F,armsZ([84,90,5],[94,112,11])), B:P(F,armsZ([64,58,2],[91,70,13]))},
  neckS:{view:'s', A:P(S,{hd:[94,46]}), B:P(S,{hd:[111,53]})},
  neckF:{view:'f', A:P(F,{hd:[90,47]}), B:P(F,{hd:[110,47]})},
  crunch:{view:'s',
    A:P(S,{hd:[36,172],sh:[54,174],el:[66,166],ha:[56,165],hp:[104,178],kn:[132,148],ft:[150,184],to:[162,184]}),
    B:P(S,{hd:[48,139],sh:[63,149],el:[78,160],ha:[67,152],hp:[104,178],kn:[132,148],ft:[150,184],to:[162,184]})},
  legraise:{view:'s', statics:pullbar(14),
    A:P(S,{hd:[108,49],ha:[100,16],el:[100,40],sh:[100,64],hp:[100,115],kn:[100,148],ft:[100,180],to:[110,182]}),
    B:P(S,{hd:[108,49],ha:[100,16],el:[100,40],sh:[100,64],hp:[96,112],kn:[130,100],ft:[134,134],to:[145,136]})},
  plank:{view:'s', hold:true,
    A:P(S,{hd:[150,150],sh:[136,158],el:[138,184],ha:[160,184],hp:[88,166],kn:[62,172],ft:[38,178],to:[32,184]}),
    B:P(S,{hd:[150,149],sh:[136,157],el:[138,184],ha:[160,184],hp:[88,163],kn:[62,171],ft:[38,178],to:[32,184]})},
  curl:{view:'s', A:P(S,{el:[102,90],ha:[104,115]}), B:P(S,{el:[103,90],ha:[122,74]})},
  conc:{view:'s', statics:benchSeat,
    oneHand:true,
    A:P(S,{hp:[90,128],kn:[126,128],ft:[130,184],to:[142,184],sh:[112,86],hd:[124,72],el:[118,121],ha:[121,146],el2:[114,112],ha2:[126,122],lw:[15,14],lw2:[30,28],lwl:[26,30]}),
    B:P(S,{hp:[90,128],kn:[126,128],ft:[130,184],to:[142,184],sh:[112,86],hd:[124,72],el:[118,121],ha:[124,100],el2:[114,112],ha2:[126,122],lw:[15,16],lw2:[30,28],lwl:[26,30]})},
  pushdown:{view:'s', cable:[126,0], statics:'',
    A:P(S,{el:[102,90],ha:[124,76]}), B:P(S,{el:[102,90],ha:[106,115]})},
  overhead:{view:'s', A:P(S,{el:[106,38],ha:[86,52]}), B:P(S,{el:[106,38],ha:[108,13]})},
  pullupF:{view:'f', statics:pullbar(20),
    A:P(F,{hd:[100,48],nk:[100,62],shL:[85,66],shR:[115,66],elL:[80,43],haL:[76,20],elR:[120,43],haR:[124,20],pv:[100,115],hpL:[91,117],hpR:[109,117],knL:[90,150],knR:[110,150],ftL:[93,180],ftR:[107,180]}),
    B:null},
  latpullF:{view:'f', cableMid:[100,0], statics:'<rect x="70" y="138" width="60" height="8" rx="3" fill="#3b4249"/><path d="M100 146V184" stroke="#3b4249" stroke-width="5"/><rect x="72" y="126" width="56" height="6" rx="3" fill="#3b4249"/>',
    A:P(F,{hd:[100,64],nk:[100,80],shL:[85,84],shR:[115,84],pv:[100,135],hpL:[90,137],hpR:[110,137],knL:[86,150],ftL:[86,184],knR:[114,150],ftR:[114,184],...arms([76,60],[70,36])}),
    B:P(F,{hd:[100,64],nk:[100,80],shL:[85,84],shR:[115,84],pv:[100,135],hpL:[90,137],hpR:[110,137],knL:[86,150],ftL:[86,184],knR:[114,150],ftR:[114,184],...arms([64,100],[74,78])})},
  row:{view:'s',
    A:P(S,{hd:[152,72],sh:[138,82],el:[139,108],ha:[140,134],hp:[90,112],kn:[110,146],ft:[98,184],to:[110,184]}),
    B:P(S,{hd:[152,72],sh:[138,82],el:[114,92],ha:[124,116],hp:[90,112],kn:[110,146],ft:[98,184],to:[110,184]})},
  deadlift:{view:'s',
    A:P(S,{hp:[78,132],sh:[118,100],hd:[132,92],kn:[116,148],ft:[100,184],to:[112,184],el:[118,126],ha:[118,152]}),
    B:P(S)},
  rdl:{view:'s',
    A:P(S,{hp:[80,118],sh:[124,92],hd:[138,86],kn:[104,150],ft:[100,184],to:[112,184],el:[124,118],ha:[124,144]}),
    B:P(S)},
  squat:{view:'s', barAt:'br',
    A:P(S,{el:[90,80],ha:[98,62],br:[95,60]}),
    B:P(S,{hp:[70,134],kn:[116,138],sh:[98,92],hd:[110,76],el:[88,108],ha:[96,90],br:[93,88]})},
  lunge:{view:'s', segs:LUNGE,
    A:P(S,{kn2:[99,150],ft2:[98,184],to2:[110,184]}),
    B:P(S,{hp:[100,140],sh:[100,89],hd:[100,71],el:[101,115],ha:[102,140],kn:[134,142],ft:[134,184],to:[146,184],kn2:[84,176],ft2:[60,174],to2:[72,184]})},
  calf:{view:'s', statics:'<rect x="86" y="182" width="40" height="5" fill="#3b4249"/>', A:P(S), B:shift(S,-9,['to'])},
  hipthrust:{view:'s', statics:hipBench,
    A:P(S,{hd:[46,110],sh:[62,122],hp:[90,156],kn:[134,140],ft:[146,184],to:[158,184],el:[74,144],ha:[90,154]}),
    B:P(S,{hd:[46,110],sh:[62,122],hp:[104,128],kn:[140,140],ft:[146,184],to:[158,184],el:[82,124],ha:[102,126]})},
  chestM:{view:'s', statics:'<rect x="62" y="66" width="8" height="62" rx="3" fill="#3b4249"/><rect x="62" y="128" width="50" height="7" rx="3" fill="#3b4249"/><path d="M86 135V184" stroke="#3b4249" stroke-width="5"/>',
    A:P(S,{hp:[80,126],sh:[80,74],hd:[82,56],kn:[120,128],ft:[122,184],to:[134,184],el:[64,94],ha:[90,88]}),
    B:P(S,{hp:[80,126],sh:[80,74],hd:[82,56],kn:[120,128],ft:[122,184],to:[134,184],el:[105,80],ha:[131,80]})},
  ohpSeatF:{view:'f', statics:'<rect x="70" y="138" width="60" height="8" rx="3" fill="#3b4249"/><path d="M100 146V184" stroke="#3b4249" stroke-width="5"/>',
    A:P(F,{hd:[100,64],nk:[100,80],shL:[85,84],shR:[115,84],pv:[100,135],hpL:[90,137],hpR:[110,137],knL:[86,150,30],ftL:[86,184,34],knR:[114,150,30],ftR:[114,184,34],...arms([68,100],[70,76])}),
    B:P(F,{hd:[100,64],nk:[100,80],shL:[85,84],shR:[115,84],pv:[100,135],hpL:[90,137],hpR:[110,137],knL:[86,150,30],ftL:[86,184,34],knR:[114,150,30],ftR:[114,184,34],...arms([78,58],[82,34])})},
  revflyF:{view:'f', A:P(F,armsZ([82,76,22],[97,72,42])), B:P(F,armsZ([62,66,3],[38,64,4]))},
  cablerow:{view:'s', cable:[188,150], statics:'<rect x="48" y="148" width="62" height="7" rx="3" fill="#3b4249"/><path d="M58 155V184M100 155V184" stroke="#3b4249" stroke-width="5"/><rect x="150" y="140" width="6" height="44" fill="#3b4249"/>'+tower(186),
    A:P(S,{hp:[78,146],sh:[86,96],hd:[92,79],kn:[118,128],ft:[146,152],to:[150,140],el:[110,104],ha:[136,112]}),
    B:P(S,{hp:[78,146],sh:[80,96],hd:[82,78],kn:[118,128],ft:[146,152],to:[150,140],el:[58,108],ha:[84,116]})},
  legpress:{view:'s', statics:'<path d="M28 100L78 152H104" stroke="#3b4249" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M84 154V184M100 154V184" stroke="#3b4249" stroke-width="5"/><path d="M104 150L186 88" stroke="#3a4146" stroke-width="4"/>',
    plat:true,
    A:P(S,{hd:[38,98],sh:[52,112],hp:[86,148],el:[66,138],ha:[82,152],kn:[98,106],ft:[124,128],to:[117,118]}),
    B:P(S,{hd:[38,98],sh:[52,112],hp:[86,148],el:[66,138],ha:[82,152],kn:[120,124],ft:[152,102],to:[145,92]})},
  legext:{view:'s', pad:true, statics:'<rect x="62" y="66" width="8" height="62" rx="3" fill="#3b4249"/><rect x="62" y="128" width="62" height="7" rx="3" fill="#3b4249"/><path d="M80 135V184" stroke="#3b4249" stroke-width="5"/>',
    A:P(S,{hp:[80,126],sh:[80,74],hd:[82,56],el:[86,100],ha:[96,124],kn:[122,128],ft:[126,172],to:[138,174]}),
    B:P(S,{hp:[80,126],sh:[80,74],hd:[82,56],el:[86,100],ha:[96,124],kn:[122,128],ft:[166,124],to:[168,112]})},
  legcurl:{view:'s', pad:true, statics:'<rect x="62" y="66" width="8" height="62" rx="3" fill="#3b4249"/><rect x="62" y="128" width="62" height="7" rx="3" fill="#3b4249"/><path d="M80 135V184" stroke="#3b4249" stroke-width="5"/>',
    A:P(S,{hp:[80,126],sh:[80,74],hd:[82,56],el:[86,100],ha:[96,124],kn:[122,128],ft:[166,124],to:[168,112]}),
    B:P(S,{hp:[80,126],sh:[80,74],hd:[82,56],el:[86,100],ha:[96,124],kn:[122,128],ft:[110,168],to:[121,172]})},
  walk:{view:'s', segs:LUNGE, cont:'<b>●</b> Zügig gehen · ca. 4 km/h', statics:'<rect x="34" y="178" width="140" height="8" rx="4" fill="#3a4146"/><path d="M160 178L150 96M150 96L132 100" stroke="#3b4249" stroke-width="5" stroke-linecap="round" fill="none"/><rect x="142" y="88" width="16" height="10" rx="2" fill="#3b4249"/>',
    A:P(S,{hd:[100,40],sh:[100,58],hp:[100,108],el:[94,84],ha:[96,106],kn:[110,142],ft:[118,172],to:[130,174],kn2:[94,142],ft2:[84,170],to2:[94,176]}),
    B:P(S,{hd:[100,40],sh:[100,58],hp:[100,108],el:[106,84],ha:[118,100],kn:[94,142],ft:[84,170],to:[94,176],kn2:[110,142],ft2:[118,172],to2:[130,174]})},
  flexF:{view:'f',
    A:P(F,{...arms([62,66],[52,44]),shL:[84,64],shR:[116,64]}),
    B:P(F,{...arms([56,58],[67,36]),shL:[84,62],shR:[116,62],nk:[100,59]})},
  cablecurl:{view:'s', cable:[124,184], A:P(S,{el:[102,90],ha:[104,115]}), B:P(S,{el:[103,90],ha:[122,74]})},
};
T.standF={view:'f',A:P(F),B:P(F)}; T.standB={view:'b',A:P(F),B:P(F)};
T.pullupF.B = shift(T.pullupF.A,-36); Object.assign(T.pullupF.B, arms([64,42],[76,20])); T.pullupF.B.shL=[85,30]; T.pullupF.B.shR=[115,30];

T.ropecurl=Object.assign({},T.cablecurl,{A:Object.assign({},T.cablecurl.A,{lw:[19,8]}),B:Object.assign({},T.cablecurl.B,{lw:[19,11]})});
for(const k of ['pullupF','latpullF','shrugF','revflyF']) T[k.replace(/F$/,'B')]=Object.assign({},T[k],{view:'b'});
const ease = x => 0.5 - 0.5*Math.cos(Math.PI*x);
function poseAt(tp, ph){ // ph 0..1 -> Anteil Richtung B
  const o={}; for(const k in tp.A){ const a=tp.A[k], b=(tp.B[k]||a); o[k]=[a[0]+(b[0]-a[0])*ph, a[1]+(b[1]-a[1])*ph]; if(a.length>2||b.length>2) o[k].push((a[2]||0)+((b[2]||0)-(a[2]||0))*ph); } return o;
}
const L=(p,q,w,c)=>`<line x1="${p[0].toFixed(1)}" y1="${p[1].toFixed(1)}" x2="${q[0].toFixed(1)}" y2="${q[1].toFixed(1)}" stroke="${c}" stroke-width="${w}" stroke-linecap="round"/>`;
/* ---- Anatomie-Renderer v2 ---- */
const f1=n=>(+n).toFixed(1);
const STOP_B='<stop offset="0" stop-color="#ffffff"/><stop offset=".28" stop-color="#eef1f4"/><stop offset=".7" stop-color="#aeb7bf"/><stop offset="1" stop-color="#6c757e"/>';
const STOP_H='<stop offset="0" stop-color="#ffd9b0"/><stop offset=".28" stop-color="#ff9a48"/><stop offset=".72" stop-color="#e5531b"/><stop offset="1" stop-color="#97300c"/>';
const STOP_S='<stop offset="0" stop-color="#40464d"/><stop offset=".4" stop-color="#1d2024"/><stop offset="1" stop-color="#090a0c"/>';
const STOP_M='<stop offset="0" stop-color="#5b636b"/><stop offset=".35" stop-color="#2a2f34"/><stop offset="1" stop-color="#121417"/>';
const EDGE='#8a959e', SEAM='#9fe3ff';
const W={ 'hd-sh':[10,15,0,0],'sh-hp':[31,22,3,3],'hp-kn':[21,12,3,2],'hp-kn2':[21,12,3,2],'kn-ft':[12,7,4,1],'kn2-ft2':[12,7,4,1],
  'ft-to':[7,5,0,0],'ft2-to2':[7,5,0,0],'sh-el':[14,10,3,4],'el-ha':[11,7,3,1],
  'hd-nk':[10,15,0,0],'hpL-knL':[22,12,3,3],'hpR-knR':[22,12,3,3],'knL-ftL':[12,7,3,2],'knR-ftR':[12,7,2,3],
  'shL-elL':[14,10,4,3],'shR-elR':[14,10,3,4],'elL-haL':[11,7,3,1],'elR-haR':[11,7,1,3] };
const PART={'sh-el':'upperarm','shL-elL':'upperarm','shR-elR':'upperarm','el-ha':'forearm','elL-haL':'forearm','elR-haR':'forearm',
  'hp-kn':'thigh','hp-kn2':'thigh','hpL-knL':'thigh','hpR-knR':'thigh','kn-ft':'shank','kn2-ft2':'shank','knL-ftL':'shank','knR-ftR':'shank',
  'hd-sh':'neck','hd-nk':'neck'};
const HLG={brust:['chest'],schultern:['delt'],nacken:['trap','neck'],bauch:['abs','oblique'],bizeps:['bicep'],trizeps:['tricep'],ruecken:['back','lat'],
  beine:['quad','ham','calf'],po:['glute'],cardio:['quad','calf']};
const HLX={'wadenheben':['calf'],'beinstrecker':['quad'],'beinbeuger':['ham'],'face-pulls':['delt','back'],'reverse-butterfly':['delt','back'],
  'kreuzheben':['back','erector','glute','ham'],'rumaenisches-kreuzheben':['ham','glute','erector'],'hip-thrust':['glute'],'klimmzuege':['lat','back'],
  'aufrechtes-rudern':['trap','delt'],'dips':['chest','tricep'],'bankdips':['tricep'],'enge-liegestuetze':['tricep','chest'],'kniebeuge':['quad','glute'],
  'ausfallschritte':['quad','glute'],'beinpresse':['quad','glute'],'hammer-curls':['bicep','forearm'],'shrugs':['trap'],'nackenbeugen':['neck'],'nacken-seitlich':['neck'],
  'unterarmstuetz':['abs','oblique'],'mountain-climbers':['abs','quad'],'beinheben-haengend':['abs'],'crunches':['abs'],'frontheben':['delt'],'seitheben':['delt']};
const MUS_S={chest:'Brust',abs:'Bauch',oblique:'Seitl. Bauch',lat:'Breiter Rücken',back:'Oberer Rücken',erector:'Unterer Rücken',trap:'Nacken',glute:'Po',delt:'Schulter',bicep:'Bizeps',tricep:'Trizeps',forearm:'Unterarm',quad:'Oberschenkel',ham:'Beinbeuger',calf:'Wade',neck:'Hals'};
const LAT_N={chest:'Pectoralis major',abs:'Rectus abdominis',oblique:'Obliquus externus',lat:'Latissimus dorsi',back:'Rhomboideus',erector:'Erector spinae',trap:'Trapezius',glute:'Gluteus maximus',delt:'Deltoideus',bicep:'Biceps brachii',tricep:'Triceps brachii',forearm:'Unterarm-Flexoren',quad:'Quadriceps femoris',ham:'Biceps femoris',calf:'Gastrocnemius',neck:'Sternocleidomastoideus'};
const hlOf=ex=>new Set(ex.hl||HLX[ex.id]||HLG[(ex.g||[])[0]]||[]);
/* Hilfsmuskeln aus dem Text „Neben“ ableiten (für den Anatomie-Look: rosa) */
const SEC_MAP=[[/Trizeps/,'tricep'],[/Bizeps|Oberarmmuskel|Brachialis|Oberarmspeichen/,'bicep'],[/Schulter|Rotatoren/,'delt'],[/Unterarm|Griff/,'forearm'],
  [/Latissimus/,'lat'],[/oberer Rücken|mittlerer Rücken|Rücken,|Rücken$/,'back'],[/unterer Rücken|Rückenstrecker/,'erector'],[/Trapez|Nacken/,'trap'],
  [/\bPo\b|Gesäß/,'glute'],[/Beinbeuger|hinterer Oberschenkel/,'ham'],[/Oberschenkel(?! hinten)|vorderer Oberschenkel|Beine/,'quad'],[/Wade/,'calf'],
  [/Bauch|Rumpf/,'abs'],[/schräg/i,'oblique'],[/Brust|Sägezahn/,'chest']];
const secOf=ex=>{ const t=(ex.sec||'')+''; const H=hlOf(ex), o=new Set(); for(const [re,k] of SEC_MAP) if(re.test(t)&&!H.has(k)) o.add(k); return o; };

function figure(ex, ph){
  const tp=T[ex.anim], p=poseAt(tp,ph), H=hlOf(ex), uid='u'+(figure.n=(figure.n||0)+1);
  let defs='', gi=0;
  const hot=k=>H.has(k);
  const ST=k=>hot(k)?STOP_H:STOP_B;
  const grad=(e1,e2,stops)=>{ const id=uid+'g'+(gi++); if((e2[0]-e1[0])+(e2[1]-e1[1])<0){const t=e1;e1=e2;e2=t;}
    defs+=`<linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="${f1(e1[0])}" y1="${f1(e1[1])}" x2="${f1(e2[0])}" y2="${f1(e2[1])}">${stops}</linearGradient>`; return `url(#${id})`; };
  const fib=ang=>{ const id=uid+'f'+(gi++); defs+=`<pattern id="${id}" patternUnits="userSpaceOnUse" width="2.6" height="2.6" patternTransform="rotate(${f1(ang)})"><line x1="0" y1="0" x2="0" y2="2.6" stroke="#7a2306" stroke-width=".55" opacity=".55"/></pattern>`; return `url(#${id})`; };
  const stk=st=>st===STOP_H?`stroke="${SEAM}" stroke-width="1" filter="url(#${uid}hg)"`:`stroke="${EDGE}" stroke-width=".45"`;
  // Fläche mit optionalen Fasern
  const shape=(d,stops,g1,g2,fang)=>`<path d="${d}" fill="${grad(g1,g2,stops)}" ${stk(stops)}/>`+(stops===STOP_H?`<path d="${d}" fill="${fib(fang||0)}"/>`:'');
  const lerp=(a,b,t)=>[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];
  const nrm=(a,b)=>{const dx=b[0]-a[0], dy=b[1]-a[1], l=Math.hypot(dx,dy)||1; return [-dy/l,dx/l,dx/l,dy/l,l];};
  const ang=(a,b)=>Math.atan2(b[1]-a[1],b[0]-a[0])*180/Math.PI;
  const P2=(x,y)=>f1(x)+' '+f1(y);
  const limb=(a,b,w1,w2,b1,b2,stops)=>{
    const [nx,ny]=nrm(a,b), m=lerp(a,b,.5), wm=(w1+w2)/4;
    const a1=[a[0]+nx*w1/2,a[1]+ny*w1/2], a2=[a[0]-nx*w1/2,a[1]-ny*w1/2], c1=[b[0]+nx*w2/2,b[1]+ny*w2/2], c2=[b[0]-nx*w2/2,b[1]-ny*w2/2];
    const k1=[m[0]+nx*(wm+b1*2),m[1]+ny*(wm+b1*2)], k2=[m[0]-nx*(wm+b2*2),m[1]-ny*(wm+b2*2)];
    const d=`M${P2(...a1)}Q${P2(...k1)} ${P2(...c1)}A${f1(w2/2)} ${f1(w2/2)} 0 0 0 ${P2(...c2)}Q${P2(...k2)} ${P2(...a2)}A${f1(w1/2)} ${f1(w1/2)} 0 0 0 ${P2(...a1)}Z`;
    return shape(d,stops,[m[0]+nx*(wm+b1),m[1]+ny*(wm+b1)],[m[0]-nx*(wm+b2),m[1]-ny*(wm+b2)],ang(a,b)+90);
  };
  // Muskelbauch (Linse) entlang eines Segments
  const lens=(a,b,t0,t1,w,off,stops)=>{
    const [nx,ny]=nrm(a,b), s=lerp(a,b,t0), e=lerp(a,b,t1), m=lerp(s,e,.5);
    const p0=[s[0]+nx*off,s[1]+ny*off], p1=[e[0]+nx*off,e[1]+ny*off];
    const cA=[m[0]+nx*(off+w),m[1]+ny*(off+w)], cB=[m[0]+nx*(off-w),m[1]+ny*(off-w)];
    return shape(`M${P2(...p0)}Q${P2(...cA)} ${P2(...p1)}Q${P2(...cB)} ${P2(...p0)}Z`,stops,cA,cB,ang(a,b)+90);
  };
  const ell=(c,rx,ry,an,stops)=>{ const r=Math.max(rx,ry), t=an*Math.PI/180, ca=Math.cos(t), sa=Math.sin(t);
    const pt=(x,y)=>[c[0]+x*ca-y*sa, c[1]+x*sa+y*ca];
    const q=[pt(rx,0),pt(0,ry),pt(-rx,0),pt(0,-ry)];
    const d=`M${P2(...q[0])}A${f1(rx)} ${f1(ry)} ${f1(an)} 0 1 ${P2(...q[2])}A${f1(rx)} ${f1(ry)} ${f1(an)} 0 1 ${P2(...q[0])}Z`;
    return shape(d,stops,[c[0]-r*.7,c[1]-r*.7],[c[0]+r*.7,c[1]+r*.7],an+90); };
  const PHOT={upperarm:['upperarm','bicep','tricep'],forearm:['forearm'],thigh:['thigh','quad','ham'],shank:['shank','calf'],neck:['neck']};
  const seg=(a,b)=>{ const w=W[a+'-'+b]; if(!w) return ''; const pt=PART[a+'-'+b]; const hh=(PHOT[pt]||[pt]).some(k=>hot(k)); return limb(p[a],p[b],w[0],w[1],w[2],w[3],hh?STOP_H:STOP_B); };
  const head=(hd,base)=>{ const an=ang(base,hd)+90; return ell(hd,9,11.4,an,STOP_B); };
  const metal=(c,r)=>`<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${r}" fill="${grad([c[0]-r,c[1]-r],[c[0]+r,c[1]+r],STOP_M)}" stroke="#8c969e" stroke-width="1.4"/><circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r*.5)}" fill="none" stroke="#454c53" stroke-width="1.2"/><circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="2.4" fill="#c9ced2"/>`;
  const dbFront=c=>`<line x1="${f1(c[0]-11)}" y1="${f1(c[1])}" x2="${f1(c[0]+11)}" y2="${f1(c[1])}" stroke="#aab2b8" stroke-width="3"/>`+[-1,1].map(s=>`<rect x="${f1(c[0]+s*12-4)}" y="${f1(c[1]-8)}" width="8" height="16" rx="2.5" fill="${grad([c[0]+s*12-4,c[1]-8],[c[0]+s*12+4,c[1]+8],STOP_M)}" stroke="#8c969e" stroke-width="1"/>`).join('');
  // Arm-Details (Seite: sd=+1 Rückseite des Segments laut Normalen)
  const armDetail=(sh,el,ha,front)=>{ let s='';
    if(front){ s+=lens(sh,el,.22,.86,3.6,0,ST('bicep')); }
    else { s+=lens(sh,el,.2,.85,3.1,-3,ST('bicep'))+lens(sh,el,.12,.8,3.1,3.3,ST('tricep')); }
    s+=lens(el,ha,.04,.6,2.6,front?0:-1.5,ST('forearm'));
    return s; };
  const legDetail=(hp,kn,ft,front,inner)=>{ let s='';
    if(front){ s+=lens(hp,kn,.12,.82,5,0,ST('quad'))+ell(lerp(hp,kn,.82).map((v,i)=>i===0?v+inner*4.5:v),3.6,4.8,0,ST('quad'));
      s+=lens(kn,ft,.08,.5,2.6,inner*2.5,ST('calf'))+lens(kn,ft,.08,.45,2.2,-inner*3,ST('calf')); }
    else { s+=lens(hp,kn,.12,.85,4.2,-3.5,ST('quad'))+lens(hp,kn,.15,.85,3.6,4,ST('ham'));
      s+=lens(kn,ft,.06,.55,3.6,3.2,ST('calf')); }
    return s; };

  const view=tp.view, fx=view!=='s'?[p.ftL[0],p.ftR[0]]:[p.ft[0],(p.ft2||p.ft)[0]], sx=(fx[0]+fx[1])/2;
  let s=`<ellipse cx="${f1(sx)}" cy="187" rx="48" ry="5.5" fill="url(#${uid}sh)"/>`+(tp.statics||'');
  if(tp.cable) s+=L(p.ha,tp.cable,1.6,'#8a949b');
  if(tp.cables){ s+=L(p.haL,tp.cables[0],1.6,'#8a949b')+L(p.haR,tp.cables[1],1.6,'#8a949b'); }
  if(tp.cableMid){ s+=L(lerp(p.haL,p.haR,.5),tp.cableMid,1.6,'#8a949b'); }
  let b='', eq='';
  const prop=ex.prop;

  if(view==='f'||view==='b'){
    const BK=view==='b';
    for(const [k,f] of [['knL','ftL'],['knR','ftR']]) b+=ell([p[f][0]+(k==='knL'?-2:2),p[f][1]-1],6,3.2,0,STOP_B);
    b+=seg('knL','ftL')+seg('knR','ftR')+seg('hpL','knL')+seg('hpR','knR');
    // Beine: von hinten Beinbeuger + Waden, von vorn Quadrizeps
    if(BK){ for(const [h,k,f,i] of [['hpL','knL','ftL',-1],['hpR','knR','ftR',1]]){
        b+=lens(p[h],p[k],.3,.9,5,0,ST('ham'))+lens(p[k],p[f],.05,.5,3.4,i*2.2,ST('calf'))+lens(p[k],p[f],.05,.45,3,-i*2.8,ST('calf')); } }
    else { b+=legDetail(p.hpL,p.knL,p.ftL,true,1)+legDetail(p.hpR,p.knR,p.ftR,true,-1); }
    // Shorts
    const kL=lerp(p.hpL,p.knL,.4), kR=lerp(p.hpR,p.knR,.4);
    b+=`<path d="M${P2(p.hpL[0]-12,p.hpL[1]-7)}L${P2(p.hpR[0]+12,p.hpR[1]-7)}L${P2(kR[0]+11,kR[1])}L${P2(kR[0]-8,kR[1]+1)}L${P2((p.hpL[0]+p.hpR[0])/2,p.hpL[1]+8)}L${P2(kL[0]+8,kL[1]+1)}L${P2(kL[0]-11,kL[1])}Z" fill="${grad([p.hpL[0]-12,p.hpL[1]],[p.hpR[0]+12,p.hpR[1]],STOP_S)}"/>`;
    b+=`<path d="M${P2(p.hpL[0]-12,p.hpL[1]-7)}L${P2(p.hpR[0]+12,p.hpR[1]-7)}" stroke="#3b4148" stroke-width="2.2"/>`;
    if(BK&&hot('glute')) b+=ell([p.hpL[0]-1,p.hpL[1]+3],10,9,0,STOP_H)+ell([p.hpR[0]+1,p.hpR[1]+3],10,9,0,STOP_H);
    // Rumpf-Silhouette (V-Form)
    const sl=p.shL, sr=p.shR, hl=p.hpL, hr=p.hpR, sy=(sl[1]+sr[1])/2, cx=(p.nk[0]+p.pv[0])/2, py=(hl[1]+hr[1])/2;
    b+=`<path d="M${P2(sl[0]-10,sl[1]-1)}L${P2(sr[0]+10,sr[1]-1)}Q${P2(sr[0]+12,sr[1]+19)} ${P2(hr[0]+2,hr[1]-16)}Q${P2(hr[0]+4,hr[1]-10)} ${P2(hr[0]+3,hr[1]-5)}L${P2(hl[0]-3,hl[1]-5)}Q${P2(hl[0]-4,hl[1]-10)} ${P2(hl[0]-2,hl[1]-16)}Q${P2(sl[0]-12,sl[1]+19)} ${P2(sl[0]-10,sl[1]-1)}Z" fill="${grad([sl[0]-11,sy],[sr[0]+11,sy],STOP_B)}" stroke="${EDGE}" stroke-width=".55"/>`;
    if(BK){
      const stB=(hot('back')||hot('lat'))?STOP_H:STOP_B, stT=(hot('trap')||hot('back'))?STOP_H:STOP_B, stE=(hot('erector')||hot('back'))?STOP_H:STOP_B;
      for(const sd of [-1,1]){ const sp=sd<0?sl:sr, hp=sd<0?hl:hr;
        b+=shape(`M${P2(cx+sd*3,sy+26)}L${P2(sp[0]+sd*1,sp[1]+9)}Q${P2(sp[0]+sd*13,sp[1]+21)} ${P2(hp[0]+sd*2,hp[1]-16)}Q${P2(cx+sd*9,py-6)} ${P2(cx+sd*4,py-12)}Z`,stB,[sp[0],sp[1]],[cx,py],sd*60);
        b+=ell([(cx+sp[0])/2+sd*1.5,sy+12],7.6,5,sd*-18,stB)+ell([sp[0]-sd*1,sy+20],5,3,sd*-35,stB);
        b+=lens([cx+sd*2.6,sy+30],[cx+sd*2.6,py-4],0,1,2.6,0,stE);
      }
      b+=shape(`M${P2(p.nk[0],sy-14)}Q${P2(cx-8,sy-6)} ${P2(sl[0]-3,sl[1]+1)}Q${P2(cx-6,sy+12)} ${P2(cx,sy+33)}Q${P2(cx+6,sy+12)} ${P2(sr[0]+3,sr[1]+1)}Q${P2(cx+8,sy-6)} ${P2(p.nk[0],sy-14)}Z`,stT,[sl[0],sy-14],[sr[0],sy+30],90);
      b+=`<line x1="${f1(cx)}" y1="${f1(sy+33)}" x2="${f1(cx)}" y2="${f1(py-6)}" stroke="${EDGE}" stroke-width=".9"/>`;
    } else {
      // Schräge Bauchmuskeln + Sägezahnmuskel
      for(const sd of [-1,1]){ const sp=sd<0?sl:sr, hp=sd<0?hl:hr;
        b+=shape(`M${P2(sp[0]+sd*2,sy+26)}Q${P2(sp[0]+sd*4,sy+40)} ${P2(hp[0]+sd*1,hp[1]-16)}L${P2(cx+sd*12,py-9)}Q${P2(cx+sd*13,sy+34)} ${P2(cx+sd*11,sy+23)}Z`,ST('oblique'),[sp[0],sy+25],[cx,py],sd*-55);
        for(let i=0;i<3;i++) b+=`<path d="M${P2(sp[0]+sd*(1-i*0.5),sy+16+i*4)}l${f1(-sd*5)} 2.2" stroke="${EDGE}" stroke-width=".7" fill="none"/>`;
      }
      // Brust (Platten)
      const stC=ST('chest');
      for(const sd of [-1,1]){ const sp=sd<0?sl:sr;
        b+=shape(`M${P2(cx-sd*.6,sy-3)}L${P2(sp[0]+sd*3,sp[1]+1)}Q${P2(sp[0]+sd*7,sy+12)} ${P2(sp[0]+sd*1,sy+19)}Q${P2(cx+sd*8,sy+25)} ${P2(cx-sd*.6,sy+19)}Z`,stC,[cx,sy],[sp[0],sy+20],sd*10);
      }
      // Bauch: 6er-Pack + Linea alba
      const top=sy+23, bot=py-12, rh=(bot-top)/3, stA=ST('abs');
      for(let i=0;i<3;i++) for(const sd of [-1,1]){ const x=cx+(sd<0?-9:1), y=top+i*rh+.6, w=8, hh=rh-1.6;
        b+=shape(`M${P2(x+2.6,y)}H${f1(x+w-2.6)}Q${P2(x+w,y)} ${P2(x+w,y+2.6)}V${f1(y+hh-2.6)}Q${P2(x+w,y+hh)} ${P2(x+w-2.6,y+hh)}H${f1(x+2.6)}Q${P2(x,y+hh)} ${P2(x,y+hh-2.6)}V${f1(y+2.6)}Q${P2(x,y)} ${P2(x+2.6,y)}Z`,stA,[x,y],[x+w,y+hh],0); }
      b+=shape(`M${P2(cx-9,bot+1)}L${P2(cx+9,bot+1)}Q${P2(cx+6,py-3)} ${P2(cx,py-2)}Q${P2(cx-6,py-3)} ${P2(cx-9,bot+1)}Z`,stA,[cx-9,bot],[cx+9,py],0);
      // Trapez vorn
      b+=shape(`M${P2(p.nk[0]-5,sy-14)}L${P2(sl[0]-5,sl[1]+1)}L${P2(sr[0]+5,sr[1]+1)}L${P2(p.nk[0]+5,sy-14)}Z`,ST('trap'),[sl[0],sy-14],[sr[0],sy],90);
    }
    b+=seg('hd','nk');
    if(hot('neck')) b+=lens(p.hd,p.nk,.35,1,2.2,-2.5,STOP_H)+lens(p.hd,p.nk,.35,1,2.2,2.5,STOP_H);
    // Schultern (3-köpfig angedeutet)
    for(const sd of [-1,1]){ const sp=sd<0?sl:sr, el=sd<0?p.elL:p.elR;
      b+=ell([sp[0]+sd*3,sp[1]+4],8.8,9.8,sd*-20,ST('delt'));
      b+=`<path d="M${P2(sp[0]+sd*3,sp[1]-4)}Q${P2(sp[0]+sd*8,sp[1]+4)} ${P2(sp[0]+sd*5,sp[1]+12)}" stroke="${hot('delt')?SEAM:EDGE}" stroke-width=".7" fill="none"/>`; }
    for(const [sh,el,ha] of [['shL','elL','haL'],['shR','elR','haR']]){
      b+=seg(sh,el)+seg(el,ha);
      b+= BK ? lens(p[sh],p[el],.2,.85,3.6,0,ST('tricep'))+lens(p[el],p[ha],.04,.55,2.4,0,ST('forearm')) : armDetail(p[sh],p[el],p[ha],true);
    }
    b+=head(p.hd,p.nk);
    if(prop==='bar'){ const y=(p.haL[1]+p.haR[1])/2; eq+=`<line x1="${f1(p.haL[0]-30)}" y1="${f1(y)}" x2="${f1(p.haR[0]+30)}" y2="${f1(y)}" stroke="#b8c0c6" stroke-width="3.2"/>`+[p.haL[0]-34,p.haR[0]+26].map(x=>`<rect x="${f1(x)}" y="${f1(y-14)}" width="8" height="28" rx="2" fill="${grad([x,y-14],[x+8,y+14],STOP_M)}" stroke="#8c969e" stroke-width="1"/>`).join(''); }
    if(prop==='handle'){ eq+=`<line x1="${f1(p.haL[0]-8)}" y1="${f1(p.haL[1])}" x2="${f1(p.haR[0]+8)}" y2="${f1(p.haR[1])}" stroke="#2a2f34" stroke-width="4" stroke-linecap="round"/>`; }
    if(prop==='db'){ eq+=dbFront(p.haL)+dbFront(p.haR); }
  } else {
    const segs=tp.segs||SIDE, legs=segs.filter(([a])=>/^(hp|kn|ft)/.test(a)), arms=segs.filter(([a,c])=>(a==='sh'&&c==='el')||a==='el');
    for(const [a,c] of legs.filter(([a,c])=>/2$/.test(c))) b+=seg(a,c);
    if(p.kn2) b+=legDetail(p.hp,p.kn2,p.ft2,false,1);
    for(const [a,c] of legs.filter(([a,c])=>!/2$/.test(c))) b+=seg(a,c);
    b+=legDetail(p.hp,p.kn,p.ft,false,1);
    if(tp.plat) eq+=L([p.ft[0]-13,p.ft[1]-17],[p.ft[0]+10,p.ft[1]+13],6,'#2a2f34');
    if(tp.pad) eq+=`<circle cx="${f1(p.ft[0])}" cy="${f1(p.ft[1])}" r="6" fill="#2a2f34" stroke="#8c969e" stroke-width="1"/>`;
    b+=seg('sh','hp');
    const [, , ux, uy]=nrm(p.sh,p.hp), fr=[uy,-ux], an=ang(p.sh,p.hp);
    const at=(t,o)=>[p.sh[0]+ux*t+fr[0]*o, p.sh[1]+uy*t+fr[1]*o];
    // Rumpf-Muskeln (Seite)
    for(let i=0;i<3;i++) b+=ell(at(25+i*7.2,8.6),3.6,2.8,an,ST('abs'));
    b+=ell(at(24,1),9,4,an+12,ST('oblique'));
    b+=lens(at(6,-12),at(34,-6),0,1,4.2,0,(hot('lat')||hot('back'))?STOP_H:STOP_B);
    if(hot('erector')) b+=lens(at(26,-11),at(46,-9),0,1,2.4,0,STOP_H);
    b+=hot('chest')?ell(at(14,8.5),13,7.6,an,STOP_H):ell(at(13,7.5),10.5,6.6,an,STOP_B);
    // Shorts
    b+=limb(lerp(p.sh,p.hp,.86),p.hp,20,20,0,0,STOP_S)+limb(p.hp,lerp(p.hp,p.kn,.36),20,17,1,1,STOP_S);
    if(p.kn2) b+=limb(p.hp,lerp(p.hp,p.kn2,.36),20,17,1,1,STOP_S);
    if(hot('glute')) b+=ell([p.hp[0]-fr[0]*7,p.hp[1]-fr[1]*7],9,8,an,STOP_H);
    b+=seg('hd','sh');
    if(hot('trap')) b+=ell(at(-3,-6),7,5,an,STOP_H);
    if(hot('neck')) b+=lens(p.hd,p.sh,.3,1,2.4,0,STOP_H);
    b+=head(p.hd,p.sh);
    b+=ell([p.sh[0]+fr[0]*1,p.sh[1]+fr[1]*1+2],8.6,9.6,an,ST('delt'));
    for(const [a,c] of arms) b+=seg(a,c);
    b+=armDetail(p.sh,p.el,p.ha,false);
    const hand=p[tp.barAt||'ha'];
    if(prop==='bar') eq+=metal(hand, ex.plate||13);
    if(prop==='db') eq+=metal(p.ha,7.5);
    if(prop==='handle') eq+=`<rect x="${f1(p.ha[0]-3)}" y="${f1(p.ha[1]-8)}" width="6" height="16" rx="2" fill="#2a2f34" stroke="#8c969e" stroke-width="1"/>`;
  }
  defs+=`<radialGradient id="${uid}sh"><stop offset="0" stop-color="#000" stop-opacity=".6"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient>`+
        `<radialGradient id="${uid}sp" cx=".5" cy="0" r="1"><stop offset="0" stop-color="#8fb4ff" stop-opacity=".22"/><stop offset=".55" stop-color="#8fb4ff" stop-opacity=".05"/><stop offset="1" stop-color="#8fb4ff" stop-opacity="0"/></radialGradient>`+
        `<filter id="${uid}hg" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="0" stdDeviation="1.6" flood-color="#ff6a1f" flood-opacity=".85"/></filter>`+
        `<filter id="${uid}gl" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="0" stdDeviation="1.4" flood-color="#b9d4ff" flood-opacity=".9"/><feDropShadow dx="0" dy="0" stdDeviation="3.5" flood-color="#5f8fff" flood-opacity=".55"/></filter>`;
  const vals=Object.values(p), mx=vals.reduce((a,v)=>a+v[0],0)/vals.length;
  const spot=`<path d="M${f1(mx-22)} 0L${f1(mx+22)} 0L${f1(mx+70)} 190L${f1(mx-70)} 190Z" fill="url(#${uid}sp)"/>`;
  return `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg"><defs>${defs}</defs>${spot}${s}<g filter="url(#${uid}gl)">${b}</g>${eq}</svg>`;
}

/* ============ Übungsdaten ============ */
const GROUPS=[['cardio','Aufwärmen'],['brust','Brust'],['schultern','Schultern'],['nacken','Nacken'],['bauch','Bauch'],['bizeps','Bizeps'],['trizeps','Trizeps'],['ruecken','Rücken'],['beine','Beine'],['po','Po']];
const EX=[
{id:'laufband',name:'Laufband – zügiges Gehen',g:['cardio'],anim:'walk',prop:'',prim:'Herz-Kreislauf, Beine',sec:'Aufwärmen der Gelenke',equip:'Laufband',lvl:'Anfänger',sets:'1 × 5–7 Min. (4 km/h)',
 steps:['Aufs Laufband stellen, Notaus-Clip an der Kleidung befestigen.','Mit 3 km/h starten und nach 1 Minute auf ca. 4 km/h steigern.','Aufrecht gehen, Blick nach vorn, Arme locker mitschwingen.','5–7 Minuten zügig gehen, bis dir warm ist und der Puls leicht erhöht ist.','Langsam herunterregeln und danach direkt mit dem Training starten.'],
 tips:['Optional 2–5 % Steigung – macht schneller warm, ohne zu ermüden.','Danach bei der ersten Übung 1–2 leichte Aufwärmsätze machen.'],
 err:['Sich an den Griffen festhalten.','Zu schnell – das Aufwärmen soll nicht erschöpfen.']},
// BRUST
{id:'bankdruecken',name:'Bankdrücken (Langhantel)',g:['brust','trizeps'],anim:'bench',prop:'bar',prim:'Große Brustmuskeln',sec:'Trizeps, vordere Schulter',equip:'Langhantel, Flachbank',lvl:'Anfänger',sets:'3–4 × 6–12',
 steps:['Leg dich auf die Bank, Augen unter der Stange, Füße fest auf dem Boden.','Greif die Stange etwas breiter als schulterbreit, Schulterblätter nach hinten-unten ziehen.','Stange ausheben und über der Brust stabilisieren.','Kontrolliert zur unteren Brust absenken, Ellbogen ca. 45–70° vom Körper.','Kraftvoll nach oben drücken, ohne die Ellbogen ganz durchzuschlagen.'],
 tips:['Leichtes Hohlkreuz ist okay – Po bleibt auf der Bank.','Bei schweren Gewichten immer mit Partner (Spotter) trainieren.','Handgelenke gerade halten, Stange liegt im Handballen.'],
 err:['Stange auf der Brust abprallen lassen.','Ellbogen 90° seitlich abspreizen – belastet die Schulter.','Po hebt von der Bank ab.']},
{id:'schraegbank-kh',name:'Schrägbankdrücken (Kurzhantel)',g:['brust'],anim:'incline',prop:'db',prim:'Obere Brust',sec:'Vordere Schulter, Trizeps',equip:'Kurzhanteln, Schrägbank 30–45°',lvl:'Anfänger',sets:'3 × 8–12',
 steps:['Bank auf 30–45° stellen, Kurzhanteln auf den Oberschenkeln mitnehmen.','Zurücklehnen, Hanteln seitlich auf Brusthöhe bringen.','Schulterblätter zusammenziehen, Brust raus.','Hanteln nach oben drücken, bis sie sich fast berühren.','Langsam wieder auf Brusthöhe absenken.'],
 tips:['Nicht steiler als 45° – sonst arbeitet vor allem die Schulter.','Unten eine gute Dehnung spüren, ohne Schmerz.'],
 err:['Hanteln oben laut zusammenschlagen.','Zu schnell absenken, Spannung verlieren.']},
{id:'butterfly-kabel',name:'Kabel-Crossover / Butterfly',g:['brust'],anim:'flyF',prop:'handle',prim:'Brust (innen)',sec:'Vordere Schulter',equip:'Kabelzug oder Butterfly-Maschine',lvl:'Anfänger',sets:'3 × 12–15',
 steps:['Griffe oben einstellen, mittig zwischen die Türme stellen, ein Fuß leicht vor.','Oberkörper leicht nach vorn neigen, Arme weit geöffnet, Ellbogen leicht gebeugt.','Hände in einem Bogen vor dem Körper zusammenführen.','Kurz die Brust anspannen.','Langsam in die Dehnung zurück öffnen.'],
 tips:['Den Ellbogenwinkel während der ganzen Bewegung gleich lassen.','Stell dir vor, du umarmst einen großen Baum.'],
 err:['Arme beugen und strecken – dann wird es zum Drücken.','Mit Schwung aus dem Rücken arbeiten.']},
{id:'liegestuetze',name:'Liegestütze',g:['brust','trizeps'],anim:'pushup',prop:'',prim:'Brust',sec:'Trizeps, Schulter, Rumpf',equip:'Körpergewicht',lvl:'Anfänger',sets:'3 × so viele wie sauber möglich',
 steps:['Hände etwas breiter als schulterbreit auf den Boden, Arme gestreckt.','Körper bildet eine gerade Linie von Kopf bis Fersen, Bauch und Po fest.','Brust kontrolliert Richtung Boden senken, Ellbogen schräg nach hinten.','Kurz über dem Boden stoppen.','Explosiv wieder hochdrücken.'],
 tips:['Zu schwer? Knie auf den Boden oder Hände auf eine Bank.','Zu leicht? Füße erhöht oder langsamer absenken.'],
 err:['Hüfte hängt durch (Hohlkreuz).','Po ragt nach oben.','Kopf nach vorn strecken statt in Verlängerung der Wirbelsäule.']},
{id:'dips',name:'Dips am Barren',g:['brust','trizeps'],anim:'dip',prop:'',prim:'Untere Brust, Trizeps',sec:'Vordere Schulter',equip:'Dip-Barren',lvl:'Fortgeschritten',sets:'3 × 6–12',
 steps:['Auf den Barren stützen, Arme gestreckt, Schultern tief.','Oberkörper leicht nach vorn neigen (mehr Brust) oder aufrecht (mehr Trizeps).','Langsam absenken, bis die Oberarme etwa parallel zum Boden sind.','Ellbogen zeigen nach hinten.','Kraftvoll nach oben drücken.'],
 tips:['Anfänger: Dip-Maschine oder Gummiband zur Unterstützung.','Nicht tiefer gehen, als die Schulter angenehm mitmacht.'],
 err:['Zu tief absenken – Schulter wird überlastet.','Schultern Richtung Ohren hochziehen.']},
// SCHULTERN
{id:'schulterdruecken-kh',name:'Schulterdrücken (Kurzhantel)',g:['schultern','trizeps'],anim:'ohpF',prop:'db',prim:'Vordere & seitliche Schulter',sec:'Trizeps, oberer Rücken',equip:'Kurzhanteln, Bank mit Lehne',lvl:'Anfänger',sets:'3–4 × 8–12',
 steps:['Aufrecht sitzen oder stehen, Hanteln auf Schulterhöhe, Handflächen nach vorn.','Bauch anspannen, Rücken gerade.','Hanteln senkrecht nach oben drücken.','Oben fast strecken, Hanteln nähern sich über dem Kopf.','Kontrolliert zurück auf Ohr-/Kinnhöhe absenken.'],
 tips:['Ellbogen leicht vor dem Körper führen – schont die Schulter.','Im Sitzen mit Lehne kannst du dich besser stabilisieren.'],
 err:['Starkes Hohlkreuz beim Drücken.','Gewicht mit Schwung aus den Beinen hochwerfen.']},
{id:'seitheben',name:'Seitheben (Kurzhantel)',g:['schultern'],anim:'latF',prop:'db',prim:'Seitliche Schulter',sec:'Trapez',equip:'Kurzhanteln',lvl:'Anfänger',sets:'3 × 12–15',
 steps:['Aufrecht stehen, Hanteln seitlich am Körper, Ellbogen leicht gebeugt.','Schultern tief halten.','Arme seitlich anheben, bis sie etwa auf Schulterhöhe sind.','Kurz halten.','Langsam wieder absenken.'],
 tips:['Lieber leichtes Gewicht und saubere Technik.','Denk daran, die Hanteln „nach außen“ statt nach oben zu schieben.'],
 err:['Schultern hochziehen (dann arbeitet der Nacken).','Schwung holen mit dem Oberkörper.','Über Schulterhöhe hinaus anheben.']},
{id:'frontheben',name:'Frontheben',g:['schultern'],anim:'frontS',prop:'db',prim:'Vordere Schulter',sec:'Obere Brust',equip:'Kurzhanteln oder Hantelscheibe',lvl:'Anfänger',sets:'3 × 10–15',
 steps:['Aufrecht stehen, Hanteln vor den Oberschenkeln.','Bauch fest, Ellbogen leicht gebeugt.','Arm(e) nach vorn bis auf Schulterhöhe heben.','Kurz halten.','Kontrolliert absenken.'],
 tips:['Abwechselnd links/rechts ist einfacher für Anfänger.'],
 err:['Mit dem Oberkörper nach hinten lehnen.','Arme zu schnell fallen lassen.']},
{id:'face-pulls',name:'Face Pulls (Kabel)',g:['schultern','ruecken'],anim:'facepull',prop:'handle',prim:'Hintere Schulter',sec:'Oberer Rücken, Rotatorenmanschette',equip:'Kabelzug mit Seil',lvl:'Anfänger',sets:'3 × 12–20',
 steps:['Seil auf Gesichtshöhe einstellen, mit beiden Händen greifen.','Einen Schritt zurück, Arme gestreckt, Körper stabil.','Seil Richtung Gesicht ziehen, Ellbogen hoch und weit nach außen.','Hände enden neben den Ohren, Schulterblätter zusammen.','Langsam zurück in die Streckung.'],
 tips:['Super Übung für gesunde Schultern und gute Haltung.','Leichtes Gewicht, viele Wiederholungen.'],
 err:['Mit dem Körper nach hinten lehnen und reißen.','Ellbogen fallen nach unten.']},
// NACKEN
{id:'shrugs',name:'Shrugs (Schulterheben)',g:['nacken'],anim:'shrugB',prop:'db',prim:'Oberer Trapez (Nacken)',sec:'Unterarme (Griff)',equip:'Kurzhanteln oder Langhantel',lvl:'Anfänger',sets:'3 × 12–15',
 steps:['Aufrecht stehen, Hanteln seitlich, Arme gestreckt.','Kopf neutral, Blick geradeaus.','Schultern gerade nach oben Richtung Ohren ziehen.','Oben 1–2 Sekunden halten.','Langsam wieder absenken.'],
 tips:['Nur hoch und runter – nicht kreisen.','Arme bleiben gestreckt, sie sind nur „Haken“.'],
 err:['Schultern kreisen lassen.','Kopf nach vorn schieben.','Mit den Armen mitziehen.']},
{id:'aufrechtes-rudern',name:'Aufrechtes Rudern',g:['nacken','schultern'],anim:'uprowF',prop:'bar',prim:'Trapez, seitliche Schulter',sec:'Bizeps',equip:'Langhantel oder SZ-Stange',lvl:'Fortgeschritten',sets:'3 × 10–12',
 steps:['Stange schulterbreit im Obergriff vor den Oberschenkeln halten.','Aufrecht stehen, Bauch fest.','Stange nah am Körper nach oben ziehen, Ellbogen führen.','Bis etwa Brust- bzw. Schulterhöhe ziehen.','Kontrolliert absenken.'],
 tips:['Nicht zu eng greifen – schulterbreit schont die Schulter.','Bei Schulterbeschwerden lieber Shrugs oder Face Pulls.'],
 err:['Stange bis unters Kinn reißen.','Handgelenke stark abknicken.']},
{id:'nackenbeugen',name:'Nacken beugen & strecken',g:['nacken'],anim:'neckS',prop:'',prim:'Nackenmuskulatur vorn & hinten',sec:'–',equip:'Körpergewicht (optional Hand als Widerstand)',lvl:'Anfänger',sets:'2–3 × 10–15 langsam',
 steps:['Aufrecht sitzen oder stehen, Schultern locker.','Kinn langsam Richtung Brust senken.','Kopf langsam wieder aufrichten und leicht nach hinten führen.','Für mehr Widerstand die Hand an Stirn bzw. Hinterkopf legen und leicht dagegen drücken.','Ruhig atmen, nichts ruckartig.'],
 tips:['Sehr langsam ausführen – der Nacken ist empfindlich.','Gut als Aufwärmen und gegen Verspannungen.'],
 err:['Ruckartige Bewegungen.','Kopf weit in den Nacken werfen.']},
{id:'nacken-seitlich',name:'Nacken seitlich neigen',g:['nacken'],anim:'neckF',prop:'',prim:'Seitliche Nackenmuskulatur',sec:'–',equip:'Körpergewicht',lvl:'Anfänger',sets:'2 × 10 pro Seite',
 steps:['Aufrecht stehen, Schultern tief und locker.','Kopf langsam zur rechten Schulter neigen (Ohr Richtung Schulter).','Zurück zur Mitte.','Zur linken Seite neigen.','Optional mit der Hand leichten Gegendruck geben.'],
 tips:['Schulter nicht zum Ohr hochziehen.','Am Ende der Bewegung kurz halten für eine sanfte Dehnung.'],
 err:['Kopf drehen statt neigen.','Zu viel Druck mit der Hand.']},
// BAUCH
{id:'crunches',name:'Crunches',g:['bauch'],anim:'crunch',prop:'',prim:'Gerader Bauchmuskel',sec:'Schräge Bauchmuskeln',equip:'Matte',lvl:'Anfänger',sets:'3 × 15–20',
 steps:['Auf den Rücken legen, Knie angewinkelt, Füße auf dem Boden.','Arme vor der Brust kreuzen oder Fingerspitzen an die Schläfen.','Oberkörper einrollen, Schulterblätter vom Boden lösen.','Oben kurz den Bauch fest anspannen.','Langsam zurückrollen, Kopf nicht ablegen.'],
 tips:['Es geht um das Einrollen, nicht ums Hochkommen.','Blick schräg nach oben, Platz für eine Faust zwischen Kinn und Brust.'],
 err:['Am Kopf ziehen.','Mit Schwung hochreißen.']},
{id:'beinheben-haengend',name:'Hängendes Knie-/Beinheben',g:['bauch'],anim:'legraise',prop:'',prim:'Unterer Bauch',sec:'Hüftbeuger, Griffkraft',equip:'Klimmzugstange',lvl:'Fortgeschritten',sets:'3 × 8–15',
 steps:['An die Stange hängen, Arme gestreckt, Schultern aktiv.','Körper ruhig halten, nicht schaukeln.','Knie Richtung Brust ziehen, Becken leicht einrollen.','Oben kurz halten.','Langsam wieder absenken.'],
 tips:['Anfänger: erst Knie anziehen, später gestreckte Beine.','Alternative: Beinheben liegend auf der Matte.'],
 err:['Mit Schwung arbeiten.','Nur die Beine heben, ohne das Becken einzurollen.']},
{id:'unterarmstuetz',name:'Unterarmstütz (Plank)',g:['bauch'],anim:'plank',prop:'',prim:'Gesamter Rumpf',sec:'Schultern, Po',equip:'Matte',lvl:'Anfänger',sets:'3 × 20–60 Sek.',
 steps:['Unterarme schulterbreit auflegen, Ellbogen unter den Schultern.','Beine strecken, auf die Zehenspitzen.','Körper bildet eine gerade Linie.','Bauch und Po fest anspannen.','Position halten und ruhig weiteratmen.'],
 tips:['Lieber kürzer und sauber als lang und durchhängend.','Ziehe gedanklich die Ellbogen Richtung Füße – das erhöht die Spannung.'],
 err:['Hüfte hängt durch.','Po zu hoch.','Luft anhalten.']},
{id:'mountain-climbers',name:'Mountain Climbers',g:['bauch'],anim:'climber',prop:'',prim:'Bauch, Hüftbeuger',sec:'Schultern, Ausdauer',equip:'Körpergewicht',lvl:'Anfänger',sets:'3 × 30 Sek.',
 steps:['Startposition wie beim Liegestütz oben.','Ein Knie Richtung Brust ziehen.','Zurück und sofort das andere Knie anziehen.','Im Wechsel zügig weiter.','Hüfte bleibt tief und stabil.'],
 tips:['Erst langsam für Technik, dann Tempo steigern.'],
 err:['Po weit nach oben schieben.','Hände wandern nach vorn.']},
// BIZEPS
{id:'lh-curls',name:'Langhantel-Curls',g:['bizeps'],anim:'curl',prop:'bar',plate:12,prim:'Bizeps',sec:'Unterarme',equip:'Langhantel oder SZ-Stange',lvl:'Anfänger',sets:'3–4 × 8–12',
 steps:['Aufrecht stehen, Stange schulterbreit im Untergriff.','Ellbogen eng am Körper fixieren.','Stange in einem Bogen Richtung Schultern beugen.','Oben den Bizeps fest anspannen.','Langsam bis zur fast vollen Streckung absenken.'],
 tips:['SZ-Stange schont die Handgelenke.','Absenken dauert ca. 2–3 Sekunden.'],
 err:['Ellbogen wandern nach vorn.','Oberkörper schwingt nach hinten.']},
{id:'kh-curls',name:'Kurzhantel-Curls',g:['bizeps'],anim:'curl',prop:'db',prim:'Bizeps',sec:'Unterarme',equip:'Kurzhanteln',lvl:'Anfänger',sets:'3 × 10–12',
 steps:['Aufrecht stehen, Hanteln seitlich, Handflächen nach vorn.','Ellbogen am Körper lassen.','Hantel(n) nach oben beugen.','Oben kurz anspannen.','Kontrolliert absenken.'],
 tips:['Abwechselnd oder gleichzeitig – beides geht.','Für mehr Wirkung die Handfläche oben leicht nach außen drehen.'],
 err:['Gewicht mit Schwung hochwerfen.','Nur halbe Bewegung.']},
{id:'hammer-curls',name:'Hammer-Curls',g:['bizeps'],anim:'curl',prop:'handle',prim:'Bizeps, Oberarmmuskel (Brachialis)',sec:'Unterarme',equip:'Kurzhanteln',lvl:'Anfänger',sets:'3 × 10–12',
 steps:['Hanteln seitlich halten, Daumen zeigen nach vorn (wie ein Hammer).','Ellbogen fixieren.','Hantel nach oben beugen, Griff bleibt neutral.','Oben kurz halten.','Langsam absenken.'],
 tips:['Macht die Oberarme „dicker“ und stärkt den Griff.'],
 err:['Handgelenk dreht sich.','Schultern ziehen nach vorn.']},
{id:'konzentrationscurls',name:'Konzentrationscurls',g:['bizeps'],anim:'conc',prop:'db',prim:'Bizeps (isoliert)',sec:'–',equip:'Kurzhantel, Bank',lvl:'Anfänger',sets:'3 × 10–12 pro Arm',
 steps:['Auf die Bank setzen, Beine gespreizt, leicht nach vorn lehnen.','Ellbogen an die Innenseite des Oberschenkels legen.','Hantel Richtung Schulter beugen.','Oben stark anspannen.','Langsam ganz absenken.'],
 tips:['Nur der Unterarm bewegt sich – volle Konzentration auf den Muskel.'],
 err:['Ellbogen vom Bein lösen.','Mit dem Oberkörper mithelfen.']},
// TRIZEPS
{id:'trizepsdruecken-kabel',name:'Trizepsdrücken am Kabel',g:['trizeps'],anim:'pushdown',prop:'handle',prim:'Trizeps',sec:'–',equip:'Kabelzug mit Stange oder Seil',lvl:'Anfänger',sets:'3 × 10–15',
 steps:['Vor den Kabelzug stellen, Griff oben fassen.','Ellbogen eng am Körper, Oberkörper leicht nach vorn.','Griff nach unten drücken, bis die Arme gestreckt sind.','Unten den Trizeps anspannen.','Langsam zurück bis die Unterarme etwa waagerecht sind.'],
 tips:['Oberarme bleiben die ganze Zeit still.','Mit Seil kannst du unten die Hände auseinanderziehen.'],
 err:['Ellbogen wandern nach vorn/hinten.','Mit Körpergewicht runterdrücken.']},
{id:'ueberkopf-trizeps',name:'Trizepsstrecken über Kopf',g:['trizeps'],anim:'overhead',prop:'db',prim:'Trizeps (langer Kopf)',sec:'–',equip:'Kurzhantel',lvl:'Anfänger',sets:'3 × 10–12',
 steps:['Stehen oder sitzen, Hantel mit beiden Händen über den Kopf.','Oberarme neben dem Kopf, Ellbogen zeigen nach vorn-oben.','Hantel hinter dem Kopf langsam absenken.','Wieder nach oben strecken.','Bauch anspannen, kein Hohlkreuz.'],
 tips:['Ellbogen nicht weit nach außen fallen lassen.'],
 err:['Starkes Hohlkreuz.','Zu schweres Gewicht – belastet den Ellbogen.']},
{id:'bankdips',name:'Bank-Dips',g:['trizeps'],anim:'benchdip',prop:'',prim:'Trizeps',sec:'Vordere Schulter, Brust',equip:'Bank oder Stuhl',lvl:'Anfänger',sets:'3 × 10–15',
 steps:['Hände schulterbreit hinter dir auf die Bankkante, Finger nach vorn.','Beine nach vorn strecken (leichter: Knie beugen).','Po nah an der Bank absenken, Ellbogen zeigen nach hinten.','Bis die Oberarme etwa waagerecht sind.','Über den Trizeps wieder hochdrücken.'],
 tips:['Gut für zu Hause – ein stabiler Stuhl reicht.'],
 err:['Zu tief gehen – Schulter überlastet.','Po weit von der Bank weg.']},
{id:'enge-liegestuetze',name:'Enge Liegestütze',g:['trizeps','brust'],anim:'pushup',prop:'',prim:'Trizeps',sec:'Brust, Schulter',equip:'Körpergewicht',lvl:'Fortgeschritten',sets:'3 × 8–15',
 steps:['Liegestützposition, Hände eng unter der Brust.','Körper gerade, Bauch fest.','Absenken, Ellbogen streifen eng am Körper nach hinten.','Brust nah zum Boden.','Hochdrücken.'],
 tips:['Erleichterung: auf den Knien oder an einer Bank.'],
 err:['Ellbogen gehen weit nach außen.','Hüfte hängt durch.']},
// RÜCKEN
{id:'klimmzuege',name:'Klimmzüge',g:['ruecken','bizeps'],anim:'pullupB',prop:'',prim:'Breiter Rückenmuskel (Latissimus)',sec:'Bizeps, hintere Schulter',equip:'Klimmzugstange',lvl:'Fortgeschritten',sets:'3 × so viele wie sauber möglich',
 steps:['Stange etwas breiter als schulterbreit im Obergriff fassen.','Aktiv hängen: Schultern leicht nach unten ziehen.','Brust zur Stange ziehen, Ellbogen nach unten führen.','Kinn über die Stange.','Kontrolliert bis zur Streckung absenken.'],
 tips:['Noch kein Klimmzug? Gummiband, Klimmzugmaschine oder nur langsames Herunterlassen üben.'],
 err:['Mit den Beinen schwingen (Kipping).','Nur halbe Wiederholungen.']},
{id:'latzug',name:'Latzug',g:['ruecken'],anim:'latpullB',prop:'handle',prim:'Latissimus',sec:'Bizeps, mittlerer Rücken',equip:'Latzugmaschine',lvl:'Anfänger',sets:'3–4 × 10–12',
 steps:['Hinsetzen, Knie unter das Polster, Stange breit greifen.','Oberkörper leicht nach hinten neigen, Brust raus.','Stange zur oberen Brust ziehen, Ellbogen nach unten-hinten.','Schulterblätter zusammenziehen.','Langsam nach oben zurücklassen.'],
 tips:['Denke „Ellbogen in die Hosentaschen“.'],
 err:['Stange in den Nacken ziehen.','Weit zurücklehnen und reißen.']},
{id:'lh-rudern',name:'Langhantelrudern vorgebeugt',g:['ruecken'],anim:'row',prop:'bar',plate:13,prim:'Mittlerer & oberer Rücken',sec:'Latissimus, Bizeps, unterer Rücken',equip:'Langhantel',lvl:'Fortgeschritten',sets:'3–4 × 8–10',
 steps:['Stange schulterbreit greifen, Knie leicht beugen.','Mit geradem Rücken nach vorn beugen (ca. 45°).','Stange Richtung Bauchnabel ziehen.','Schulterblätter zusammendrücken.','Kontrolliert absenken.'],
 tips:['Rücken bleibt die ganze Zeit gerade – Blick leicht nach vorn-unten.'],
 err:['Runder Rücken.','Oberkörper richtet sich beim Ziehen auf.']},
{id:'kh-rudern',name:'Kurzhantelrudern einarmig',g:['ruecken'],anim:'row',prop:'db',prim:'Latissimus, mittlerer Rücken',sec:'Bizeps, hintere Schulter',equip:'Kurzhantel, Bank',lvl:'Anfänger',sets:'3 × 10–12 pro Seite',
 steps:['Ein Knie und eine Hand auf die Bank, Rücken gerade.','Hantel mit dem freien Arm hängen lassen.','Hantel Richtung Hüfte ziehen, Ellbogen nah am Körper.','Oben kurz halten.','Langsam absenken.'],
 tips:['Ziehe eher Richtung Hüfte als Richtung Schulter.'],
 err:['Oberkörper aufdrehen.','Mit Schwung reißen.']},
{id:'kreuzheben',name:'Kreuzheben',g:['ruecken','beine','po'],anim:'deadlift',prop:'bar',plate:15,prim:'Unterer Rücken, Po, Beinbeuger',sec:'Oberschenkel, Trapez, Griff',equip:'Langhantel',lvl:'Fortgeschritten',sets:'3 × 5–8',
 steps:['Füße hüftbreit, Stange über der Fußmitte.','Hüfte nach hinten, Knie beugen, Stange schulterbreit greifen.','Rücken gerade, Brust raus, Schultern über der Stange.','Aus den Beinen drücken, Stange nah am Körper hochziehen.','Oben aufrecht stehen, dann kontrolliert wieder ablegen.'],
 tips:['Technik zuerst mit leichtem Gewicht oder vom Trainer zeigen lassen.','Vor dem Heben tief einatmen und den Bauch fest machen.'],
 err:['Runder Rücken – größtes Verletzungsrisiko!','Stange weit vom Körper weg.','Oben ins Hohlkreuz lehnen.']},
// BEINE
{id:'kniebeuge',name:'Kniebeuge (Langhantel)',g:['beine','po'],anim:'squat',prop:'bar',plate:14,prim:'Oberschenkel vorn, Po',sec:'Beinbeuger, Rumpf',equip:'Langhantel, Rack',lvl:'Fortgeschritten',sets:'3–4 × 6–10',
 steps:['Stange auf den oberen Rücken (nicht auf den Nacken) legen.','Füße etwa schulterbreit, Zehen leicht nach außen.','Tief einatmen, Bauch fest, Hüfte nach hinten und Knie beugen.','So tief wie mit geradem Rücken möglich (Ideal: Oberschenkel waagerecht).','Aus den Fersen kraftvoll hochdrücken.'],
 tips:['Knie zeigen in Richtung der Zehen.','Anfänger: erst ohne Gewicht oder mit Kurzhantel vor der Brust (Goblet Squat).'],
 err:['Knie fallen nach innen.','Fersen heben ab.','Runder Rücken unten.']},
{id:'ausfallschritte',name:'Ausfallschritte',g:['beine','po'],anim:'lunge',prop:'db',prim:'Oberschenkel, Po',sec:'Beinbeuger, Gleichgewicht',equip:'Kurzhanteln oder Körpergewicht',lvl:'Anfänger',sets:'3 × 10 pro Bein',
 steps:['Aufrecht stehen, Hanteln seitlich.','Großen Schritt nach vorn machen.','Hinteres Knie Richtung Boden absenken, Oberkörper aufrecht.','Vorderes Knie über dem Fuß, nicht weit über die Zehen.','Über die vordere Ferse zurückdrücken, Bein wechseln.'],
 tips:['Längerer Schritt = mehr Po, kürzerer = mehr Oberschenkel.'],
 err:['Vorderes Knie knickt nach innen.','Oberkörper fällt nach vorn.']},
{id:'rumaenisches-kreuzheben',name:'Rumänisches Kreuzheben',g:['beine','po'],anim:'rdl',prop:'bar',plate:13,prim:'Beinbeuger, Po',sec:'Unterer Rücken',equip:'Langhantel oder Kurzhanteln',lvl:'Fortgeschritten',sets:'3 × 8–12',
 steps:['Aufrecht stehen, Stange vor den Oberschenkeln.','Knie leicht gebeugt und so lassen.','Hüfte weit nach hinten schieben, Stange gleitet an den Beinen nach unten.','Bis du eine starke Dehnung hinten im Oberschenkel spürst.','Hüfte nach vorn schieben und aufrichten.'],
 tips:['Bewegung kommt aus der Hüfte – stell dir vor, du schließt eine Tür mit dem Po.'],
 err:['Rücken rundet sich.','Knie zu stark beugen (wird zur Kniebeuge).']},
{id:'wadenheben',name:'Wadenheben stehend',g:['beine'],anim:'calf',prop:'',prim:'Waden',sec:'–',equip:'Stufe, optional Kurzhanteln',lvl:'Anfänger',sets:'3–4 × 15–20',
 steps:['Mit den Fußballen auf eine Stufe stellen, Fersen frei.','Aufrecht stehen, ggf. irgendwo festhalten.','Fersen so hoch wie möglich drücken.','Oben 1–2 Sekunden halten.','Langsam unter die Stufe absenken für die Dehnung.'],
 tips:['Volle Bewegung ist wichtiger als viel Gewicht.'],
 err:['Wippen ohne Kontrolle.','Nur halbe Bewegung.']},
// PO
{id:'hip-thrust',name:'Hip Thrust',g:['po','beine'],anim:'hipthrust',prop:'bar',plate:12,prim:'Großer Gesäßmuskel',sec:'Beinbeuger',equip:'Bank, Langhantel (mit Polster)',lvl:'Anfänger',sets:'3–4 × 8–12',
 steps:['Oberer Rücken an die Bankkante, Stange (mit Polster) auf der Hüfte.','Füße hüftbreit, Knie etwa 90° wenn oben.','Hüfte nach oben drücken, bis der Körper von Schultern bis Knie gerade ist.','Oben den Po fest zusammenkneifen.','Kontrolliert absenken.'],
 tips:['Kinn leicht zur Brust – verhindert Hohlkreuz.','Ohne Gewicht auf dem Boden = Glute Bridge (Einsteiger).'],
 err:['Oben ins Hohlkreuz drücken.','Aus den Zehen statt aus den Fersen drücken.']},
// MASCHINEN & KABEL
{id:'brustpresse',name:'Brustpresse (Maschine)',g:['brust','trizeps'],anim:'chestM',prop:'handle',prim:'Brust',sec:'Trizeps, vordere Schulter',equip:'Brustpresse-Maschine',lvl:'Anfänger',sets:'3 × 8–12',
 steps:['Sitz so einstellen, dass die Griffe auf Höhe der mittleren Brust sind.','Rücken fest an die Lehne, Schulterblätter nach hinten-unten.','Griffe nach vorn drücken, bis die Arme fast gestreckt sind.','Kurz die Brust anspannen.','Langsam zurück, bis du eine leichte Dehnung in der Brust spürst.'],
 tips:['Ideal, um sicher bis kurz vor Muskelversagen zu trainieren – kein Spotter nötig.','Ellbogen etwas unter Schulterhöhe führen.'],
 err:['Sitz zu tief/hoch – dann arbeitet vor allem die Schulter.','Gewicht zurückknallen lassen.']},
{id:'schulterpresse-maschine',name:'Schulterpresse (Maschine)',g:['schultern','trizeps'],anim:'ohpSeatF',prop:'handle',prim:'Vordere & seitliche Schulter',sec:'Trizeps',equip:'Schulterpresse-Maschine',lvl:'Anfänger',sets:'3 × 8–12',
 steps:['Sitz so einstellen, dass die Griffe etwa auf Schulterhöhe sind.','Rücken an die Lehne, Bauch anspannen.','Griffe nach oben drücken, bis die Arme fast gestreckt sind.','Kurz halten.','Kontrolliert bis auf Kinnhöhe absenken.'],
 tips:['Sicherer als freie Gewichte, wenn du allein trainierst.'],
 err:['Po rutscht nach vorn, Hohlkreuz.','Arme oben komplett durchdrücken.']},
{id:'reverse-butterfly',name:'Reverse Butterfly (Maschine)',g:['schultern','ruecken'],anim:'revflyB',prop:'handle',prim:'Hintere Schulter',sec:'Oberer Rücken, Trapez',equip:'Butterfly-Maschine (umgekehrt) oder Kabel',lvl:'Anfänger',sets:'3 × 12–15',
 steps:['Mit der Brust zum Polster setzen, Griffe auf Schulterhöhe.','Arme vor dem Körper, Ellbogen leicht gebeugt.','Arme in einem Bogen weit nach hinten-außen führen.','Schulterblätter am Ende kurz zusammenziehen.','Langsam zurück nach vorn.'],
 tips:['Wichtig für breite Schultern und eine gute Haltung.','Leichtes Gewicht, sauber und kontrolliert.'],
 err:['Mit Schwung arbeiten.','Schultern zu den Ohren hochziehen.']},
{id:'kabelrudern-sitzend',name:'Rudern am Kabel (sitzend)',g:['ruecken','bizeps'],anim:'cablerow',prop:'handle',prim:'Mittlerer Rücken, Latissimus',sec:'Bizeps, hintere Schulter',equip:'Kabelzug mit V-Griff',lvl:'Anfänger',sets:'3 × 10–12',
 steps:['Hinsetzen, Füße an die Platte, Knie leicht gebeugt.','V-Griff fassen, Oberkörper aufrecht, Brust raus.','Griff zum Bauch ziehen, Ellbogen eng am Körper nach hinten.','Schulterblätter fest zusammenziehen.','Arme langsam nach vorn strecken, Schultern dürfen leicht mitgehen.'],
 tips:['Oberkörper bleibt fast ruhig – kein Schaukeln.'],
 err:['Mit dem Oberkörper weit zurückwerfen.','Runder Rücken beim Vorgehen.']},
{id:'beinpresse',name:'Beinpresse',g:['beine','po'],anim:'legpress',prop:'',prim:'Oberschenkel vorn, Po',sec:'Beinbeuger, Waden',equip:'Beinpresse (Maschine)',lvl:'Anfänger',sets:'3 × 10–15',
 steps:['Hinsetzen, Rücken und Po fest an die Lehne.','Füße schulterbreit mittig auf die Platte.','Sicherung lösen, Knie langsam Richtung Brust beugen.','So tief, wie der Po noch am Polster bleibt.','Über die ganze Fußsohle zurückdrücken, Knie nicht durchstrecken.'],
 tips:['Füße höher = mehr Po & Beinbeuger, tiefer = mehr vorderer Oberschenkel.','Sehr gut, um die Beine schwer und sicher zu trainieren.'],
 err:['Knie oben ganz durchdrücken.','Po hebt unten vom Polster ab (runder unterer Rücken).','Knie fallen nach innen.']},
{id:'beinstrecker',name:'Beinstrecker (Maschine)',g:['beine'],anim:'legext',prop:'',prim:'Vorderer Oberschenkel',sec:'–',equip:'Beinstrecker-Maschine',lvl:'Anfänger',sets:'3 × 12–15',
 steps:['Sitz so einstellen, dass das Knie auf Höhe des Drehpunkts ist.','Polster vorn am Schienbein, knapp über dem Fuß.','Beine nach oben strecken.','Oben 1 Sekunde den Oberschenkel anspannen.','Langsam wieder absenken.'],
 tips:['Gut als zweite Beinübung nach Beinpresse oder Kniebeuge.'],
 err:['Gewicht hochschleudern.','Po hebt vom Sitz ab.']},
{id:'beinbeuger',name:'Beinbeuger sitzend (Maschine)',g:['beine'],anim:'legcurl',prop:'',prim:'Hinterer Oberschenkel',sec:'Waden',equip:'Beinbeuger-Maschine',lvl:'Anfänger',sets:'3 × 10–12',
 steps:['Sitz einstellen, Knie am Drehpunkt, Oberschenkelpolster fest.','Polster hinten an die Unterschenkel, knapp über der Ferse.','Beine nach unten-hinten beugen, so weit es geht.','Kurz halten.','Langsam zurück in die Streckung.'],
 tips:['Die Rückseite der Beine wird oft vernachlässigt – wichtig für gesunde Knie.'],
 err:['Hüfte hebt ab.','Zu schnell zurückschnellen lassen.']},
{id:'kabel-curls',name:'Bizeps-Curls am Kabel',g:['bizeps'],anim:'cablecurl',prop:'handle',prim:'Bizeps',sec:'Unterarme',equip:'Kabelzug mit Stange oder Seil',lvl:'Anfänger',sets:'3 × 12–15',
 steps:['Seilzug unten einstellen, Griff im Untergriff fassen.','Aufrecht stehen, Ellbogen eng am Körper.','Griff Richtung Schultern beugen.','Oben kurz anspannen.','Langsam wieder strecken.'],
 tips:['Das Kabel hält die Spannung über die ganze Bewegung.'],
 err:['Ellbogen wandern nach vorn.','Mit dem Rücken nachhelfen.']},
];

/* ============ Teilen ============ */
const WA_ICON='<svg width="20" height="20" viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.6.8-.8 1-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.2-.4.3-.4.8-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.7a2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .2-1.3c-.1-.1-.3-.2-.5-.3z"/></svg>';
function appUrl(){ return location.href.split('#')[0]; }
const waHref=t=>'https://wa.me/?text='+encodeURIComponent(trMsg(t));
function appShareText(){ return '💪 Muskel-Coach – Trainings-App mit 3D-Übungen, Trainingsplan, Kalender und Kalorienrechner. 10 Tage kostenlos testen:\n'+appUrl(); }
function initShare(){ $('waApp').href=waHref(appShareText());
  $('copyApp').onclick=async()=>{ const t=trMsg(appShareText()); try{ await navigator.clipboard.writeText(t); $('copyMsg').textContent='Kopiert ✓ – jetzt in WhatsApp einfügen'; }catch(e){ $('copyMsg').textContent=t; } }; }

/* ============ Kalorien (MET-Methode) ============ */
const MET_CAT={big:6.0,mid:5.0,iso:3.5,core:3.8,hiit:8.0,light:2.3};
const REST_CAT={big:120,mid:90,iso:60,core:45,hiit:30,light:20};
const CAT={bankdruecken:'big',kniebeuge:'big',kreuzheben:'big',beinpresse:'big',klimmzuege:'big',ausfallschritte:'big','rumaenisches-kreuzheben':'big','hip-thrust':'big',
  dips:'mid','schraegbank-kh':'mid',liegestuetze:'mid','enge-liegestuetze':'mid',latzug:'mid','lh-rudern':'mid','kh-rudern':'mid','kabelrudern-sitzend':'mid',
  'schulterdruecken-kh':'mid','schulterpresse-maschine':'mid',brustpresse:'mid','aufrechtes-rudern':'mid',bankdips:'mid',
  crunches:'core','beinheben-haengend':'core',unterarmstuetz:'core','mountain-climbers':'hiit',nackenbeugen:'light','nacken-seitlich':'light'};
const nums=s=>(String(s).match(/\d+(?:[.,]\d+)?/g)||[]).map(x=>parseFloat(x.replace(',','.')));
const avg=a=>a.length?(a.length>1&&!/\//.test(a.src||'')?(a[0]+a[1])/2:a[0]):0;
function bodyW(){ const w=parseFloat(String(prof&&prof.w||'').replace(',','.')); return w>=35&&w<=250?w:80; }
function walkMET(kmh){ return kmh<=3?2.5:kmh<=4.5?3.0:kmh<=5.5?3.8:kmh<=6.5?5.0:kmh<=8?8.3:9.8; }
function kcalFor(id,setsStr,repsStr,w){
  w=w||bodyW(); const s=String(repsStr||'');
  if(id==='laufband'){ const mm=s.match(/(\d+(?:[.,]\d+)?)\s*(?:[–-]\s*(\d+(?:[.,]\d+)?))?\s*Min/i); const mins=mm?(parseFloat(mm[1])+(mm[2]?parseFloat(mm[2]):parseFloat(mm[1])))/2:6;
    const sp=s.match(/(\d+(?:[.,]\d+)?)\s*km/i); const kmh=sp?parseFloat(sp[1].replace(',','.')):4; return walkMET(kmh)*w*mins/60; }
  const cat=CAT[id]||'iso', met=MET_CAT[cat]; let sets=parseInt(setsStr)||3, active;
  const n=nums(s);
  if(/\//.test(s)&&n.length>1){ sets=n.length; active=n.reduce((a,b)=>a+b,0)*4; }
  else if(/\d\s*(s|sek)\b/i.test(s)){ const hold=n.length>1?(n[0]+n[1])/2:(n[0]||30); active=sets*hold; }
  else { let reps=n.length>1?(n[0]+n[1])/2:(n[0]||10); if(/bein|seite|arm/i.test(s)) reps*=2; active=sets*reps*4; }
  const rest=sets*REST_CAT[cat];
  return w*(met*active+2.5*rest)/3600;
}
const kcalItem=i=>kcalFor(i.id,i.sets,i.reps);
const kcalDay=d=>d.items.reduce((a,i)=>a+kcalItem(i),0);
const kTxt=v=>Math.round(v);

/* ============ App ============ */
let favs=[]; try{favs=JSON.parse(testLocal.getItem('mc_favs')||'[]')}catch(e){}
const saveFavs=()=>{try{testLocal.setItem('mc_favs',JSON.stringify(favs))}catch(e){}};
let group='alle', query='';
const $=id=>document.getElementById(id);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const gname=k=>(GROUPS.find(g=>g[0]===k)||[,k])[1];

const GVIEW={brust:'f',schultern:'f',nacken:'b',bauch:'f',bizeps:'f',trizeps:'b',ruecken:'b',beine:'f',po:'b',cardio:'f',alle:'f'};

/* ===== Zusätzliche Bewegungen ===== */
(function(){
  const LYING={hd:[48,117],sh:[64,122],hp:[122,124],kn:[148,112],ft:[160,184],to:[172,184]};
  const FLOOR={hd:[36,172],sh:[54,174],hp:[104,178]};
  const BENT={hd:[152,72],sh:[138,82],hp:[90,112],kn:[110,146],ft:[98,184],to:[110,184]};
  const SEAT={hp:[90,128],kn:[126,128],ft:[128,184],to:[140,184],sh:[98,82],hd:[104,65]};
  const lowCables=[[60,182],[140,182]];
  Object.assign(T,{
    flyS:{view:'s',statics:benchFlat,A:P(S,Object.assign({},LYING,{el:[66,96],ha:[66,70],lw:[24,20]})),B:P(S,Object.assign({},LYING,{el:[70,120],ha:[64,124],lw:[58,66]}))},
    pullover:{view:'s',statics:benchFlat,A:P(S,Object.assign({},LYING,{el:[64,96],ha:[62,72],lw:[10,4]})),B:P(S,Object.assign({},LYING,{el:[42,110],ha:[22,108],lw:[10,4]}))},
    flyLowF:{view:'f',cables:[[8,176],[192,176]],statics:tower(0)+tower(190),eqZ:-0.38,A:P(F,Object.assign({},LEAN,armsZ([72,96,4],[56,118,10]))),B:P(F,Object.assign({},LEAN,armsZ([86,76,24],[96,64,42])))},
    bike:{view:'s',segs:LUNGE,
      A:P(S,{hd:[48,139],sh:[63,149],el:[78,160],ha:[67,152],hp:[104,178],kn:[112,142],ft:[134,150],to:[142,146],kn2:[138,168],ft2:[172,170],to2:[178,164]}),
      B:P(S,{hd:[50,141],sh:[64,150],el:[78,160],ha:[67,152],hp:[104,178],kn:[138,168],ft:[172,170],to:[178,164],kn2:[112,142],ft2:[134,150],to2:[142,146]})},
    lyleg:{view:'s',A:P(S,Object.assign({},FLOOR,{el:[78,180],ha:[96,181],kn:[138,179],ft:[172,180],to:[178,172]})),
      B:P(S,Object.assign({},FLOOR,{el:[78,180],ha:[96,181],kn:[112,146],ft:[118,112],to:[128,108]}))},
    revcrunch:{view:'s',A:P(S,Object.assign({},FLOOR,{el:[78,180],ha:[96,181],kn:[124,148],ft:[150,168],to:[160,166]})),
      B:P(S,Object.assign({},FLOOR,{el:[78,180],ha:[96,181],hp:[100,170],kn:[86,130],ft:[110,118],to:[118,110]}))},
    rollout:{view:'s',A:P(S,{hd:[140,96],sh:[128,110],el:[134,136],ha:[138,162],hp:[100,140],kn:[96,182],ft:[66,184],to:[60,182]}),
      B:P(S,{hd:[174,138],sh:[160,148],el:[176,158],ha:[188,166],hp:[112,160],kn:[96,182],ft:[66,184],to:[60,182]})},
    woodF:{view:'f',cableMid:[190,16],statics:tower(190),eqZ:-0.3,sideAz:-90,
      A:P(F,{hd:[102,44,2],nk:[102,60],shL:[91,64,14],shR:[113,64,-12],elL:[114,52,22],haL:[135,43,24],elR:[127,56,10],haR:[137,41,24]}),
      B:P(F,{hd:[97,52,6],nk:[99,68],shL:[89,72,-8],shR:[109,72,14],elL:[82,90,12],haL:[79,105,26],elR:[93,90,22],haR:[77,103,26],
             pv:[100,121],hpL:[91,123],hpR:[109,123],knL:[88,152,8],knR:[112,152,8]})},
    latCableF:Object.assign({},T.latF,{cables:lowCables}),
    frontCable:Object.assign({},T.frontS,{cable:[96,184]}),
    uprowCable:Object.assign({},T.uprowF,{cableMid:[100,184]}),
    skull:{view:'s',statics:benchFlat,A:P(S,Object.assign({},LYING,{el:[68,92],ha:[66,66]})),B:P(S,Object.assign({},LYING,{el:[68,92],ha:[50,104]}))},
    kickback:{view:'s',A:P(S,Object.assign({},BENT,{el:[116,98],ha:[118,124]})),B:P(S,Object.assign({},BENT,{el:[116,98],ha:[90,92]}))},
    ohCable:Object.assign({},T.overhead,{cable:[70,184]}),
    preacher:{view:'s',statics:'<path d="M104 92L130 118" stroke="#3b4249" stroke-width="8" stroke-linecap="round"/><path d="M120 112V184" stroke="#3b4249" stroke-width="5"/><rect x="62" y="128" width="40" height="7" rx="3" fill="#3b4249"/><path d="M82 135V184" stroke="#3b4249" stroke-width="5"/>',
      A:P(S,{hp:[80,128],sh:[94,82],hd:[102,66],kn:[118,130],ft:[120,184],to:[132,184],el:[124,106],ha:[146,128]}),
      B:P(S,{hp:[80,128],sh:[94,82],hd:[102,66],kn:[118,130],ft:[120,184],to:[132,184],el:[124,106],ha:[116,78]})},
    inclCurl:{view:'s',statics:benchIncl,A:P(S,{hd:[64,88],sh:[76,104],hp:[116,134],kn:[146,124],ft:[156,184],to:[168,184],el:[76,130],ha:[78,156]}),
      B:P(S,{hd:[64,88],sh:[76,104],hp:[116,134],kn:[146,124],ft:[156,184],to:[168,184],el:[78,130],ha:[94,106]})},
    wrist:{view:'s',statics:benchSeat,A:P(S,Object.assign({},SEAT,{el:[108,122],ha:[134,130]})),B:P(S,Object.assign({},SEAT,{el:[108,122],ha:[133,116]}))},
    farmer:{view:'s',segs:LUNGE,
      A:P(S,{hd:[100,40],sh:[100,58],hp:[100,108],el:[100,84],ha:[101,108],kn:[110,142],ft:[118,172],to:[130,174],kn2:[94,142],ft2:[84,170],to2:[94,176]}),
      B:P(S,{hd:[100,40],sh:[100,58],hp:[100,108],el:[100,84],ha:[101,108],kn:[94,142],ft:[84,170],to:[94,176],kn2:[110,142],ft2:[118,172],to2:[130,174]})},
    wroller:{view:'s',A:P(S,{el:[126,62],ha:[152,60]}),B:P(S,{el:[126,63],ha:[151,66]})},
    hangB:Object.assign({},T.pullupB,{B:T.pullupB.A,hold:true})
  });
})();
GROUPS.push(['unterarme','Unterarme']);
Object.assign(GVIEW,{unterarme:'f'}); Object.assign(HLG,{unterarme:['forearm']});
Object.assign(CAT,{'kh-bankdruecken':'mid','kh-fliegende':'iso','kabel-crossover-unten':'iso','kh-pullover':'iso','schraegbank-lh':'big',
  'fahrrad-crunch':'core','beinheben-liegend':'core','reverse-crunch':'core','bauchroller':'core','kabel-holzhacker':'core',
  'arnold-press':'mid','seitheben-kabel':'iso','frontheben-kabel':'iso','vorgebeugtes-seitheben':'iso','lh-schulterdruecken':'big','aufrechtes-rudern-kabel':'mid',
  'skullcrusher':'iso','kh-kickbacks':'iso','trizeps-ueberkopf-seil':'iso','trizepsdruecken-einarmig':'iso','enges-bankdruecken':'mid',
  'scottcurls':'iso','schraegbank-curls':'iso','seil-hammercurls':'iso','zottman-curls':'iso',
  'handgelenk-curls':'iso','reverse-handgelenk-curls':'iso','reverse-curls':'iso','farmers-walk':'mid','handgelenk-roller':'iso','dead-hang':'core'});
Object.assign(HLX,{'kh-bankdruecken':['chest','tricep','delt'],'kh-fliegende':['chest'],'kabel-crossover-unten':['chest','delt'],'kh-pullover':['chest','lat'],'schraegbank-lh':['chest','delt'],
  'fahrrad-crunch':['abs','oblique'],'beinheben-liegend':['abs'],'reverse-crunch':['abs'],'bauchroller':['abs','lat'],'kabel-holzhacker':['oblique','abs'],
  'arnold-press':['delt','tricep'],'seitheben-kabel':['delt'],'frontheben-kabel':['delt'],'vorgebeugtes-seitheben':['delt','back'],'lh-schulterdruecken':['delt','tricep'],'aufrechtes-rudern-kabel':['delt','trap'],
  'skullcrusher':['tricep'],'kh-kickbacks':['tricep'],'trizeps-ueberkopf-seil':['tricep'],'trizepsdruecken-einarmig':['tricep'],'enges-bankdruecken':['tricep','chest'],
  'scottcurls':['bicep'],'schraegbank-curls':['bicep'],'seil-hammercurls':['bicep','forearm'],'zottman-curls':['bicep','forearm'],
  'handgelenk-curls':['forearm'],'reverse-handgelenk-curls':['forearm'],'reverse-curls':['forearm','bicep'],'farmers-walk':['forearm','trap','abs'],'handgelenk-roller':['forearm','delt'],'dead-hang':['forearm','lat']});
const X=(id,name,g,anim,prop,prim,sec,equip,lvl,sets,steps,tips,err)=>({id,name,g,anim,prop,prim,sec,equip,lvl,sets,steps,tips,err,neu:true});
EX.push(
 // ---- Brust ----
 X('kh-bankdruecken','Kurzhantel-Bankdrücken',['brust','trizeps'],'bench','db','Große Brustmuskeln','Trizeps, vordere Schulter','Kurzhanteln, Flachbank','Anfänger','3–4 × 8–12',
  ['Mit den Hanteln auf den Oberschenkeln hinsetzen und zurücklegen, Hanteln auf Brusthöhe.','Schulterblätter zusammen, Füße fest am Boden.','Hanteln nach oben drücken, oben leicht zueinander führen.','Langsam bis auf Brusthöhe absenken.'],
  ['Größere Bewegung als mit der Langhantel – gut für die Dehnung.','Ellbogen ca. 45° vom Körper.'],['Hanteln oben zusammenschlagen.','Ellbogen ganz seitlich abspreizen.']),
 X('kh-fliegende','Kurzhantel-Fliegende (flach)',['brust'],'flyS','db','Große Brustmuskeln (innen & außen)','Vordere Schulter','Kurzhanteln, Flachbank','Anfänger','3 × 10–12',
  ['Auf die Flachbank legen, Hanteln über der Brust, Handflächen zueinander.','Ellbogen leicht gebeugt fixieren.','Arme in einem großen Bogen seitlich absenken, bis du die Dehnung in der Brust spürst.','Im gleichen Bogen wieder nach oben „umarmen“.'],
  ['Leichtes Gewicht – es geht um die Dehnung, nicht ums Drücken.','Wie beim Umarmen eines großen Baums.'],['Arme durchstrecken (Belastung fürs Ellbogengelenk).','Zu tief absenken.']),
 X('kabel-crossover-unten','Kabel-Crossover von unten',['brust','schultern'],'flyLowF','handle','Obere Brust','Vordere Schulter','Kabelzug (beide Rollen unten)','Fortgeschritten','3 × 12–15',
  ['Beide Rollen ganz unten einstellen, Griffe fassen, in die Mitte stellen.','Arme leicht gebeugt neben dem Körper.','Griffe schräg nach oben vor der Brust zusammenführen.','Oben kurz anspannen, langsam zurück.'],
  ['Trifft besonders die obere Brust.','Oberkörper aufrecht, Brust raus.'],['Mit dem Rücken mitziehen.','Ellbogen stark beugen (dann wird es ein Drücken).']),
 X('kh-pullover','Kurzhantel-Pullover',['brust','ruecken'],'pullover','db','Brust & Latissimus','Trizeps, Sägezahnmuskel','Eine Kurzhantel, Flachbank','Fortgeschritten','3 × 10–12',
  ['Auf die Bank legen, eine Hantel mit beiden Händen über der Brust halten.','Arme fast gestreckt lassen.','Hantel in einem Bogen hinter den Kopf absenken, bis die Oberarme neben den Ohren sind.','Im gleichen Bogen zurück über die Brust.'],
  ['Langsam und mit Gefühl – große Dehnung.','Bauch anspannen, kein starkes Hohlkreuz.'],['Zu schweres Gewicht.','Ellbogen beugen und es zu Trizepsdrücken machen.']),
 X('schraegbank-lh','Schrägbankdrücken (Langhantel)',['brust','schultern'],'incline','bar','Obere Brust','Vordere Schulter, Trizeps','Langhantel, Schrägbank','Fortgeschritten','3–4 × 6–10',
  ['Bank auf 30–45° stellen, Stange etwas breiter als schulterbreit greifen.','Stange aus der Ablage heben, über die obere Brust bringen.','Kontrolliert zur oberen Brust absenken.','Kraftvoll nach oben drücken.'],
  ['Mit Partner/Sicherung trainieren.','Füße fest auf dem Boden.'],['Bank zu steil.','Stange vom Brustkorb abprallen lassen.']),
 // ---- Bauch ----
 X('fahrrad-crunch','Fahrrad-Crunch',['bauch'],'bike','','Gerader & schräger Bauchmuskel','Hüftbeuger','Matte','Anfänger','3 × 20 (10 je Seite)',
  ['Auf den Rücken legen, Hände an die Schläfen, Schultern leicht angehoben.','Ein Knie zur Brust ziehen, das andere Bein strecken.','Gegenüberliegenden Ellbogen Richtung Knie drehen.','Seite wechseln wie beim Radfahren.'],
  ['Langsam und kontrolliert – nicht strampeln.','Unterer Rücken bleibt am Boden.'],['Am Kopf ziehen.','Nur die Ellbogen bewegen statt den Oberkörper zu drehen.']),
 X('beinheben-liegend','Beinheben liegend',['bauch'],'lyleg','','Unterer Bauch','Hüftbeuger','Matte','Anfänger','3 × 12–15',
  ['Auf den Rücken legen, Arme neben dem Körper, Handflächen unten.','Beine gestreckt zusammen.','Beine langsam bis ca. 90° anheben.','Langsam absenken, kurz vor dem Boden stoppen.'],
  ['Unteren Rücken in den Boden drücken.','Zu schwer? Knie leicht beugen.'],['Hohlkreuz beim Absenken.','Beine fallen lassen.']),
 X('reverse-crunch','Reverse Crunch',['bauch'],'revcrunch','','Unterer Bauch','Hüftbeuger','Matte','Anfänger','3 × 12–15',
  ['Auf den Rücken legen, Knie 90° gebeugt anheben.','Hände neben dem Körper am Boden.','Becken einrollen und Knie Richtung Brust ziehen, Po hebt leicht ab.','Langsam zurückrollen.'],
  ['Bewegung kommt aus dem Bauch, nicht aus dem Schwung.','Ausatmen beim Einrollen.'],['Mit Schwung arbeiten.','Kopf und Schultern hochziehen.']),
 X('bauchroller','Bauchroller (Ab-Wheel)',['bauch'],'rollout','db','Gesamter Bauch','Latissimus, Schultern, unterer Rücken','Bauchroller','Fortgeschritten','3 × 8–12',
  ['Auf die Knie, Bauchroller mit beiden Händen unter den Schultern.','Bauch fest anspannen, Rücken leicht rund.','Langsam nach vorn rollen, so weit du die Spannung halten kannst.','Mit dem Bauch wieder zurückziehen.'],
  ['Anfangs nur kurze Strecken rollen.','Po nicht nach oben schieben beim Zurückrollen.'],['Hohlkreuz – belastet den unteren Rücken.','Zu weit rollen.']),
 X('kabel-holzhacker','Kabel-Holzhacker',['bauch'],'woodF','handle','Schräge Bauchmuskeln','Gerader Bauch, Schultern','Kabelzug (Rolle oben), Griff/Seil','Fortgeschritten','3 × 12 je Seite',
  ['Seitlich zum Kabelzug stellen, Rolle oben, Griff mit beiden Händen.','Füße schulterbreit, Knie leicht gebeugt.','Griff diagonal von oben nach unten zur anderen Hüfte ziehen, Oberkörper dreht mit.','Kontrolliert zurück und Seite wechseln.'],
  ['Kraft kommt aus der Rumpfdrehung, Arme bleiben fast gestreckt.','Hintere Ferse darf sich mitdrehen.'],['Nur mit den Armen ziehen.','Rundrücken.']),
 // ---- Schultern ----
 X('arnold-press','Arnold Press',['schultern','trizeps'],'ohpF','db','Vordere & seitliche Schulter','Trizeps','Kurzhanteln, Bank mit Lehne','Fortgeschritten','3 × 8–12',
  ['Hanteln vor der Brust halten, Handflächen zeigen zu dir.','Beim Hochdrücken die Hände nach außen drehen.','Oben zeigen die Handflächen nach vorn.','Beim Absenken wieder zurückdrehen.'],
  ['Große Bewegung – trifft alle Schulterbereiche.','Sitzend mit Lehne ist es rückenschonender.'],['Zu schweres Gewicht.','Hohlkreuz beim Drücken.']),
 X('seitheben-kabel','Seitheben am Kabel',['schultern'],'latCableF','handle','Seitliche Schulter','Trapez','Kabelzug (Rolle unten), Griffe','Anfänger','3 × 12–15',
  ['Rollen unten, Griffe fassen, aufrecht stehen.','Arme leicht gebeugt neben dem Körper.','Arme seitlich bis Schulterhöhe heben.','Langsam absenken – das Kabel hält die Spannung.'],
  ['Konstante Spannung über die ganze Bewegung.','Auch einarmig sehr effektiv.'],['Schultern hochziehen.','Mit dem Körper schwingen.']),
 X('frontheben-kabel','Frontheben am Kabel',['schultern'],'frontCable','handle','Vordere Schulter','Obere Brust','Kabelzug (Rolle unten), Griff oder Seil','Anfänger','3 × 12',
  ['Mit dem Rücken zum Kabelzug stehen, Griff zwischen den Beinen.','Arm(e) fast gestreckt.','Griff nach vorn bis auf Schulterhöhe heben.','Langsam zurückführen.'],
  ['Nicht höher als Schulterhöhe.','Bauch fest.'],['Schwung aus dem Rücken.','Arme ganz durchstrecken.']),
 X('vorgebeugtes-seitheben','Vorgebeugtes Seitheben (Kurzhantel)',['schultern','ruecken'],'revflyB','db','Hintere Schulter','Oberer Rücken, Trapez','Kurzhanteln','Anfänger','3 × 12–15',
  ['Oberkörper mit geradem Rücken weit nach vorn beugen.','Hanteln hängen unter der Brust, Arme leicht gebeugt.','Arme seitlich nach oben führen, Schulterblätter zusammen.','Langsam absenken.'],
  ['Kleines Gewicht – die hintere Schulter ist schwach.','Kopf in Verlängerung der Wirbelsäule.'],['Aufrichten mit Schwung.','Rundrücken.']),
 X('lh-schulterdruecken','Schulterdrücken stehend (Langhantel)',['schultern','trizeps'],'ohpF','bar','Vordere & seitliche Schulter','Trizeps, Rumpf','Langhantel','Fortgeschritten','3–4 × 6–10',
  ['Stange auf Schulterhöhe vor dem Körper, schulterbreit greifen.','Bauch und Po fest anspannen.','Stange gerade über den Kopf drücken, Kopf leicht zurück.','Kontrolliert zur Schulter absenken.'],
  ['Klassische Kraftübung für breite Schultern.','Unterarme senkrecht unter der Stange.'],['Starkes Hohlkreuz.','Mit den Beinen Schwung holen.']),
 X('aufrechtes-rudern-kabel','Aufrechtes Rudern am Kabel',['schultern','nacken'],'uprowCable','handle','Seitliche Schulter, Trapez','Bizeps','Kabelzug (Rolle unten), Stange/Seil','Anfänger','3 × 12',
  ['Rolle unten, Stange oder Seil fassen, aufrecht stehen.','Griff nah am Körper nach oben ziehen.','Ellbogen führen, bis etwa Brusthöhe.','Langsam absenken.'],
  ['Nicht höher als Brust ziehen – schont die Schulter.','Etwas breiter greifen ist angenehmer.'],['Zu hoch ziehen.','Schwung holen.']),
 // ---- Trizeps ----
 X('skullcrusher','Skull Crusher (French Press)',['trizeps'],'skull','bar','Trizeps (langer Kopf)','','SZ-Stange oder Langhantel, Flachbank','Fortgeschritten','3 × 8–12',
  ['Auf die Bank legen, Stange mit gestreckten Armen über der Brust.','Oberarme bleiben senkrecht und fest.','Nur die Unterarme beugen, Stange Richtung Stirn/hinter den Kopf.','Wieder nach oben strecken.'],
  ['SZ-Stange schont die Handgelenke.','Langsam ablassen – Stirn schützen!'],['Ellbogen gehen weit auseinander.','Oberarme bewegen sich mit.']),
 X('kh-kickbacks','Kurzhantel-Kickbacks',['trizeps'],'kickback','db','Trizeps','','Kurzhantel(n), evtl. Bank','Anfänger','3 × 12 je Arm',
  ['Oberkörper nach vorn beugen, Rücken gerade, evtl. auf Bank abstützen.','Oberarm parallel zum Körper fixieren.','Unterarm nach hinten strecken, bis der Arm gerade ist.','Kurz halten, langsam zurück.'],
  ['Oben den Trizeps fest anspannen.','Lieber leichter und sauber.'],['Oberarm schwingt mit.','Mit Schwung arbeiten.']),
 X('trizeps-ueberkopf-seil','Trizepsdrücken über Kopf am Seil',['trizeps'],'ohCable','handle','Trizeps (langer Kopf)','','Kabelzug, Seil','Anfänger','3 × 12',
  ['Rolle unten, Seil fassen, mit dem Rücken zum Kabelzug stellen.','Seil hinter den Kopf führen, Ellbogen zeigen nach oben.','Arme über dem Kopf strecken.','Langsam wieder hinter den Kopf.'],
  ['Großer Dehnreiz für den Trizeps.','Ein Fuß vor dem anderen für Stabilität.'],['Ellbogen weit auseinander.','Hohlkreuz.']),
 X('trizepsdruecken-einarmig','Trizepsdrücken einarmig am Kabel',['trizeps'],'pushdown','handle','Trizeps','','Kabelzug (Rolle oben), Einhandgriff','Anfänger','3 × 12 je Arm',
  ['Rolle oben, Einhandgriff fassen.','Ellbogen eng am Körper.','Griff nach unten drücken, bis der Arm gestreckt ist.','Langsam zurück bis Brusthöhe.'],
  ['Gut, um Seitenunterschiede auszugleichen.','Auch im Untergriff möglich.'],['Ellbogen wandert nach vorn.','Oberkörper drückt mit.']),
 X('enges-bankdruecken','Enges Bankdrücken',['trizeps','brust'],'bench','bar','Trizeps','Innere Brust, vordere Schulter','Langhantel, Flachbank','Fortgeschritten','3 × 6–10',
  ['Auf die Bank legen, Stange etwa schulterbreit greifen.','Ellbogen beim Absenken nah am Körper.','Stange zur unteren Brust absenken.','Kraftvoll hochdrücken.'],
  ['Eine der besten Übungen für Trizeps-Masse.','Nicht zu eng greifen – schont die Handgelenke.'],['Ellbogen weit seitlich.','Zu enger Griff.']),
 // ---- Bizeps ----
 X('scottcurls','Scott-Curls (Preacher Curls)',['bizeps'],'preacher','bar','Bizeps (unterer Teil)','Unterarme','SZ-Stange oder Kurzhantel, Scottbank','Anfänger','3 × 10–12',
  ['Auf die Scottbank setzen, Oberarme flach auf das Polster.','Stange im Untergriff, Arme fast gestreckt.','Stange nach oben beugen.','Langsam ablassen, nicht ganz durchstrecken.'],
  ['Kein Schwung möglich – sehr gezielt.','Unten kontrolliert, das schützt die Sehne.'],['Ellbogen hebt vom Polster ab.','Unten fallen lassen.']),
 X('schraegbank-curls','Schrägbank-Curls',['bizeps'],'inclCurl','db','Bizeps (langer Kopf)','Unterarme','Kurzhanteln, Schrägbank','Fortgeschritten','3 × 10–12',
  ['Bank auf ca. 45–60°, zurücklehnen, Arme hängen nach unten.','Handflächen zeigen nach vorn.','Hanteln nach oben beugen, Oberarme bleiben hinten.','Langsam ablassen bis zur vollen Dehnung.'],
  ['Durch die Dehnung sehr effektiv.','Leichter beginnen als bei normalen Curls.'],['Schultern nach vorn schieben.','Halbe Bewegung.']),
 X('seil-hammercurls','Hammer-Curls am Seil',['bizeps','unterarme'],'ropecurl','rope','Bizeps, Oberarmmuskel','Unterarme','Kabelzug (Rolle unten), Seil','Anfänger','3 × 12',
  ['Rolle unten, Seil mit neutralem Griff (Daumen oben).','Ellbogen am Körper.','Seil nach oben beugen, Enden oben leicht auseinander.','Langsam ablassen.'],
  ['Konstante Spannung durch das Kabel.','Gut für dicke Oberarme.'],['Ellbogen nach vorn.','Oberkörper lehnt zurück.']),
 X('zottman-curls','Zottman-Curls',['bizeps','unterarme'],'curl','db','Bizeps & Unterarme','Oberarmmuskel','Kurzhanteln','Fortgeschritten','3 × 10',
  ['Hanteln im Untergriff hochbeugen wie beim Curl.','Oben die Hände drehen (Handrücken nach oben).','Im Obergriff langsam absenken.','Unten zurückdrehen.'],
  ['Trainiert Bizeps und Unterarm in einer Übung.','Absenken langsam (3 Sek.).'],['Zu schweres Gewicht beim Absenken.','Schwung.']),
 // ---- Unterarme & Handgelenk ----
 X('handgelenk-curls','Handgelenk-Curls',['unterarme'],'wrist','db','Unterarm-Beuger','Griffkraft','Kurzhantel(n), Bank','Anfänger','3 × 15–20',
  ['Hinsetzen, Unterarme auf die Oberschenkel, Handgelenke über die Knie.','Hantel im Untergriff (Handfläche oben).','Nur das Handgelenk nach oben beugen.','Langsam absenken, Hantel darf in die Finger rollen.'],
  ['Hohe Wiederholungen, leichtes Gewicht.','Stärkt Griff und Handgelenke.'],['Unterarme heben vom Oberschenkel ab.','Zu schwer – das belastet die Sehnen.']),
 X('reverse-handgelenk-curls','Reverse Handgelenk-Curls',['unterarme'],'wrist','db','Unterarm-Strecker','Handgelenk-Stabilität','Kurzhantel(n), Bank','Anfänger','3 × 15',
  ['Wie Handgelenk-Curls, aber Hantel im Obergriff (Handrücken oben).','Unterarme auf den Oberschenkeln.','Handrücken nach oben ziehen.','Langsam absenken.'],
  ['Sehr leichtes Gewicht nehmen.','Gut gegen Ellbogen-/Handgelenksschmerzen durch Ausgleich.'],['Zu schwer.','Ruckartige Bewegungen.']),
 X('reverse-curls','Reverse Curls (Obergriff)',['unterarme','bizeps'],'curl','bar','Unterarme, Oberarmspeichenmuskel','Bizeps','SZ-Stange oder Langhantel','Anfänger','3 × 10–12',
  ['Stange im Obergriff schulterbreit halten.','Ellbogen am Körper.','Stange nach oben beugen, Handrücken bleiben oben.','Langsam absenken.'],
  ['SZ-Stange schont die Handgelenke.','Weniger Gewicht als bei normalen Curls.'],['Handgelenke knicken ab.','Schwung.']),
 X('farmers-walk','Farmer’s Walk (Hanteln tragen)',['unterarme','nacken'],'farmer','db','Griffkraft, Unterarme','Trapez, Rumpf, Beine','Schwere Kurzhanteln','Anfänger','3 × 30–40 m',
  ['Zwei schwere Hanteln greifen, aufrecht hinstellen.','Schultern unten und hinten, Bauch fest.','Mit kurzen, schnellen Schritten gehen.','Am Ziel kontrolliert absetzen.'],
  ['Einfach, aber extrem effektiv für den Griff.','Blick nach vorn.'],['Schultern hängen nach vorn.','Hanteln pendeln lassen.']),
 X('handgelenk-roller','Handgelenk-Roller',['unterarme'],'wroller','handle','Unterarm-Beuger & -Strecker','Vordere Schulter (halten)','Handgelenk-Roller (Stab mit Seil und Gewicht)','Anfänger','3 × 2–3 Durchgänge',
  ['Roller mit gestreckten Armen vor dem Körper halten.','Durch Drehen der Handgelenke das Seil aufwickeln.','Gewicht ganz nach oben drehen.','Langsam wieder abwickeln.'],
  ['Brennt stark – Pausen sind normal.','Auch rückwärts drehen für die Strecker.'],['Arme sinken ab.','Zu schweres Gewicht.']),
 X('dead-hang','Hängen an der Stange (Dead Hang)',['unterarme','ruecken'],'hangB','','Griffkraft, Unterarme','Latissimus, Schultern','Klimmzugstange','Anfänger','3 × 20–45 Sek.',
  ['Stange schulterbreit im Obergriff greifen.','Arme gestreckt, ruhig hängen.','Schultern leicht nach unten ziehen.','Zeit halten, dann kontrolliert loslassen.'],
  ['Super für Griff und Schulter-Beweglichkeit.','Gute Vorbereitung für Klimmzüge.'],['Schwingen.','Nur mit den Fingerspitzen halten.'])
);

/* ===== Maschinen-Übungen (Einsteiger-freundlich) ===== */
(function(){
  const MSEAT='<rect x="62" y="66" width="8" height="62" rx="3" fill="#3b4249"/><rect x="62" y="128" width="50" height="7" rx="3" fill="#3b4249"/><path d="M86 135V184" stroke="#3b4249" stroke-width="5"/>';
  const SEAT={hp:[80,126],sh:[80,74],hd:[82,56],kn:[120,128],ft:[122,184],to:[134,184]};
  const SF={hd:[100,64],nk:[100,80],shL:[85,84],shR:[115,84],pv:[100,135],hpL:[90,137],hpR:[110,137],knL:[86,150,30],ftL:[86,184,34],knR:[114,150,30],ftR:[114,184,34]};
  const SFST='<rect x="70" y="138" width="60" height="8" rx="3" fill="#3b4249"/><path d="M100 146V184" stroke="#3b4249" stroke-width="5"/>';
  const o=(a,b)=>Object.assign({},a,b);
  Object.assign(T,{
    pecdeck:{view:'s',statics:MSEAT,A:P(S,o(SEAT,{el:[82,76],ha:[82,50],lw:[46,44]})),B:P(S,o(SEAT,{el:[104,74],ha:[106,50],lw:[12,8]}))},
    inclPressM:{view:'s',statics:'<path d="M60 66L72 128" stroke="#3b4249" stroke-width="8" stroke-linecap="round"/><rect x="66" y="128" width="50" height="7" rx="3" fill="#3b4249"/><path d="M90 135V184" stroke="#3b4249" stroke-width="5"/>',
      A:P(S,{hp:[84,126],sh:[72,76],hd:[70,58],kn:[122,128],ft:[124,184],to:[136,184],el:[62,100],ha:[84,88]}),
      B:P(S,{hp:[84,126],sh:[72,76],hd:[70,58],kn:[122,128],ft:[124,184],to:[136,184],el:[94,64],ha:[114,48]})},
    latpullS:{view:'s',cable:[100,0],statics:'<rect x="60" y="146" width="54" height="7" rx="3" fill="#3b4249"/><path d="M86 153V184" stroke="#3b4249" stroke-width="5"/><rect x="112" y="126" width="16" height="8" rx="3" fill="#3b4249"/><path d="M120 134V184" stroke="#3b4249" stroke-width="4"/>',
      A:P(S,{hp:[86,138],sh:[86,88],hd:[90,70],kn:[122,140],ft:[124,184],to:[136,184],el:[94,58],ha:[100,30],lw:[22,6]}),
      B:P(S,{hp:[86,138],sh:[84,88],hd:[86,70],kn:[122,140],ft:[124,184],to:[136,184],el:[82,112],ha:[100,92],lw:[22,6]})},
    rowM:{view:'s',statics:MSEAT.replace('<rect x="62" y="66" width="8" height="62" rx="3" fill="#3b4249"/>','')+'<rect x="110" y="78" width="8" height="44" rx="3" fill="#3b4249"/><path d="M114 122V184" stroke="#3b4249" stroke-width="5"/>',
      A:P(S,o(SEAT,{sh:[86,74],hd:[90,56],el:[110,86],ha:[136,90]})),B:P(S,o(SEAT,{sh:[84,74],hd:[88,56],el:[62,92],ha:[92,92]}))},
    backExtM:{view:'s',backPad:true,statics:MSEAT.replace('<rect x="62" y="66" width="8" height="62" rx="3" fill="#3b4249"/>',''),
      A:P(S,o(SEAT,{sh:[108,86],hd:[122,74],el:[120,104],ha:[121,90],lw:[20,-9]})),B:P(S,o(SEAT,{sh:[72,75],hd:[73,57],el:[86,92],ha:[87,79],lw:[20,-9]}))},
    hyper:{view:'s',statics:'<path d="M78 152L104 126" stroke="#3b4249" stroke-width="8" stroke-linecap="round"/><path d="M36 182L46 172" stroke="#3b4249" stroke-width="8" stroke-linecap="round"/><path d="M46 178L96 140M90 146V184M50 176V184" stroke="#3a4146" stroke-width="4"/>',
      prone:true,dynFront:true,
      A:P(S,{ft:[42,174],to:[36,182],kn:[66,154],hp:[94,130],sh:[118,164],hd:[128,176],el:[112,150],ha:[118,156]}),
      B:P(S,{ft:[42,174],to:[36,182],kn:[66,154],hp:[94,130],sh:[134,98],hd:[148,86],el:[128,112],ha:[124,106]})},
    latSeatF:{view:'f',statics:SFST,A:P(F,o(SF,arms([80,110],[79,132]))),B:P(F,o(SF,arms([60,86],[38,86])))},
    abd:{view:'s',statics:MSEAT,A:P(S,o(SEAT,{el:[84,100],ha:[94,124],lwl:[12,12]})),B:P(S,o(SEAT,{el:[84,100],ha:[94,124],lwl:[34,26]}))},
    add:{view:'s',statics:MSEAT,A:P(S,o(SEAT,{el:[84,100],ha:[94,124],lwl:[34,26]})),B:P(S,o(SEAT,{el:[84,100],ha:[94,124],lwl:[9,10]}))},
    gluteKick:{view:'s',segs:LUNGE,cableFoot:[18,180],statics:tower(8)+'<path d="M150 60V184M140 96H160" stroke="#3b4249" stroke-width="5"/>',
      A:P(S,{hp:[100,115],sh:[124,78],hd:[134,64],el:[138,92],ha:[150,96],kn:[100,150],ft:[100,184],to:[113,184],kn2:[106,148],ft2:[100,180],to2:[110,182]}),
      B:P(S,{hp:[100,115],sh:[124,78],hd:[134,64],el:[138,92],ha:[150,96],kn:[100,150],ft:[100,184],to:[113,184],kn2:[72,134],ft2:[48,122],to2:[42,130]})},
    legCurlLy:{view:'s',prone:true,pad:true,statics:'<rect x="40" y="132" width="114" height="8" rx="3" fill="#3b4249"/><path d="M54 140V184M140 140V184" stroke="#3b4249" stroke-width="5"/>',
      A:P(S,{hd:[40,118],sh:[58,122],hp:[110,124],kn:[146,126],ft:[180,128],to:[186,138],el:[50,136],ha:[58,130]}),
      B:P(S,{hd:[40,118],sh:[58,122],hp:[110,124],kn:[146,126],ft:[150,92],to:[160,86],el:[50,136],ha:[58,130]})}
  });
})();
GROUPS.push(['maschinen','Maschinen']);
Object.assign(GVIEW,{maschinen:'f'}); Object.assign(HLG,{maschinen:['chest','lat','delt']});
for(const e of EX) if(['brustpresse','schulterpresse-maschine','reverse-butterfly','latzug','kabelrudern-sitzend','beinpresse','beinstrecker','beinbeuger'].includes(e.id)&&!e.g.includes('maschinen')) e.g.push('maschinen');
Object.assign(CAT,{'butterfly-maschine':'iso','schraeg-brustpresse-maschine':'mid','dip-maschine':'mid','latzug-eng':'mid','latzug-untergriff':'mid','rudermaschine':'mid','klimmzug-maschine':'mid',
  'rueckenstrecker-maschine':'iso','hyperextension':'core','seitheben-maschine':'iso','smith-schulterdruecken':'mid','abduktoren-maschine':'iso','adduktoren-maschine':'iso','glute-kickback-kabel':'iso','beinbeuger-liegend':'iso'});
Object.assign(HLX,{'butterfly-maschine':['chest'],'schraeg-brustpresse-maschine':['chest','delt','tricep'],'dip-maschine':['tricep','chest'],'latzug-eng':['lat','back','bicep'],'latzug-untergriff':['lat','bicep'],
  'rudermaschine':['back','lat','delt'],'klimmzug-maschine':['lat','bicep'],'rueckenstrecker-maschine':['erector','glute'],'hyperextension':['erector','glute','ham'],'seitheben-maschine':['delt'],
  'smith-schulterdruecken':['delt','tricep'],'abduktoren-maschine':['glute'],'adduktoren-maschine':['quad'],'glute-kickback-kabel':['glute','ham'],'beinbeuger-liegend':['ham','calf']});
const EASY='Einsteiger: mit einer niedrigen Gewichtsstufe (1–3) beginnen und erst steigern, wenn 15 saubere Wiederholungen gehen.';
const MX=(...a)=>Object.assign(X(...a),{neuDate:'2026-11-22'});
EX.push(
 MX('butterfly-maschine','Butterfly an der Maschine',['brust','maschinen'],'pecdeck','handle','Große Brustmuskeln (innen)','Vordere Schulter','Butterfly-Maschine','Anfänger','3 × 12–15',
  ['Sitz so einstellen, dass die Griffe/Polster auf Brusthöhe sind.','Rücken fest an die Lehne, Unterarme an die Polster oder Griffe fassen.','Arme in einem Bogen vor der Brust zusammenführen.','Kurz anspannen, langsam zurück bis zur leichten Dehnung.'],
  [EASY,'Sehr gelenkschonend – ideal statt Kurzhantel-Fliegende.'],['Zu weit nach hinten öffnen.','Schultern nach vorn rollen.']),
 MX('schraeg-brustpresse-maschine','Schräg-Brustpresse (Maschine)',['brust','maschinen'],'inclPressM','handle','Obere Brust','Vordere Schulter, Trizeps','Schrägbank-Brustpresse','Anfänger','3 × 10–12',
  ['Sitz so einstellen, dass die Griffe auf Höhe der oberen Brust sind.','Rücken und Kopf an das Polster.','Griffe schräg nach oben drücken, Arme fast strecken.','Langsam zurück, bis die Brust leicht gedehnt ist.'],
  [EASY,'Geführte Bewegung – sicher ohne Partner.'],['Rücken vom Polster lösen.','Ellbogen ganz durchdrücken.']),
 MX('dip-maschine','Dips an der Maschine (unterstützt)',['trizeps','brust','maschinen'],'dip','','Trizeps, untere Brust','Vordere Schulter','Dip-/Klimmzug-Maschine mit Kniepolster','Anfänger','3 × 8–12',
  ['Gegengewicht einstellen – mehr Gewicht = mehr Hilfe.','Knie auf das Polster, Griffe fassen, Arme gestreckt.','Langsam absenken, bis die Oberarme etwa waagerecht sind.','Kraftvoll hochdrücken.'],
  ['Viel Unterstützung zu Beginn ist völlig okay – nach und nach reduzieren.','Oberkörper aufrecht = mehr Trizeps.'],['Zu tief absenken.','Schultern hochziehen.']),
 MX('latzug-eng','Latzug eng (V-Griff)',['ruecken','maschinen'],'latpullS','handle','Latissimus, mittlerer Rücken','Bizeps','Latzugmaschine, V-Griff','Anfänger','3 × 10–12',
  ['V-Griff einhängen, Oberschenkel unter das Polster.','Leicht zurücklehnen, Brust raus.','Griff zur oberen Brust ziehen, Ellbogen eng nach unten.','Langsam nach oben, bis die Arme gestreckt sind.'],
  [EASY,'Gut für einen dicken, starken Rücken.'],['Mit dem Oberkörper weit nach hinten reißen.','Schultern hochziehen.']),
 MX('latzug-untergriff','Latzug im Untergriff',['ruecken','bizeps','maschinen'],'latpullS','handle','Latissimus','Bizeps','Latzugmaschine, gerade Stange','Anfänger','3 × 10–12',
  ['Stange schulterbreit im Untergriff (Handflächen zu dir).','Oberschenkel fixieren, leicht zurücklehnen.','Stange zur Brust ziehen.','Kontrolliert nach oben.'],
  [EASY,'Leichter als der breite Latzug – guter Einstieg für Klimmzüge.'],['Mit Schwung ziehen.','Halbe Bewegung.']),
 MX('rudermaschine','Rudermaschine (Brust gestützt)',['ruecken','maschinen'],'rowM','handle','Mittlerer Rücken, Latissimus','Hintere Schulter, Bizeps','Rudermaschine mit Brustpolster','Anfänger','3 × 10–12',
  ['Sitz so einstellen, dass die Griffe auf Brusthöhe sind.','Brust fest ans Polster.','Griffe nach hinten ziehen, Schulterblätter zusammen.','Langsam nach vorn, bis die Arme gestreckt sind.'],
  [EASY,'Das Brustpolster schont den unteren Rücken – ideal für Einsteiger.'],['Brust vom Polster lösen.','Schultern hochziehen.']),
 MX('klimmzug-maschine','Klimmzüge an der Maschine (unterstützt)',['ruecken','bizeps','maschinen'],'pullupB','','Latissimus','Bizeps, hintere Schulter','Klimmzug-Maschine mit Gegengewicht','Anfänger','3 × 8–10',
  ['Gegengewicht wählen – mehr Gewicht = mehr Hilfe.','Knie auf das Polster, Griffe weit fassen.','Hochziehen, bis das Kinn über den Griffen ist.','Langsam ablassen.'],
  ['Perfekter Weg zum ersten echten Klimmzug.','Jede Woche etwas weniger Unterstützung.'],['Schwung holen.','Nur halbe Wiederholungen.']),
 MX('rueckenstrecker-maschine','Rückenstrecker-Maschine',['ruecken','maschinen'],'backExtM','','Unterer Rücken','Po, Beinbeuger','Rückenstrecker-Maschine','Anfänger','3 × 12–15',
  ['Sitz einstellen, Polster liegt am oberen Rücken.','Füße fest, Arme vor der Brust verschränkt.','Oberkörper langsam nach hinten strecken.','Kontrolliert nach vorn zurück.'],
  [EASY,'Stärkt den unteren Rücken – gut gegen Rückenschmerzen.'],['Ruckartig nach hinten werfen.','Zu weit überstrecken.']),
 MX('hyperextension','Hyperextension (Rückenstrecken)',['ruecken','po','maschinen'],'hyper','','Unterer Rücken','Po, Beinbeuger','45°-Hyperextension-Bank','Anfänger','3 × 12–15',
  ['Polster knapp unter dem Hüftknochen einstellen, Füße fixieren.','Arme vor der Brust verschränken.','Oberkörper mit geradem Rücken absenken.','Bis zur geraden Linie aufrichten – nicht überstrecken.'],
  ['Langsam und kontrolliert.','Für mehr Po: Rücken leicht rund, Po fest anspannen.'],['Hohlkreuz oben.','Schwung.']),
 MX('seitheben-maschine','Seitheben an der Maschine',['schultern','maschinen'],'latSeatF','handle','Seitliche Schulter','Trapez','Seitheben-Maschine','Anfänger','3 × 12–15',
  ['Sitz so einstellen, dass die Schultern auf Höhe des Drehpunkts sind.','Arme an die Polster legen.','Arme seitlich bis Schulterhöhe heben.','Langsam absenken.'],
  [EASY,'Geführt – perfekt für schöne, runde Schultern.'],['Schultern hochziehen.','Mit Schwung arbeiten.']),
 MX('smith-schulterdruecken','Schulterdrücken an der Smith-Maschine',['schultern','trizeps','maschinen'],'ohpSeatF','bar','Vordere & seitliche Schulter','Trizeps','Smith-Maschine, Bank mit Lehne','Anfänger','3 × 10',
  ['Bank unter die Stange stellen, Lehne fast senkrecht.','Stange etwas breiter als schulterbreit greifen und aushaken.','Stange vom Kinn nach oben drücken.','Langsam bis Kinnhöhe absenken, Haken drehen zum Ablegen.'],
  [EASY,'Die Führung sorgt für Sicherheit ohne Partner.'],['Stange in den Nacken absenken.','Hohlkreuz.']),
 MX('abduktoren-maschine','Abduktoren-Maschine (Beine auseinander)',['po','beine','maschinen'],'abd','handle','Seitlicher Po (Gluteus medius)','Hüfte','Abduktoren-Maschine','Anfänger','3 × 15–20',
  ['Hinsetzen, Polster außen an den Knien.','Rücken an die Lehne, Griffe fassen.','Beine kontrolliert nach außen drücken.','Langsam zurück, Gewicht nicht absetzen.'],
  [EASY,'Für einen runden, straffen Po – ein Klassiker im Frauentraining.'],['Mit Schwung arbeiten.','Gewichte zurückfallen lassen.']),
 MX('adduktoren-maschine','Adduktoren-Maschine (Beine zusammen)',['beine','maschinen'],'add','handle','Innenschenkel (Adduktoren)','','Adduktoren-Maschine','Anfänger','3 × 15–20',
  ['Hinsetzen, Polster innen an den Knien.','Startweite so wählen, dass es angenehm dehnt.','Beine kontrolliert zusammendrücken.','Langsam öffnen.'],
  [EASY,'Strafft die Innenseite der Oberschenkel.'],['Zu weite Startposition.','Ruckartige Bewegungen.']),
 MX('glute-kickback-kabel','Po-Kickback am Kabel',['po','maschinen'],'gluteKick','','Großer Po-Muskel','Beinbeuger','Kabelzug (Rolle unten), Fußschlaufe','Anfänger','3 × 12–15 je Bein',
  ['Fußschlaufe am Knöchel, mit Blick zum Kabelzug stellen.','Oberkörper leicht nach vorn, am Gerät festhalten.','Bein gestreckt nach hinten-oben drücken, Po fest anspannen.','Langsam zurück, Seite wechseln.'],
  [EASY,'Oben 1 Sekunde halten – da arbeitet der Po am meisten.'],['Ins Hohlkreuz gehen.','Mit Schwung kicken.']),
 MX('beinbeuger-liegend','Beinbeuger liegend',['beine','po','maschinen'],'legCurlLy','','Hintere Oberschenkel','Waden, Po','Beinbeuger-Maschine (liegend)','Anfänger','3 × 12–15',
  ['Bäuchlings auf die Maschine legen, Polster über den Fersen.','Griffe vorne festhalten, Hüfte bleibt auf dem Polster.','Fersen Richtung Po ziehen.','Langsam wieder strecken.'],
  [EASY,'Hüfte unten lassen – dann arbeiten die Beinbeuger richtig.'],['Hüfte hebt ab.','Gewicht fallen lassen.'])
);
const THUMB={};
const thumb=k=>THUMB[k]||(THUMB[k]=figure({anim:GVIEW[k]==='b'?'standB':'standF',prop:'',hl:k==='alle'?['chest','abs','delt','bicep','quad']:HLG[k]},0).replace('viewBox="0 0 200 200"','viewBox="50 26 100 166"'));
function renderChips(){
  const list=[['alle','Alle',EX.length],...GROUPS.map(([k,n])=>[k,n,EX.filter(e=>e.g.includes(k)).length]),['favs','Gemerkt',favs.length]];
  $('chips').innerHTML=list.map(([k,n,c])=>`<button class="gcard ${group===k?'on':''}" data-g="${k}"><span class="gf">${k==='favs'?'⭐':thumb(k)}</span><span class="gl">${n}<small>${c} Übungen</small></span></button>`).join('');
}
function renderGrid(){
  const q=query.trim().toLowerCase();
  let items=EX.filter(e=> group==='alle' ? true : group==='favs' ? favs.includes(e.id) : e.g.includes(group));
  if(q) items=items.filter(e=>{ const t=e.name+' '+e.prim+' '+e.sec+' '+e.g.map(gname).join(' '); return (t+' '+(LANG==='en'?[e.name,e.prim,e.sec,...e.g.map(gname)].map(x=>tr(x)).join(' '):'')).toLowerCase().includes(q); });
  $('sectitle').textContent = (group==='alle'?'Alle Übungen':group==='favs'?'Gemerkte Übungen':gname(group)) + ` · ${items.length}`;
  $('grid').innerHTML = items.length ? items.map(e=>`
    <button class="card" data-id="${e.id}">
      <span class="fig">${figure(e,0.65)}${isLocked(e)?'<span class="lock">🔒 Vollversion</span>':''}</span>
      <span class="meta"><h3>${esc(e.name)} ${favs.includes(e.id)?'<span class="fav">★</span>':''}${isNewEx(e)?'<span class="newtag">NEU</span>':''}</h3><div class="sub">${esc(e.prim)}</div></span>
    </button>`).join('') : `<div class="empty">${group==='favs'?'Noch nichts gemerkt – öffne eine Übung und tippe auf „☆ Merken“.':'Keine Übung gefunden.'}</div>`;
}

let cur=null, raf=0, t0=0, speed=1, paused=false, pausedAt=0;
/* =====================================================================
   BILD-MODUS: fertige Bilder pro Übung (Start / Mitte / Ende) statt 3D
   Dateien in den Ordner „bilder“ legen: bilder/<übungs-id>-1.jpg, -2.jpg, -3.jpg
   (2 oder 3 Bilder). Fehlen sie, zeigt die App automatisch die 3D-Figur.
   ===================================================================== */
const IMGV={on:false,n:0,id:'',srcs:[],cache:{}};
const IMG_DIR='bilder/';
function probeImg(src){ return new Promise(res=>{ const im=new Image(); im.onload=()=>res(src); im.onerror=()=>res(null); im.src=src; }); }
async function findImgs(id){ if(IMGV.cache[id]) return IMGV.cache[id]; const out=[];
  for(let i=1;i<=3;i++){ const s=await probeImg(IMG_DIR+id+'-'+i+'.jpg'); if(!s) break; out.push(s); }
  IMGV.cache[id]=out.length>=2?out:(out.length===1?out:[]); return IMGV.cache[id]; }
function imgMode(e,srcs){ const st=document.querySelector('#detail .stage'); if(!st||!srcs.length) return;
  IMGV.on=true; IMGV.n=srcs.length; IMGV.id=e.id; IMGV.srcs=srcs; st.classList.add('imgmode');
  let v=st.querySelector('.imgv'); if(!v){ v=document.createElement('div'); v.className='imgv'; st.insertBefore(v,st.firstChild); }
  v.innerHTML=srcs.map((s,i)=>`<img src="${s}" alt="" data-f="${i}" style="opacity:${i?0:1}">`).join('')+'<div class="imgstrip"></div>';
  const strip=v.querySelector('.imgstrip');
  strip.innerHTML=srcs.map((s,i)=>`<button type="button" data-jf="${i}"><img src="${s}" alt=""></button>`).join('');
  strip.querySelectorAll('[data-jf]').forEach(b=>b.onclick=()=>{ const i=+b.dataset.jf, ph=srcs.length>1?i/(srcs.length-1):0, x=ph*0.4;
    const sc=$('mlScr'); if(sc){ sc.value=Math.round(x*1000); sc.dispatchEvent(new Event('input')); } });
  let lab=st.querySelector('.imglab'); if(!lab){ lab=document.createElement('div'); lab.className='imglab'; st.appendChild(lab); }
  const k=['chest','lat','quad','glute','delt','bicep','tricep','ham','abs','calf','trap','back','erector','oblique','forearm','neck'].find(x=>hlOf(e).has(x));
  lab.innerHTML=k&&LAT_N[k]?`<b>${esc(MUS_S[k]||e.prim.split(',')[0])}</b> <i>(${LAT_N[k]})</i>`:`<b>${esc(e.prim)}</b>`;
  let reps=v.querySelector('.imgreps'); if(!reps){ reps=document.createElement('div'); reps.className='imgreps'; v.appendChild(reps); }
  reps.innerHTML=`<small>Sätze × Wdh.</small><b>${esc(e.sets)}</b>`;
  const mc=$('mlCam'); if(mc) mc.classList.add('imgcam'); $('detail').classList.add('imgon'); updViewBtn(); }
function imgFrame(ph){ const v=document.querySelector('#detail .imgv'); if(!v) return; const n=IMGV.n, f=Math.max(0,Math.min(n-1,ph*(n-1))), a=Math.floor(f), t=f-a;
  v.querySelectorAll(':scope>img').forEach((im,i)=>{ const o=i===a?1-t:(i===a+1?t:0); im.style.opacity=o.toFixed(3); });
  const near=Math.round(f); document.querySelectorAll('#detail .imgstrip button').forEach((b,i)=>b.classList.toggle('on',i===near)); }
function updViewBtn(){ const b=$('viewTog'); if(!b) return; b.hidden=!IMGV.srcs.length||IMGV.id!==(cur&&cur.id); b.textContent=IMGV.on?'🧍 3D':'📷 Bild'; }
function setViewMode(img){ try{ testLocal.setItem('mc_viewmode',img?'img':'3d'); }catch(e){} const st=document.querySelector('#detail .stage'); if(!st) return;
  IMGV.on=img; st.classList.toggle('imgmode',img); const mc=$('mlCam'); if(mc) mc.classList.toggle('imgcam',img); $('detail').classList.toggle('imgon',img); updViewBtn(); }

function openEx(id, push=true){
  const e=EX.find(x=>x.id===id); if(!e) return; if(isLocked(e)){ upsell(e.name); return; }
  cur=e;
  const yt='https://www.youtube.com/results?search_query='+encodeURIComponent(e.name.replace(/\(.*?\)/g,'')+' richtige Ausführung');
  $('detail').innerHTML=`
    <div class="stage studio">
      <div id="anim"></div>
      <button type="button" class="viewtog" id="viewTog" hidden onclick="setViewMode(!IMGV.on)">📷 Bild</button>
      <div class="mlleg min" id="mlLeg">
        <button class="mlleg-h" id="mlLegT" type="button"><span class="dots"><i class="sw p"></i><i class="sw s"></i></span><b>Beteiligte Muskeln</b><i>▾</i></button>
        <div class="mlleg-b">
          <div class="mlr"><i class="sw p"></i><b>Hauptmuskeln</b><span>${esc(e.prim)}${(()=>{ const l=[...hlOf(e)].map(k=>(LAT_N[k]||'')).filter(Boolean); return l.length?'<em class="lat">'+l.join(', ')+'</em>':''; })()}</span></div>
          ${e.sec&&e.sec!=='–'?`<div class="mlr"><i class="sw s"></i><b>Hilfsmuskeln</b><span>${esc(e.sec)}${(()=>{ const l=[...secOf(e)].map(k=>(LAT_N[k]||'')).filter(Boolean); return l.length?'<em class="lat">'+l.join(', ')+'</em>':''; })()}</span></div>`:''}
          <div class="mlr"><i class="sw o"></i><b>Andere</b><span>neutral · nicht hervorgehoben</span></div>
          <p>Farben zeigen die Rolle des Muskels, keine gemessene Kraft.</p>
        </div>
      </div>
      <div class="mlph" id="mlPh">
        <div class="mlst" id="mlSt"><i></i><span>Läuft</span></div>
        <b id="mlName">Startposition</b>
        <label class="mlsl"><small>Bewegungsablauf</small><input type="range" id="mlScr" min="0" max="1000" value="0" aria-label="Bewegungsablauf"></label>
        <p id="mlTxt"></p>
      </div>
    </div>
    <div class="mlctl">
      <div class="mlc1"><button id="pp" type="button" class="on">⏸ Pause</button><button id="mlRe" type="button">↺ Neu starten</button><span>Tempo</span><button id="mlSp" type="button">1×</button></div>
      <div class="mlc2" id="mlCam"><button data-cam="oblique" type="button" class="on">Schräg</button><button data-cam="side" type="button">Seite</button><button data-cam="front" type="button">Vorne</button><button data-cam="back" type="button">Hinten</button><button data-cam="auto" type="button">🔄 360°</button></div>
      <p class="mlhint">👆 Wischen zum Drehen · 2 Finger zoomen · vereinfachte Bewegungsdarstellung</p>
    </div>
    <h2 class="dtitle">${esc(e.name)}</h2>
    <div class="tags">${e.g.map(k=>`<span class="tag p">${gname(k)}</span>`).join('')}</div>
    <div class="toplan" id="toplan"></div>
    <div class="stats">
      <div class="stat"><small>Sätze × Wdh.</small><b>${esc(e.sets)}</b></div>
      <div class="stat"><small>Level</small><b>${esc(e.lvl)}</b></div>
      <div class="stat"><small>Geräte</small><b>${esc(e.equip)}</b></div>
    </div>
    <div class="block kcalc"><h4>🔥 Kalorien-Rechner</h4>
      <div class="kcrow">${e.id==='laufband'
        ? `<label>Minuten<input id="kcM" inputmode="decimal" value="6"></label><label>km/h<input id="kcV" inputmode="decimal" value="4"></label>`
        : `<label>Sätze<input id="kcS" inputmode="numeric" value="${esc(((e.sets.match(/^(\d)/)||[,'3'])[1]))}"></label><label>${/\d\s*s/.test(e.sets)?'Sekunden':'Wiederholungen'}<input id="kcR" value="${esc((e.sets.split('×')[1]||'10').replace(/\(.*?\)/g,'').trim())}"></label>`}
        <div class="kcout"><b id="kcOut">–</b><small>kcal</small></div></div>
      <p class="muted" id="kcNote"></p>
    </div>
    <div class="block"><h4>📈 Dein Fortschritt</h4>${progressHTML(e.id)}${(()=>{ const a=avgStats(e.id), a5=avgStats(e.id,5); if(!a) return ''; return `<div class="avgbox"><div><small>Ø Gewicht</small><b>${a.kg?fmtKg(a.kg)+' kg':'–'}</b></div><div><small>Ø Wiederholungen</small><b>${String(Math.round(a.reps*10)/10).replace('.',',')}</b></div><div><small>Ø Volumen / Training</small><b>${Math.round(a.vol).toLocaleString('de-DE')} kg</b></div>${a.n>5&&a5?`<div><small>Ø letzte 5 Trainings</small><b>${a5.kg?fmtKg(a5.kg)+' kg × ':''}${String(Math.round(a5.reps*10)/10).replace('.',',')}</b></div>`:''}</div>`; })()}</div>
    ${e.id==='laufband'?'':grenzBlock(e)}
    <div class="block"><h4>Trainierte Muskeln</h4>
      <div class="tags"><span class="tag p">Haupt: ${esc(e.prim)}</span><span class="tag">Neben: ${esc(e.sec)}</span></div></div>
    <div class="block"><h4>So geht's</h4><ol class="steps">${e.steps.map(s=>`<li>${esc(s)}</li>`).join('')}</ol></div>
    <div class="block"><h4>Tipps</h4><ul class="pts ok">${e.tips.map(s=>`<li>${esc(s)}</li>`).join('')}</ul></div>
    <div class="block"><h4>Häufige Fehler</h4><ul class="pts no">${e.err.map(s=>`<li>${esc(s)}</li>`).join('')}</ul></div>
    <a class="wa full" target="_blank" rel="noopener" href="${waHref('🏋️ Schau dir diese Übung an: '+e.name+'\n'+appUrl()+'#'+e.id)}">${WA_ICON} Übung per WhatsApp teilen</a>
    <a class="yt" href="${yt}" target="_blank" rel="noopener">▶ <span>Echtes Video ansehen<small>öffnet YouTube-Videos zu dieser Übung</small></span></a>
    <button class="sharebtn" id="shareEx">🔗 Übung teilen</button><p class="hint" id="shareMsg"></p>`;
  updFav(); renderToPlan(); bindGrenz(e);
  IMGV.on=false; IMGV.id=e.id; IMGV.srcs=[]; $('detail').classList.remove('imgon');
  const is3d=G3.mount($('anim'),e);
  findImgs(e.id).then(srcs=>{ if(!cur||cur.id!==e.id) return; IMGV.srcs=srcs; if(!srcs.length){ updViewBtn(); return; }
    let pref='img'; try{ pref=testLocal.getItem('mc_viewmode')||'img'; }catch(err){} imgMode(e,srcs); if(pref==='3d'&&is3d) setViewMode(false); });
  if(is3d){ $('anim').classList.add('is3d'); G3.bindButtons($('detail')); } else { const mc=$('mlCam'); if(mc) mc.hidden=true; }
  { const an=is3d&&G3.anat(); const sw=(c,v)=>document.querySelectorAll('#mlLeg .sw.'+c).forEach(x=>x.style.background=v);
    const pro=is3d&&G3.pro(); sw('p',an?'#8f1318':pro?'#ff2d20':'#ff6a1f'); sw('s',an?'#e3a59e':pro?'#d9a19a':'#f0b48c'); sw('o',an?'#dcd7cf':pro?'#a7a9ad':'#c08a66');
    $('mlLegT').onclick=()=>$('mlLeg').classList.toggle('min'); }
  $('shareEx').onclick=async()=>{ const url=location.href.split('#')[0]+'#'+e.id;
    try{ if(navigator.share){ await navigator.share({title:tr(e.name)+' – Muskel-Coach',text:trMsg('Schau dir diese Übung an: '+e.name),url}); return; } }catch(err){ if(err&&err.name==='AbortError') return; }
    try{ await navigator.clipboard.writeText(url); $('shareMsg').textContent='Link kopiert ✓'; }catch(err){ $('shareMsg').textContent=url; } };
  const kcUpd=()=>{ let v; if(e.id==='laufband') v=kcalFor('laufband',1,`${$('kcM').value} Min · ${$('kcV').value} km/h`); else v=kcalFor(e.id,$('kcS').value,$('kcR').value);
    $('kcOut').textContent=kTxt(v); const hw=parseFloat(String(prof.w||'').replace(',','.'))>=35;
    $('kcNote').innerHTML=`Geschätzt für ${fmt(bodyW(),0)} kg Körpergewicht inkl. Satzpausen.${hw?'':' <b>Profil unter „Mein Bedarf“ anlegen</b> für genaue Werte.'} Mehrere Sätze verschieden? z. B. <b>10 / 7 / 5</b> eingeben.`; };
  document.querySelectorAll('#kcS,#kcR,#kcM,#kcV').forEach(x=>x.oninput=kcUpd); kcUpd();
  $('sheet').classList.add('open'); $('sheet').scrollTop=0;
  document.body.style.overflow='hidden';
  if(push && location.hash!=='#'+id){ try{ location.hash=id; }catch(err){} }
  speed=1; paused=false; t0=performance.now(); mlLast='';
  cancelAnimationFrame(raf); loop();
  const ppTxt=()=>{ $('pp').textContent=paused?'▶ Abspielen':'⏸ Pause'; $('pp').classList.toggle('on',!paused); };
  $('pp').onclick=()=>{ paused=!paused; if(paused){pausedAt=performance.now();} else {t0+=performance.now()-pausedAt; loop();} ppTxt(); mlState(); };
  $('mlRe').onclick=()=>{ t0=performance.now(); if(paused){ paused=false; ppTxt(); } cancelAnimationFrame(raf); loop(); mlState(); };
  $('mlSp').onclick=()=>{ const S=[0.5,1,1.5], ns=S[(S.indexOf(speed)+1)%S.length], now=performance.now(), el=((paused?pausedAt:now)-t0)*speed; speed=ns; t0=(paused?pausedAt:now)-el/speed; $('mlSp').textContent=String(ns).replace('.',LANG==='en'?'.':',')+'×'; };
  const scr=$('mlScr');
  scr.oninput=()=>{ if(!paused){ paused=true; pausedAt=performance.now(); ppTxt(); } const x=scr.value/1000, cyc=mlCyc(); t0=pausedAt-x*cyc/speed; mlScrub=true; frameAt(x); mlState(true); };
  scr.onchange=()=>{ mlScrub=false; };
}
let mlLast='', mlScrub=false, mlX=0;
/* bei Pause trotzdem neu zeichnen, wenn die Kamera bewegt wird */
window.mlRedraw=()=>{ if(cur&&paused&&$('sheet').classList.contains('open')) requestAnimationFrame(()=>frameAt(mlX)); };
const mlCyc=()=>cur&&T[cur.anim].cont?1300:3200;
function mlState(manual){ const s=$('mlSt'); if(!s) return; s.className='mlst'+(paused?(manual?' man':' pau'):''); s.querySelector('span').textContent=paused?(manual?'Manuell':'Pausiert'):'Läuft'; }
function mlTexts(e){ const st=e.steps||[], n=st.length; return {start:st[Math.max(0,n-4)]||st[0]||'', power:st[Math.max(0,n-3)]||'', hold:st[Math.max(0,n-2)]||'', back:st[n-1]||''}; }
function loop(){
  if(!cur || paused) return;
  const cyc=mlCyc(), x=((((performance.now()-t0)*speed)%cyc)+cyc)%cyc/cyc;
  frameAt(x); raf=requestAnimationFrame(loop);
}
/* eine Stelle des Bewegungsablaufs zeichnen (x = 0…1) – für Abspielen und Schieberegler */
function frameAt(x){
  if(!cur) return; mlX=x; const tp=T[cur.anim], tx=mlTexts(cur);
  let ph, key, name, txt;
  if(tp.cont){ ph=0.5-0.5*Math.cos(2*Math.PI*x); key='c'; name=String(tp.cont).replace(/<[^>]*>/g,'').replace(/^[●▲▼\s]+/,'').trim(); txt=tx.power||tx.start; }
  else if(x<0.4){ph=ease(x/0.4); key='p'; name='Ausführen – ausatmen'; txt=tx.power;}
  else if(x<0.5){ph=1; key='h'; name='Kurz halten'; txt=tx.hold;}
  else if(x<0.9){ph=1-ease((x-0.5)/0.4); key='b'; name='Kontrolliert zurück – einatmen'; txt=tx.back;}
  else {ph=0; key='s'; name='Startposition'; txt=tx.start;}
  if(tp.hold&&!tp.cont){ key='hold'; name='Spannung halten, ruhig atmen'; txt=tx.hold||tx.power; }
  if(IMGV.on&&IMGV.id===cur.id) imgFrame(ph); else if(G3.ok) G3.draw(cur,ph); else $('anim').innerHTML=_figure2d(cur,ph);
  const bar=$('mlBar'); if(bar) bar.style.width=(x*100).toFixed(1)+'%';
  const sc=$('mlScr'); if(sc&&!mlScrub) sc.value=Math.round(x*1000);
  if(key!==mlLast){ mlLast=key; const n=$('mlName'), t=$('mlTxt'); if(n) n.textContent=name; if(t) t.textContent=txt||''; }
}
function closeEx(){
  cur=null; cancelAnimationFrame(raf);
  $('sheet').classList.remove('open'); document.body.style.overflow='';
  if(location.hash){ try{ location.hash='start'; }catch(e){} }
  renderChips(); renderGrid(); if(view==='plan') renderPlan();
}
function updFav(){ const on=cur&&favs.includes(cur.id); $('favbtn').textContent=on?'★ Gemerkt':'☆ Merken'; $('favbtn').style.color=on?'var(--acc)':''; }

$('chips').onclick=e=>{const b=e.target.closest('.gcard'); if(!b)return; group=b.dataset.g; renderChips(); renderGrid();};
$('grid').onclick=e=>{const b=e.target.closest('.card'); if(!b) return; const x=exById(b.dataset.id); if(isLocked(x)) return upsell(x.name); openEx(b.dataset.id);};
$('q').oninput=e=>{query=e.target.value; renderGrid();};
$('back').onclick=closeEx;
$('favbtn').onclick=()=>{ if(!cur)return; favs=favs.includes(cur.id)?favs.filter(x=>x!==cur.id):[...favs,cur.id]; saveFavs(); updFav(); };
function route(){ const h=location.hash.slice(1); if(EX.some(e=>e.id===h)) { if(!cur||cur.id!==h) openEx(h,false); } else if(cur) closeEx(); }
window.addEventListener('hashchange',route);
/* ============ Trainingsplan ============ */
const it=(id,sets,reps)=>({id,sets:String(sets),reps,kg:''});
const WARM=()=>it('laufband',1,'5–7 Min · 4 km/h');
const SPLIT_PLAN=()=>({v:2,type:'split',days:[
  {name:'Tag 1 – Rücken, Schultern, Bizeps',items:[WARM(),it('klimmzuege',3,'10 / 7 / 5'),it('latzug',3,'10–12'),it('kabelrudern-sitzend',3,'10–12'),it('schulterpresse-maschine',3,'8–12'),it('seitheben',3,'12–15'),it('face-pulls',3,'12–15'),it('kh-curls',3,'10–12'),it('hammer-curls',3,'10–12')]},
  {name:'Tag 2 – Brust, Trizeps, Nacken, Bauch',items:[WARM(),it('bankdruecken',4,'6–10'),it('schraegbank-kh',3,'8–12'),it('butterfly-kabel',3,'12–15'),it('trizepsdruecken-kabel',3,'10–15'),it('ueberkopf-trizeps',3,'10–12'),it('shrugs',3,'12–15'),it('crunches',3,'15–20'),it('unterarmstuetz',3,'30–60 s')]},
  {name:'Tag 3 – Beine & Bauch',items:[WARM(),it('beinpresse',3,'10–12'),it('beinstrecker',3,'12–15'),it('beinbeuger',3,'10–12'),it('ausfallschritte',3,'10 pro Bein'),it('wadenheben',3,'15–20'),it('beinheben-haengend',3,'8–15'),it('mountain-climbers',3,'30 s')]},
]});
const DEFAULT_PLAN=()=>({v:2,type:'ganz',days:[
  {name:'Tag 1 – Ganzkörper A',items:[it('bankdruecken',4,'6–10'),it('latzug',3,'8–12'),it('beinpresse',3,'10–12'),it('seitheben',3,'12–15'),it('trizepsdruecken-kabel',3,'10–15'),it('kh-curls',3,'10–12'),it('crunches',3,'15–20')]},
  {name:'Tag 2 – Ganzkörper B',items:[it('schraegbank-kh',3,'8–12'),it('kabelrudern-sitzend',3,'10–12'),it('beinstrecker',3,'12–15'),it('beinbeuger',3,'10–12'),it('schulterpresse-maschine',3,'8–12'),it('face-pulls',3,'12–20'),it('hammer-curls',3,'10–12'),it('unterarmstuetz',3,'30–60 s')]},
  {name:'Tag 3 – Ganzkörper C',items:[it('brustpresse',3,'8–12'),it('kh-rudern',3,'10–12'),it('beinpresse',3,'12–15'),it('rumaenisches-kreuzheben',3,'10–12'),it('butterfly-kabel',3,'12–15'),it('reverse-butterfly',3,'12–15'),it('kabel-curls',3,'12–15'),it('ueberkopf-trizeps',3,'10–12')]},
]});
const DAY=(name,items)=>({name,items:[WARM(),...items]});
const PRESETS={
  split:{name:'3er-Split',freq:'3 Tage · z. B. Mo / Mi / Fr',desc:'Tag 1 Rücken, Schultern, Bizeps – Tag 2 Brust, Trizeps, Nacken, Bauch – Tag 3 Beine & Bauch. Jede Muskelgruppe bekommt viele Sätze und eine Woche Erholung.',make:()=>SPLIT_PLAN()},
  ok_uk:{name:'2er-Split Ober/Unter',freq:'4 Tage · z. B. Mo / Di / Do / Fr',desc:'Oberkörper und Beine im Wechsel (A/B). Jeder Muskel wird 2× pro Woche trainiert – sehr effektiv für Muskelaufbau.',make:()=>({days:[
    DAY('Tag 1 – Oberkörper A',[it('bankdruecken',4,'6–10'),it('latzug',3,'8–12'),it('schulterpresse-maschine',3,'8–12'),it('kabelrudern-sitzend',3,'10–12'),it('trizepsdruecken-kabel',3,'10–15'),it('kh-curls',3,'10–12')]),
    DAY('Tag 2 – Unterkörper A',[it('beinpresse',4,'8–12'),it('beinbeuger',3,'10–12'),it('beinstrecker',3,'12–15'),it('wadenheben',4,'15–20'),it('crunches',3,'15–20')]),
    DAY('Tag 3 – Oberkörper B',[it('schraegbank-kh',3,'8–12'),it('klimmzuege',3,'10 / 7 / 5'),it('brustpresse',3,'10–12'),it('kh-rudern',3,'10–12'),it('seitheben',3,'12–15'),it('hammer-curls',3,'10–12'),it('ueberkopf-trizeps',3,'10–12')]),
    DAY('Tag 4 – Unterkörper B',[it('ausfallschritte',3,'10 pro Bein'),it('rumaenisches-kreuzheben',3,'10–12'),it('hip-thrust',3,'10–12'),it('beinstrecker',3,'12–15'),it('wadenheben',3,'15–20'),it('beinheben-haengend',3,'8–15')])]})},
  split4:{name:'4er-Split',freq:'4 Tage · z. B. Mo / Di / Do / Fr',desc:'Brust & Trizeps – Rücken & Bizeps – Beine – Schultern, Nacken & Bauch. Mehr Volumen pro Muskelgruppe, ideal ab ca. 6 Monaten Training.',make:()=>({days:[
    DAY('Tag 1 – Brust & Trizeps',[it('bankdruecken',4,'6–10'),it('schraegbank-kh',3,'8–12'),it('brustpresse',3,'10–12'),it('butterfly-kabel',3,'12–15'),it('trizepsdruecken-kabel',3,'10–15'),it('ueberkopf-trizeps',3,'10–12')]),
    DAY('Tag 2 – Rücken & Bizeps',[it('klimmzuege',3,'10 / 7 / 5'),it('latzug',3,'10–12'),it('kabelrudern-sitzend',3,'10–12'),it('kh-rudern',3,'10–12'),it('kh-curls',3,'10–12'),it('hammer-curls',3,'10–12')]),
    DAY('Tag 3 – Beine',[it('beinpresse',4,'8–12'),it('beinstrecker',3,'12–15'),it('beinbeuger',3,'10–12'),it('ausfallschritte',3,'10 pro Bein'),it('rumaenisches-kreuzheben',3,'10–12'),it('wadenheben',4,'15–20')]),
    DAY('Tag 4 – Schultern, Nacken & Bauch',[it('schulterpresse-maschine',4,'8–12'),it('seitheben',4,'12–15'),it('face-pulls',3,'12–15'),it('reverse-butterfly',3,'12–15'),it('shrugs',4,'12–15'),it('beinheben-haengend',3,'8–15'),it('unterarmstuetz',3,'30–60 s')])]})},
  split5:{name:'5er-Split',freq:'5 Tage · Mo – Fr',desc:'Jeden Tag eine Muskelgruppe: Brust – Rücken – Beine – Schultern & Nacken – Arme & Bauch. Für Fortgeschrittene mit viel Zeit.',make:()=>({days:[
    DAY('Tag 1 – Brust',[it('bankdruecken',4,'6–10'),it('schraegbank-kh',4,'8–12'),it('brustpresse',3,'10–12'),it('butterfly-kabel',3,'12–15'),it('dips',3,'6–12')]),
    DAY('Tag 2 – Rücken',[it('klimmzuege',3,'10 / 7 / 5'),it('latzug',4,'10–12'),it('kabelrudern-sitzend',3,'10–12'),it('kh-rudern',3,'10–12'),it('face-pulls',3,'12–15')]),
    DAY('Tag 3 – Beine & Po',[it('beinpresse',4,'8–12'),it('beinstrecker',3,'12–15'),it('beinbeuger',4,'10–12'),it('hip-thrust',3,'10–12'),it('ausfallschritte',3,'10 pro Bein'),it('wadenheben',4,'15–20')]),
    DAY('Tag 4 – Schultern & Nacken',[it('schulterpresse-maschine',4,'8–12'),it('seitheben',4,'12–15'),it('frontheben',3,'10–12'),it('reverse-butterfly',3,'12–15'),it('shrugs',4,'12–15')]),
    DAY('Tag 5 – Arme & Bauch',[it('kh-curls',3,'10–12'),it('hammer-curls',3,'10–12'),it('kabel-curls',3,'12–15'),it('trizepsdruecken-kabel',3,'10–15'),it('ueberkopf-trizeps',3,'10–12'),it('bankdips',3,'10–15'),it('crunches',3,'15–20'),it('beinheben-haengend',3,'8–15')])]})},
  ppl:{name:'Push / Pull / Beine',freq:'3 oder 6 Tage · 1× oder 2× durchlaufen',desc:'Push = Drücken (Brust, Schultern, Trizeps), Pull = Ziehen (Rücken, Bizeps, Nacken), dann Beine. Bei 6 Tagen einfach 2× pro Woche durchlaufen.',make:()=>({days:[
    DAY('Tag 1 – Push',[it('bankdruecken',4,'6–10'),it('schraegbank-kh',3,'8–12'),it('schulterpresse-maschine',3,'8–12'),it('seitheben',3,'12–15'),it('butterfly-kabel',3,'12–15'),it('trizepsdruecken-kabel',3,'10–15'),it('ueberkopf-trizeps',3,'10–12')]),
    DAY('Tag 2 – Pull',[it('klimmzuege',3,'10 / 7 / 5'),it('latzug',3,'10–12'),it('kabelrudern-sitzend',3,'10–12'),it('face-pulls',3,'12–15'),it('shrugs',3,'12–15'),it('kh-curls',3,'10–12'),it('hammer-curls',3,'10–12')]),
    DAY('Tag 3 – Beine & Bauch',[it('beinpresse',4,'8–12'),it('beinbeuger',3,'10–12'),it('beinstrecker',3,'12–15'),it('rumaenisches-kreuzheben',3,'10–12'),it('wadenheben',4,'15–20'),it('crunches',3,'15–20'),it('unterarmstuetz',3,'30–60 s')])]})},
  ganz:{name:'Ganzkörper 3×',freq:'3 Tage · z. B. Mo / Mi / Fr',desc:'Jeder Muskel 3× pro Woche mit wenigen Sätzen – ideal für Einsteiger und wenig Zeit.',make:()=>DEFAULT_PLAN()},
};
const loadPreset=k=>{ const pl=PRESETS[k].make(); pl.v=2; pl.type=k; return pl; };
let plan=null; try{plan=JSON.parse(testLocal.getItem('mc_plan')||'null')}catch(e){}
if(!plan||!Array.isArray(plan.days)||plan.days.length<1||plan.v!==2) plan=loadPreset('split');
plan.days.forEach(d=>d.items=d.items.filter(i=>EX.some(e=>e.id===i.id)));
let day=0, view='home', confirmKey='';
const savePlan=()=>{try{testLocal.setItem('mc_plan',JSON.stringify(plan))}catch(e){}};
const exById=id=>EX.find(e=>e.id===id);

const VIEWMAP={home:'vHome',ex:'vEx',plan:'vPlan',cal:'vCal',prog:'vProg',prof:'vProf'};
const VIEWNAME={home:'Start',ex:'Übungen',plan:'Trainingsplan',cal:'Kalender',prog:'Fortschritt',prof:'Profil & Einstellungen'};
function setView(v){
  if(!VIEWMAP[v]) v='home';
  const changed=view!==v; view=v;
  for(const k in VIEWMAP){ const el=$(VIEWMAP[k]); if(el) el.style.display=k===v?'':'none'; }
  document.querySelectorAll('#tabbar button').forEach(b=>b.classList.toggle('on',b.dataset.v===v));
  $('tbSub').textContent=VIEWNAME[v]; document.body.classList.toggle('onhome',v==='home');
  if(v==='plan'){ if(MC.pro) renderPlan(); else $('vPlan').innerHTML=proTeaser('Trainingsplan & Training'); } else if(v==='cal'){ if(MC.pro) renderCal(); else $('vCal').innerHTML=proTeaser('Trainingskalender'); } else if(v==='prof'){ for(const f of [fillForm,renderResults,renderSettings]){ try{ f(); }catch(e){ console.warn(f.name,e); } } } else if(v==='prog'){ if(MC.pro) renderProg(); else $('vProg').innerHTML=proTeaser('Fortschritt: Statistik, Körper & Abzeichen'); } else if(v==='home') renderSummary(); else { renderChips(); renderGrid(); }
  try{testLocal.setItem('mc_tab',v)}catch(e){}
  if(changed) window.scrollTo({top:0});
}
$('tabbar').onclick=e=>{const b=e.target.closest('button'); if(b) setView(b.dataset.v);};
document.querySelector('.qgrid').onclick=e=>{const b=e.target.closest('[data-go]'); if(b) setView(b.dataset.go);};
function toast2(t){const el=$('toast2'); el.textContent=t; el.classList.add('on'); clearTimeout(toast2.t); toast2.t=setTimeout(()=>el.classList.remove('on'),1800);}
$('nav').onclick=e=>{const b=e.target.closest('button'); if(b) setView(b.dataset.v);};

function renderPlan(){
  if(!MC.pro){ $('vPlan').innerHTML=proTeaser('Trainingsplan & Training'); return; }
  const d=plan.days[day];
  const totalSets=d.items.filter(i=>i.id!=='laufband').reduce((s,i)=>s+(parseInt(i.sets)||0),0);
  const mins=Math.round(totalSets*2.3+(d.items.some(i=>i.id==='laufband')?7:0)+5);
  $('vPlan').innerHTML=`
    <details class="info"><summary>💡 So holst du mit dem Plan das Maximum raus</summary>
      <ul class="pts ok">
        ${PRESETS[plan.type]?`<li><b>${PRESETS[plan.type].name}</b> (${PRESETS[plan.type].freq}): ${esc(PRESETS[plan.type].desc)}</li>`:`<li><b>Eigener Plan</b> mit ${plan.days.length} Trainingstagen.</li>`}
        ${plan.days.some(d=>d.items.some(i=>i.id==='laufband'))?'<li>Jeder Tag startet mit <b>5–7 Min. zügigem Gehen</b> auf dem Laufband (4 km/h).</li>':''}
        ${plan.days.some(d=>d.items.some(i=>i.id==='klimmzuege'))?'<li><b>Klimmzüge 10 / 7 / 5:</b> Schaffst du in Satz 2 und 3 mehr, steigere die Zahlen. Bei 3 × 10 mit Zusatzgewicht trainieren.</li>':''}
        <li>Jede Muskelgruppe braucht <b>48–72 Std. Pause</b>, bevor sie wieder dran ist.</li>
        <li><b>Letzter Satz 1–2 Wiederholungen vor dem Muskelversagen</b> – nur dann wächst der Muskel.</li>
        <li><b>Steigerung:</b> Schaffst du in allen Sätzen die obere Wiederholungszahl, nimm nächstes Mal mehr Gewicht (+2,5 kg bzw. eine Stufe an der Maschine). Trag dein Gewicht unten bei „kg“ ein.</li>
        <li><b>Pausen:</b> 2–3 Min. bei Bankdrücken, Beinpresse &amp; Co., 60–90 Sek. bei kleinen Übungen.</li>
        <li>Bei der ersten schweren Übung 1–2 leichte Aufwärmsätze machen.</li>
      </ul></details>
    <div class="curplan">Aktueller Plan: <b>${PRESETS[plan.type]?PRESETS[plan.type].name:'Eigener Plan'}</b> · ${plan.days.length} Tage</div>
    <div class="seg" id="days" style="margin-top:8px">${plan.days.map((x,i)=>`<button data-d="${i}" class="${i===day?'on':''}">${plan.days.length>4?'T'+(i+1):'Tag '+(i+1)}</button>`).join('')}${plan.days.length<7?'<button data-add="1" aria-label="Tag hinzufügen">＋</button>':''}</div>
    <input class="dayname" id="dayname" value="${esc(d.name)}" maxlength="40" aria-label="Name des Trainingstags">
    <button class="startbtn" id="startTr">${LIVE?(LIVE.test?'▶ Testlauf fortsetzen':'▶ Laufendes Training fortsetzen'):'▶ Training starten'}</button>
    ${LIVE?'':'<button class="testbtn" id="testTr">👀 Testlauf – Übungen nur ansehen <small>(wird nicht gespeichert)</small></button>'}
    <div class="daymeta" id="daymeta">${d.items.length} Übungen · ${totalSets} Sätze · ca. ${mins} Min. · <b class="kc">🔥 ca. ${kTxt(kcalDay(d))} kcal</b></div>
    <div id="items">${d.items.map((i,n)=>{const e=exById(i.id); return `
      <div class="item ${i.ss&&n<d.items.length-1?'ssA':''} ${n>0&&d.items[n-1].ss?'ssB':''}" data-n="${n}">
        <button class="mini" data-open="${e.id}">${figure(e,0.65)}</button>
        <div class="body">
          <button class="nm" data-open="${e.id}">${n+1}. ${esc(e.name)} <span>· ${e.g.map(gname).join(', ')}</span></button><span class="kcb" data-kc="${n}">🔥 ${kTxt(kcalItem(i))} kcal</span>${(()=>{const rc=maxKgRec(e.id), lt=lastTop(e.id); if(!rc){ const rr=maxRepRec(e.id); return rr?`<span class="prline">🏆 Rekord <b>${unitR(e.id,rr.reps)}</b> am Stück</span>`:''; } return `<span class="prline">🏆 Rekord <b>${fmtKg(rc.kg)} kg</b>${lt&&(lt.kg!==rc.kg||lt.date!==rc.date)?` · zuletzt ${fmtKg(lt.kg)} kg`:''}</span>`;})()}
          ${i.id==='laufband' ? `<div class="ins"><input class="r" style="width:150px" data-f="reps" value="${esc(i.reps)}" aria-label="Dauer und Tempo"></div>` : `<div class="ins"><input data-f="sets" value="${esc(i.sets)}" inputmode="numeric" aria-label="Sätze"> Sätze ×
            <input class="r" data-f="reps" value="${esc(i.reps)}" aria-label="Wiederholungen"> Wdh. ·
            <input data-f="kg" value="${esc(i.kg)}" inputmode="decimal" placeholder="–" aria-label="Gewicht"> kg</div>`}
        </div>
        <div class="ops"><button data-op="up" aria-label="nach oben">▲</button><button data-op="dn" aria-label="nach unten">▼</button><button data-op="rm" class="x" aria-label="entfernen">✕</button></div>
      </div>${n<d.items.length-1&&i.id!=='laufband'&&d.items[n+1].id!=='laufband'?`<button class="sslink ${i.ss?'on':''}" data-ss="${n}">${i.ss?'🔗 Supersatz mit der nächsten Übung – ohne Pause hintereinander (antippen zum Lösen)':'＋ 🔗 Als Supersatz mit nächster Übung verbinden'}</button>`:''}`}).join('') || '<div class="empty">Noch keine Übungen an diesem Tag.</div>'}</div>
    <button class="addbtn" id="addEx">＋ Übung hinzufügen</button>
    ${(()=>{const done=LOG.some(l=>l.date===ymd(new Date())&&l.day===day); return `<button class="donebtn ${done?'is':''}" id="doneDay">${done?'✅ Heute erledigt – zum Kalender':'✅ Training heute erledigt'}</button>`})()}
    <div class="planops">
      ${plan.days.length>1?`<button id="delDay" class="${confirmKey==='del'?'danger':''}">${confirmKey==='del'?'Sicher? Nochmal tippen':'🗑 Tag '+(day+1)+' entfernen'}</button>`:''}
    </div>
    <h4 class="sectitle" style="margin-top:26px">Split-Vorlagen</h4>
    <div class="muted" style="margin-top:-4px;margin-bottom:10px">Antippen und bestätigen – ersetzt deinen aktuellen Plan.</div>
    <div class="presets" id="presets">${Object.entries(PRESETS).map(([k,pr])=>`
      <button class="preset ${plan.type===k?'cur':''} ${confirmKey==='p_'+k?'ask':''}" data-k="${k}">
        <b>${pr.name}</b><small>${pr.freq}</small><span>${confirmKey==='p_'+k?'⚠️ Nochmal tippen zum Laden':esc(pr.desc)}</span>
      </button>`).join('')}
      <button class="preset ${confirmKey==='clear'?'ask':''}" data-k="__clear"><b>🧩 Eigener Plan</b><small>Leer – frei zusammenstellen</small><span>${confirmKey==='clear'?'⚠️ Nochmal tippen zum Leeren':'Gleiche Anzahl Tage, alle Übungen entfernt. Mit ＋ weitere Tage anlegen.'}</span></button>
    </div>`;
  $('days').onclick=e=>{const b=e.target.closest('button'); if(!b)return;
    if(b.dataset.add){ plan.days.push({name:'Tag '+(plan.days.length+1),items:[WARM()]}); day=plan.days.length-1; if(PRESETS[plan.type]) plan.type='eigen'; savePlan(); }
    else day=+b.dataset.d;
    confirmKey=''; renderPlan();};
  if($('delDay')) $('delDay').onclick=()=>{ if(confirmKey==='del'){ plan.days.splice(day,1); day=Math.max(0,day-1); plan.type='eigen'; savePlan(); confirmKey=''; } else confirmKey='del'; renderPlan(); };
  $('presets').onclick=e=>{ const b=e.target.closest('.preset'); if(!b)return; const k=b.dataset.k;
    if(k==='__clear'){ if(confirmKey==='clear'){ plan.days.forEach((d,i)=>{d.items=[]; d.name='Tag '+(i+1);}); plan.type='eigen'; savePlan(); confirmKey=''; day=0; } else confirmKey='clear'; }
    else if(confirmKey==='p_'+k){ plan=loadPreset(k); savePlan(); confirmKey=''; day=0; window.scrollTo({top:$('vPlan').offsetTop-10,behavior:'smooth'}); }
    else confirmKey='p_'+k;
    renderPlan(); };
  $('dayname').oninput=e=>{plan.days[day].name=e.target.value; savePlan();};
  $('items').oninput=e=>{const f=e.target.dataset.f; if(!f)return; const n=+e.target.closest('.item').dataset.n; plan.days[day].items[n][f]=e.target.value; savePlan();
    const kb=document.querySelector(`[data-kc="${n}"]`); if(kb) kb.textContent='🔥 '+kTxt(kcalItem(plan.days[day].items[n]))+' kcal';
    const kd=document.querySelector('#daymeta .kc'); if(kd) kd.textContent='🔥 ca. '+kTxt(kcalDay(plan.days[day]))+' kcal';};
  $('items').onclick=e=>{
    const o=e.target.closest('[data-open]'); if(o){ openEx(o.dataset.open); return; }
    const ssb=e.target.closest('[data-ss]'); if(ssb){ const it2=plan.days[day].items[+ssb.dataset.ss]; it2.ss=!it2.ss; savePlan(); renderPlan(); if(it2.ss) toast2('🔗 Supersatz: beide Übungen direkt hintereinander, Pause erst danach'); return; }
    const b=e.target.closest('[data-op]'); if(!b)return;
    const arr=plan.days[day].items, n=+b.closest('.item').dataset.n;
    if(b.dataset.op==='rm') arr.splice(n,1);
    if(b.dataset.op==='up'&&n>0) [arr[n-1],arr[n]]=[arr[n],arr[n-1]];
    if(b.dataset.op==='dn'&&n<arr.length-1) [arr[n+1],arr[n]]=[arr[n],arr[n+1]];
    savePlan(); renderPlan();
  };
  $('addEx').onclick=openPicker;
  $('startTr').onclick=()=>{ if(LIVE) openLive(); else startLive(day); };
  if($('testTr')) $('testTr').onclick=()=>{ startLive(day); if(LIVE){ LIVE.test=true; saveLive(); renderLive(); } };
  $('doneDay').onclick=()=>{ if(!LOG.some(l=>l.date===ymd(new Date())&&l.day===day)) logTraining(ymd(new Date()),day); setView('cal'); window.scrollTo({top:0,behavior:'smooth'}); };
}

function addToDay(id,d){
  const e=exById(id); const sets=(e.sets.match(/^(\d)/)||[,'3'])[1];
  const reps=(e.sets.split('×')[1]||'8–12').trim();
  plan.days[d].items.push({id,sets,reps,kg:''}); savePlan();
}
function renderToPlan(){
  if(!MC.pro){ const t=$('toplan'); if(t) t.innerHTML=''; return; }
  if(!cur) return;
  $('toplan').innerHTML='<span>Zum Plan:</span>'+plan.days.map((d,i)=>{const inn=d.items.some(x=>x.id===cur.id); return `<button data-d="${i}" class="${inn?'in':''}">${inn?'✓ ':'＋ '}Tag ${i+1}</button>`}).join('');
  $('toplan').onclick=e=>{const b=e.target.closest('button'); if(!b)return; const d=+b.dataset.d, arr=plan.days[d].items, k=arr.findIndex(x=>x.id===cur.id);
    if(k>=0) arr.splice(k,1); else addToDay(cur.id,d); savePlan(); renderToPlan();};
}

let pkGroup='alle', pkQ='';
function openPicker(){ pkGroup='alle'; pkQ=''; $('pkq').value=''; $('pktitle').textContent='Hinzufügen zu Tag '+(day+1); renderPicker(); $('pick').classList.add('open'); $('pick').scrollTop=0; document.body.style.overflow='hidden'; }
function renderPicker(){
  $('pkchips').innerHTML=[['alle','Alle'],...GROUPS].map(([k,n])=>`<button class="chip ${pkGroup===k?'on':''}" data-g="${k}">${n}</button>`).join('');
  const q=pkQ.trim().toLowerCase(), inDay=plan.days[day].items.map(i=>i.id);
  const list=EX.filter(e=>(pkGroup==='alle'||e.g.includes(pkGroup)) && (!q||(e.name+' '+e.prim+' '+e.equip+(LANG==='en'?' '+tr(e.name)+' '+tr(e.prim)+' '+tr(e.equip):'')).toLowerCase().includes(q)));
  $('pklist').innerHTML=list.map(e=>{const inn=inDay.includes(e.id); return `<button class="pickrow" data-id="${e.id}"><span class="mini">${figure(e,0.65)}</span><span class="t">${esc(e.name)}<small>${esc(e.equip)}</small></span>${isLocked(e)?'<span class="plus">🔒</span>':`<span class="plus ${inn?'done':''}">${inn?'✓':'+'}</span>`}</button>`}).join('') || '<div class="empty">Keine Übung gefunden.</div>';
}
$('pkchips').onclick=e=>{const b=e.target.closest('.chip'); if(!b)return; pkGroup=b.dataset.g; renderPicker();};
$('pkq').oninput=e=>{pkQ=e.target.value; renderPicker();};
$('pklist').onclick=e=>{const b=e.target.closest('.pickrow'); if(!b)return; if(isLocked(exById(b.dataset.id))) return upsell(exById(b.dataset.id).name); const arr=plan.days[day].items, k=arr.findIndex(x=>x.id===b.dataset.id);
  if(k>=0) arr.splice(k,1); else addToDay(b.dataset.id,day); savePlan();
  const inn=plan.days[day].items.some(x=>x.id===b.dataset.id), pl=b.querySelector('.plus'); if(pl){ pl.classList.toggle('done',inn); pl.textContent=inn?'✓':'+'; } else renderPicker(); };
$('pkback').onclick=()=>{ $('pick').classList.remove('open'); document.body.style.overflow=''; renderPlan(); };

/* ============ Kalender & Tagebuch ============ */
const WD=['Mo','Di','Mi','Do','Fr','Sa','So'];
const MON=['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'];
const ymd=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const parseD=s=>{const [y,m,d]=s.split('-').map(Number); return new Date(y,m-1,d);};
const wdOf=d=>(d.getDay()+6)%7;
const addD=(d,n)=>{const x=new Date(d); x.setDate(x.getDate()+n); return x;};
const daysBetween=(a,b)=>Math.round((parseD(ymd(b))-parseD(ymd(a)))/864e5);
const fmtD=d=>WD[wdOf(d)]+', '+d.getDate()+'.'+(d.getMonth()+1)+'.';
const AUTO_WD={1:[0],2:[0,3],3:[0,2,4],4:[0,1,3,4],5:[0,1,2,3,4],6:[0,1,2,3,4,5],7:[0,1,2,3,4,5,6]};
let LOG=[], SCHED=null;
try{LOG=JSON.parse(testLocal.getItem('mc_log')||'[]')}catch(e){}
try{SCHED=JSON.parse(testLocal.getItem('mc_sched')||'null')}catch(e){}
if(!SCHED) SCHED={wd:AUTO_WD[Math.min(7,plan.days.length)],auto:true,since:ymd(new Date())};
const saveLog=()=>{try{testLocal.setItem('mc_log',JSON.stringify(LOG))}catch(e){}};
const saveSched=()=>{try{testLocal.setItem('mc_sched',JSON.stringify(SCHED))}catch(e){}};
function syncSched(){ if(SCHED.auto){ const w=AUTO_WD[Math.min(7,plan.days.length)]; if(String(w)!==String(SCHED.wd)){SCHED.wd=w; saveSched();} } }
function logTraining(date,idx){
  const d=plan.days[idx]; const groups=[...new Set(d.items.flatMap(i=>(exById(i.id)||{g:[]}).g))].filter(g=>g!=='cardio');
  LOG.push({date,day:idx,name:d.name,groups,kcal:Math.round(kcalDay(d)),ts:Date.now()}); LOG.sort((a,b)=>a.date<b.date?-1:a.date>b.date?1:a.ts-b.ts); saveLog();
}
const lastLog=()=>LOG.length?LOG[LOG.length-1]:null;
const shortName=i=>{const n=(plan.days[i]||{}).name||('Tag '+(i+1)); return n.replace(/^Tag\s*\d+\s*[–-]\s*/,'')||n;};
// Smarte Reihenfolge: nach dem zuletzt erledigten Tag kommt der nächste – egal ob ein Termin ausgefallen ist
function nextIdx(){ const l=lastLog(); if(!l) return 0; return (l.day+1)%plan.days.length; }
// Plant die nächsten Termine (Datum -> Plan-Tag) ab heute
function upcoming(n){
  const out=[], today=new Date(), doneToday=LOG.some(l=>l.date===ymd(today));
  let idx=nextIdx(), d=doneToday?addD(today,1):today;
  for(let k=0;k<120&&out.length<n;k++,d=addD(d,1)) if(SCHED.wd.includes(wdOf(d))){ out.push({date:ymd(d),d:new Date(d),idx}); idx=(idx+1)%plan.days.length; }
  return out;
}
function heroNext(){
  if(!MC.pro) return '🔒 Trainingsplan & Training in der <b>Vollversion</b>';
  syncSched();
  const today=ymd(new Date()), t=LOG.filter(l=>l.date===today), up=upcoming(1)[0];
  if(LIVE) return `🏋️ Training läuft: <b>${esc(shortName(LIVE.day))}</b>`;
  if(t.length) return `✅ Heute erledigt: <b>${esc(shortName(t[t.length-1].day))}</b>`;
  if(up&&up.date===today) return `📅 Heute dran: <b>${esc(shortName(up.idx))}</b>`;
  return up?`😴 Ruhetag · nächstes Training <b>${fmtD(up.d)}</b>`:'';
}
let calMonth=null, calSel=null;
function renderCal(){
  if(!MC.pro){ $('vCal').innerHTML=proTeaser('Trainingskalender'); return; }
  syncSched();
  const now=new Date(), today=ymd(now); if(!calMonth) calMonth=new Date(now.getFullYear(),now.getMonth(),1);
  const tLogs=LOG.filter(l=>l.date===today), up=upcoming(40), upMap={}; up.forEach(u=>upMap[u.date]=u);
  const l=lastLog(), since=l?daysBetween(parseD(l.date),now):null;
  // Heute-Karte
  let card;
  if(tLogs.length) card=`<small>Heute · ${fmtD(now)}</small><h3>✅ Erledigt!</h3><p>${tLogs.map(x=>esc(x.name)).join(', ')}. Stark – jetzt Eiweiß tanken und erholen.</p>`+(up[0]?`<p style="margin-top:6px">Nächstes Training: <b>${fmtD(up[0].d)}</b> – ${esc(shortName(up[0].idx))}</p>`:'');
  else if(upMap[today]) card=`<small>Heute · ${fmtD(now)}</small><h3>Heute dran: ${esc(shortName(upMap[today].idx))}</h3><p>${plan.days[upMap[today].idx].items.length} Übungen · Tag ${upMap[today].idx+1} deines Plans · 🔥 ca. ${kTxt(kcalDay(plan.days[upMap[today].idx]))} kcal</p>
      <div class="btns"><button class="pri" id="goTrain">▶ Training starten</button><button id="markToday">✓ Erledigt</button></div>`;
  else { const n=up[0]; card=`<small>Heute · ${fmtD(now)}</small><h3>😴 Ruhetag</h3><p>Muskeln wachsen in der Pause. ${n?`Nächstes Training: <b>${fmtD(n.d)}</b> – ${esc(shortName(n.idx))}`:''}</p>
      <div class="btns"><button id="markToday">Trotzdem trainiert? Eintragen</button></div>`; }
  let warn='';
  if(since!==null&&since>=5&&!tLogs.length) warn=`<div class="warnline">⏰ Letztes Training vor ${since} Tagen – heute wäre ein guter Tag, um wieder einzusteigen. Es geht mit <b>${esc(shortName(nextIdx()))}</b> weiter.</div>`;
  else if(l&&!tLogs.length){ const missed=[]; for(let d=addD(parseD(l.date),1); ymd(d)<today; d=addD(d,1)) if(SCHED.wd.includes(wdOf(d))&&ymd(d)>=SCHED.since) missed.push(d);
    if(missed.length) warn=`<div class="warnline">Training am ${missed.map(fmtD).join(', ')} verpasst? Kein Problem – die App macht einfach mit <b>${esc(shortName(nextIdx()))}</b> weiter, es fällt nichts weg.</div>`; }
  // Statistik
  const wStart=addD(now,-wdOf(now)), wk=LOG.filter(x=>x.date>=ymd(wStart)&&x.date<=today).length;
  const wCount=w=>{ const s=addD(wStart,-7*w), e=addD(s,6); return LOG.filter(x=>x.date>=ymd(s)&&x.date<=ymd(e)).length; };
  let streak=0; for(let w=wCount(0)>=SCHED.wd.length?0:1; w<104 && wCount(w)>=SCHED.wd.length; w++) streak++;
  const mStr=ymd(now).slice(0,7), mCount=LOG.filter(x=>x.date.startsWith(mStr)).length;
  // Erholung je Muskel
  const rec=GROUPS.filter(([k])=>k!=='cardio').map(([k,n])=>{ const e=[...LOG].reverse().find(x=>x.groups.includes(k)); if(!e) return [n,'#59626a','noch nicht']; const dd=daysBetween(parseD(e.date),now);
    return [n, dd<2?'#ff7a45':dd<3?'#ffd23f':'#39ff6a', dd===0?'heute':dd===1?'gestern':'vor '+dd+' T.']; });
  // Monat
  const y=calMonth.getFullYear(), m=calMonth.getMonth(), first=new Date(y,m,1), off=wdOf(first), nd=new Date(y,m+1,0).getDate();
  let cells=WD.map(w=>`<div class="wd">${w}</div>`).join('');
  for(let i=0;i<off;i++) cells+='<div class="c out"></div>';
  for(let dn=1;dn<=nd;dn++){ const d=new Date(y,m,dn), k=ymd(d), lg=LOG.filter(x=>x.date===k), u=upMap[k];
    let cls='', em='';
    if(lg.length){cls='done'; em='T'+(lg[lg.length-1].day+1);} else if(u){cls='plan'; em='T'+(u.idx+1);} else if(k<today&&k>=SCHED.since&&SCHED.wd.includes(wdOf(d))){cls='miss'; em='–';}
    cells+=`<button class="c ${cls} ${k===today?'today':''} ${calSel===k?'sel':''}" data-k="${k}">${dn}${em?`<em>${em}</em>`:''}</button>`; }
  // Auswahl-Details
  let info='';
  if(calSel){ const d=parseD(calSel), lg=LOG.map((x,i)=>[x,i]).filter(([x])=>x.date===calSel), u=upMap[calSel];
    info=`<div class="dayinfo"><h5>${fmtD(d)}${calSel===today?' (heute)':''}</h5>
      ${lg.map(([x,i])=>`<div class="row"><span>✅ ${esc(x.name)}</span><button data-del="${i}">Löschen</button></div>`).join('')}
      ${!lg.length&&u?`<div class="row"><span>📅 Geplant: ${esc(plan.days[u.idx].name)}</span></div>`:''}
      ${!lg.length&&!u?(calSel<today&&calSel>=SCHED.since&&SCHED.wd.includes(wdOf(d))?'<div class="row"><span style="color:#ff9a6e">Geplant, aber nicht eingetragen</span></div>':'<div class="row"><span style="color:var(--mut)">Kein Training geplant</span></div>'):''}
      ${calSel<=today?`<div class="add"><select id="selDay">${plan.days.map((x,i)=>`<option value="${i}" ${i===(u?u.idx:nextIdx())?'selected':''}>${esc(x.name)}</option>`).join('')}</select><button id="addLog">＋ Eintragen</button></div>`:''}
    </div>`; }
  const hist=[...LOG].reverse().slice(0,5);
  $('vCal').innerHTML=`
    <div class="today">${card}</div>${warn}
    <div class="stats3"><div><b>${wk}/${SCHED.wd.length}</b><small>diese Woche</small></div><div><b>${streak} 🔥</b><small>Wochen-Serie</small></div><div><b>${kTxt(LOG.filter(x=>x.date>=ymd(wStart)&&x.date<=today).reduce((a,x)=>a+(x.kcal||0),0))}</b><small>kcal diese Woche</small></div><div style="display:none"><b>${mCount}</b><small>im ${MON[now.getMonth()]}</small></div></div>
    <div class="block"><h4>Kalender</h4>
      <div class="calhead"><button id="calPrev">‹</button><b>${MON[m]} ${y}</b><button id="calNext">›</button></div>
      <div class="cal" id="calGrid">${cells}</div>
      <div class="legendc"><span><i style="background:#1d4a27;border:1px solid #39c95a"></i>erledigt</span><span><i style="border:1.5px dashed var(--acc)"></i>geplant</span><span><i style="border:1px solid #6a3420"></i>verpasst</span><span>T1 = Tag 1 deines Plans</span></div>
      ${info}
    </div>
    <div class="block"><h4>Trainingstage pro Woche</h4>
      <div class="wds" id="wds">${WD.map((w,i)=>`<button data-w="${i}" class="${SCHED.wd.includes(i)?'on':''}">${w}</button>`).join('')}</div>
      <p class="muted">${SCHED.wd.length} Termine pro Woche · Plan hat ${plan.days.length} Tage. ${SCHED.auto?'Automatisch passend zu deinem Split gewählt.':'Von dir angepasst.'} Die Reihenfolge läuft einfach weiter – verpasst du einen Termin, rückt das nächste Training nach.</p>
      ${!SCHED.auto?'<button class="iconbtn" id="autoSched" style="margin-top:8px">↺ Automatisch passend zum Split</button>':''}
    </div>
    <div class="block"><h4>Muskel-Erholung</h4>
      <div class="recov">${rec.map(([n,c,t])=>`<div><i style="background:${c};box-shadow:0 0 8px ${c}"></i><span>${n}</span><small>${t}</small></div>`).join('')}</div>
      <p class="muted">🟠 unter 48 Std. – erholt sich · 🟡 fast bereit · 🟢 bereit für das nächste Training</p>
    </div>
    <div class="block hist"><h4>Zuletzt trainiert</h4>
      ${hist.length?hist.map(x=>{const dd=daysBetween(parseD(x.date),now); return `<div class="row"><b>${esc(x.name)}${x.kcal?` <span style="color:var(--acc2);font-weight:600">· 🔥 ${x.kcal} kcal</span>`:''}</b><small>${dd===0?'heute':dd===1?'gestern':'vor '+dd+' Tagen'} · ${fmtD(parseD(x.date))}</small></div>`}).join(''):'<div class="empty" style="padding:12px 0">Noch kein Training eingetragen. Tippe nach dem Training auf „✓ Erledigt“.</div>'}
    </div>`;
  if($('goTrain')) $('goTrain').onclick=()=>{ day=upMap[today].idx; if(LIVE) openLive(); else startLive(day); };
  if($('markToday')) $('markToday').onclick=()=>{ logTraining(today, upMap[today]?upMap[today].idx:nextIdx()); renderCal(); renderSummary(); };
  $('calPrev').onclick=()=>{calMonth=new Date(y,m-1,1); renderCal();};
  $('calNext').onclick=()=>{calMonth=new Date(y,m+1,1); renderCal();};
  $('calGrid').onclick=e=>{const b=e.target.closest('.c[data-k]'); if(!b)return; calSel=calSel===b.dataset.k?null:b.dataset.k; renderCal();};
  if($('addLog')) $('addLog').onclick=()=>{ logTraining(calSel,+$('selDay').value); renderCal(); renderSummary(); };
  document.querySelectorAll('[data-del]').forEach(b=>b.onclick=()=>{ LOG.splice(+b.dataset.del,1); saveLog(); renderCal(); renderSummary(); });
  $('wds').onclick=e=>{const b=e.target.closest('button'); if(!b)return; const w=+b.dataset.w; SCHED.wd=SCHED.wd.includes(w)?SCHED.wd.filter(x=>x!==w):[...SCHED.wd,w].sort(); if(!SCHED.wd.length) SCHED.wd=[w]; SCHED.auto=false; saveSched(); renderCal(); renderSummary();};
  if($('autoSched')) $('autoSched').onclick=()=>{ SCHED.auto=true; syncSched(); saveSched(); renderCal(); renderSummary(); };
}

/* ============ Trainings-Modus ============ */
let LIVE=null; try{LIVE=JSON.parse(testLocal.getItem('mc_live')||'null')}catch(e){}
const saveLive=()=>{try{ if(LIVE) testLocal.setItem('mc_live',JSON.stringify(LIVE)); else testLocal.removeItem('mc_live'); }catch(e){}};
const isHold=s=>/\d\s*(s|sek)\b/i.test(String(s));
function rng(s){ s=String(s||''); const n=nums(s);
  if(/\//.test(s)&&n.length>1) return {list:n,lo:Math.min(...n),hi:Math.max(...n)};
  return {lo:n[0]||10,hi:n.length>1?n[1]:(n[0]||10)}; }
// Alle früheren Sätze einer Übung (neueste zuerst)
function history(id){ return LOG.filter(l=>l.sets&&l.sets[id]&&l.sets[id].length).map(l=>({date:l.date,sets:l.sets[id]})).reverse(); }
const e1rm=s=>{ const kg=parseFloat(String(s.kg).replace(',','.'))||0, r=parseFloat(s.reps)||0; return kg>0? kg*(1+r/30) : r; };
const bestOf=sets=>sets.reduce((m,s)=>Math.max(m,e1rm(s)),0);
const fmtKg=v=>String(Math.round(v*10)/10).replace('.',',');
/* ===== Rekord-Speicher: schwerstes Gewicht je Übung ===== */
const kgNum=v=>parseFloat(String(v||'').replace(',','.'))||0;
function maxKgRec(id){ if(id==='laufband') return null; let b=null;
  for(const l of LOG){ const ss=l.sets&&l.sets[id]; if(!ss) continue;
    for(const x of ss){ const k=kgNum(x.kg), r=parseFloat(x.reps)||0; if(k>0&&(!b||k>b.kg||(k===b.kg&&r>b.reps))) b={kg:k,reps:r,date:l.date}; } }
  return b; }
function holdOf(id){ return /\d\s*s/.test((exById(id)||{}).sets||''); }
const unitR=(id,n)=>holdOf(id)?`${n} Sek.`:`${n} Wdh.`;
function maxRepRec(id){ if(id==='laufband') return null; let b=null;   // Körpergewicht: meiste Wdh./Sekunden in einem Satz
  for(const l of LOG){ const ss=l.sets&&l.sets[id]; if(!ss) continue;
    for(const x of ss){ const r=parseFloat(x.reps)||0; if(kgNum(x.kg)===0&&r>0&&(!b||r>b.reps)) b={reps:r,date:l.date}; } }
  return b; }
function avgStats(id,lastN){ if(id==='laufband') return null; let hs=history(id); if(lastN) hs=hs.slice(0,lastN); if(!hs.length) return null;
  let kgSum=0,kgN=0,rSum=0,rN=0,vol=0; for(const h of hs) for(const x of h.sets){ const k=kgNum(x.kg), r=parseFloat(x.reps)||0; if(k>0){kgSum+=k;kgN++;} if(r>0){rSum+=r;rN++;} vol+=k*r; }
  return {n:hs.length,sets:hs.reduce((a,h)=>a+h.sets.length,0),kg:kgN?kgSum/kgN:0,reps:rN?rSum/rN:0,vol:vol/hs.length}; }
function avgLine(id){ const a=avgStats(id); if(!a||(!a.kg&&!a.reps)) return ''; return `Ø ${a.kg?`<b>${fmtKg(a.kg)} kg</b> × `:''}<b>${String(Math.round(a.reps*10)/10).replace('.',',')} ${holdOf(id)?'Sek.':'Wdh.'}</b> <small>(aus ${a.sets} Sätzen · ${a.n} Training${a.n>1?'s':''})</small>`; }
function optOn(k){ try{ const o=JSON.parse(testLocal.getItem('mc_opts')||'{}'); return o[k]!==false; }catch(e){ return true; } }
function setOpt(k,v){ try{ const o=JSON.parse(testLocal.getItem('mc_opts')||'{}'); o[k]=v; testLocal.setItem('mc_opts',JSON.stringify(o)); }catch(e){} }
let TESTS={}; try{ TESTS=JSON.parse(testLocal.getItem('mc_tests')||'{}'); }catch(e){}
const saveTests=()=>{ try{ testLocal.setItem('mc_tests',JSON.stringify(TESTS)); }catch(e){} };
function grenzBlock(e){
  if(!MC.pro) return `<div class="block"><h4>🔥 Grenztest</h4><button class="recempty" style="width:100%;text-align:left" onclick="upsell('Grenztest')">🔒 Teste deine Maximalkraft und sieh, wie viel stärker du wirst – in der Vollversion.</button></div>`;
  const ts=(TESTS[e.id]||[]).slice().sort((a,b)=>a.date<b.date?1:-1), best=ts.reduce((m,t)=>Math.max(m,t.orm||0),0), bw=!ts.some(t=>t.kg>0)&&ts.length;
  return `<div class="block grenz" id="grenzBox"><h4>🔥 Grenztest (Maximalkraft)</h4>
    <p class="muted" style="margin-top:0">Gut aufwärmen, dann ein Gewicht wählen, das du ca. 3–10× schaffst, und so viele <b>saubere</b> Wiederholungen wie möglich machen. Bei schweren Übungen mit Partner/Sicherung!</p>
    <div class="kcrow"><label>Gewicht (kg)<input id="gtKg" inputmode="decimal" placeholder="z. B. 60"></label><label>Max. Wdh.<input id="gtR" inputmode="numeric" placeholder="z. B. 6"></label></div>
    <button class="savebtn" id="gtSave">Test speichern</button>
    ${ts.length?`<div class="gtbest">${best?`🏆 Geschätzte Maximalkraft: <b>${fmtKg(Math.round(best/2.5)*2.5)} kg</b>`:`🏆 Bestwert: <b>${Math.max(...ts.map(t=>t.reps))} Wdh.</b>`}</div>
      ${best?`<div class="rmt">${[[90,'Kraft · 3–4 Wdh.'],[80,'Aufbau · 8 Wdh.'],[70,'Aufbau · 12 Wdh.'],[60,'Ausdauer · 15+']].map(([p,l])=>`<span>${p}%<b>${fmtKg(Math.round(best*p/100/2.5)*2.5)} kg</b><small>${l}</small></span>`).join('')}</div>`:''}
      <div class="gtlist">${ts.slice(0,6).map((t,i)=>{ const prev=ts[i+1], d=prev&&t.orm&&prev.orm?Math.round((t.orm/prev.orm-1)*100):null; return `<div><span>${fmtD(parseD(t.date))}</span><span>${t.kg?fmtKg(t.kg)+' kg × ':''}${t.reps} Wdh.</span><b>${t.orm?'≈ '+fmtKg(Math.round(t.orm/2.5)*2.5)+' kg':''}${d!==null?` <em style="color:${d>=0?'#7dff9c':'#ff9a6e'}">${d>=0?'+':''}${d}%</em>`:''}</b></div>`; }).join('')}</div>`:''}
  </div>`; }
function bindGrenz(e){ const b=$('gtSave'); if(!b) return; b.onclick=()=>{ const kg=kgNum($('gtKg').value), r=parseInt($('gtR').value);
  if(!(r>0)){ toast2('Bitte die geschafften Wiederholungen eintragen'); return; }
  const orm=kg>0?(r===1?kg:kg*(1+r/30)):0, prevBest=(TESTS[e.id]||[]).reduce((m,t)=>Math.max(m,t.orm||0),0);
  (TESTS[e.id]=TESTS[e.id]||[]).push({date:ymd(new Date()),kg,reps:r,orm}); saveTests();
  if(orm&&prevBest&&orm>prevBest) celebrate('Neue Maximalkraft! 🔥',`Deine geschätzte Maximalkraft bei ${esc(e.name)}: <b>${fmtKg(Math.round(orm/2.5)*2.5)} kg</b><br><small>Vorher: ${fmtKg(Math.round(prevBest/2.5)*2.5)} kg</small>`);
  else toast2('Grenztest gespeichert ✓');
  const box=$('grenzBox'); if(box){ box.outerHTML=grenzBlock(e); bindGrenz(e); } }; }
function lastTop(id){ const h=history(id)[0]; if(!h||id==='laufband') return null; let t=null;
  for(const x of h.sets){ const k=kgNum(x.kg); if(k>0&&(!t||k>t.kg)) t={kg:k,reps:parseFloat(x.reps)||0,date:h.date}; } return t; }
function allRecords(){ const ids=[...new Set(LOG.flatMap(l=>Object.keys(l.sets||{})))];
  return ids.map(id=>({id,ex:exById(id),rec:maxKgRec(id),rr:maxRepRec(id)})).map(x=>({...x,rec:x.rec||(x.rr?{kg:0,reps:x.rr.reps,date:x.rr.date}:null)})).filter(x=>x.ex&&x.rec).sort((a,b)=>a.rec.date<b.rec.date?1:a.rec.date>b.rec.date?-1:b.rec.kg-a.rec.kg); }
function celebrate(title,text){
  let el=$('prPop'); if(!el){ el=document.createElement('div'); el.id='prPop'; el.className='prpop'; document.body.appendChild(el); el.onclick=()=>el.classList.remove('on'); }
  el.innerHTML=`<div class="prbox"><div class="prconf">🎉🏆🎉</div><h3>${title}</h3><p>${text}</p><span>Antippen zum Schließen</span></div>`;
  el.classList.add('on'); try{ navigator.vibrate&&navigator.vibrate([80,60,80,60,200]); }catch(e){}
  clearTimeout(celebrate.t); celebrate.t=setTimeout(()=>el.classList.remove('on'),5000);
}
function suggestKg(id,target){
  const h=history(id)[0]; if(!h) return null;
  const r=rng(target), kgs=h.sets.map(s=>parseFloat(String(s.kg).replace(',','.'))||0);
  if(!kgs.some(k=>k>0)) return null;
  const top=Math.max(...kgs), allHit=h.sets.every((s,i)=>(parseFloat(s.reps)||0)>=(r.list?r.list[i]||r.lo:r.hi));
  const step=(CAT[id]==='big'||CAT[id]==='mid')?2.5:1;
  return allHit?{kg:top+step,up:true}:{kg:top,up:false};
}
function startLive(dIdx){
  if(!MC.pro){ upsell('Training'); return; }
  const d0=plan.days[dIdx], lockedN=d0.items.filter(i=>isLocked(exById(i.id))).length, d=Object.assign({},d0,{items:d0.items.filter(i=>!isLocked(exById(i.id)))});
  if(!d.items.length){ upsell(); return; }
  if(lockedN) setTimeout(()=>{ try{ toast2(`🔒 ${lockedN} Pro-Übung${lockedN>1?'en':''} übersprungen – in der Vollversion dabei`); }catch(e){} },600);
  LIVE={date:ymd(new Date()),day:dIdx,name:d.name,start:Date.now(),idx:0,items:d.items.map(it=>{
    if(it.id==='laufband'){ const n=nums(it.reps); return {id:it.id,target:it.reps,sets:[{kg:String(n[2]||4),reps:String(n[0]&&n[1]?Math.round((n[0]+n[1])/2):(n[0]||6)),done:false}]}; }
    const r=rng(it.reps), cnt=r.list?r.list.length:(parseInt(it.sets)||3), h=history(it.id)[0], sg=suggestKg(it.id,it.reps);
    const sets=[]; for(let i=0;i<cnt;i++){ const prev=h&&h.sets[i];
      const kg=sg?fmtKg(sg.kg):(prev&&prev.kg)||(it.kg||'');
      const reps=r.list?String(r.list[i]):String(r.lo);
      sets.push({kg:String(kg),reps,done:false}); }
    return {id:it.id,target:it.reps,sets,ss:!!it.ss};
  })};
  saveLive(); openLive();
}
let liveTimer=0, liveRaf=0, restEnd=0, restTotal=0, audioCtx=null;
function beep(){ try{ if(!audioCtx) return; const t=audioCtx.currentTime;
  [0,0.22,0.44].forEach((o,i)=>{ const os=audioCtx.createOscillator(), g=audioCtx.createGain(); os.frequency.value=i===2?1046:784; os.connect(g); g.connect(audioCtx.destination);
    g.gain.setValueAtTime(0.0001,t+o); g.gain.exponentialRampToValueAtTime(0.4,t+o+0.02); g.gain.exponentialRampToValueAtTime(0.0001,t+o+0.18); os.start(t+o); os.stop(t+o+0.2); }); }catch(e){}
  try{ navigator.vibrate&&navigator.vibrate([250,120,250]); }catch(e){} }
const mmss=s=>{s=Math.max(0,Math.round(s)); return Math.floor(s/60)+':'+String(s%60).padStart(2,'0');};
function openLive(){
  if(!MC.pro){ upsell('Training'); return; }
  $('tsheet').classList.add('open'); updResume(); document.body.style.overflow='hidden'; renderLive();
  clearInterval(liveTimer); liveTimer=setInterval(tickLive,250);
  cancelAnimationFrame(liveRaf); const t0=performance.now();
  const anim=()=>{ if(!LIVE||!$('tsheet').classList.contains('open')) return; const el=$('lvFig'), it=LIVE.items[LIVE.idx];
    if(el&&it){ const ex=exById(it.id), tp=T[ex.anim], x=((performance.now()-t0)%3200)/3200; let ph;
      if(tp.cont) ph=0.5-0.5*Math.cos(2*Math.PI*((performance.now()-t0)%1300)/1300); else if(tp.hold) ph=0.5; else ph=x<.4?ease(x/.4):x<.5?1:x<.9?1-ease((x-.5)/.4):0;
      if(cur){} else if(G3.mount(el,ex)) G3.draw(ex,ph); else el.innerHTML=_figure2d(ex,ph); }
    liveRaf=requestAnimationFrame(anim); };
  anim();
}
function updResume(){ const b=$('resume'); if(b) b.style.display=(MC.pro&&LIVE&&!$('tsheet').classList.contains('open'))?'block':'none'; }
function closeLive(){ setTimeout(updResume,0); $('tsheet').classList.remove('open'); document.body.style.overflow=''; clearInterval(liveTimer); cancelAnimationFrame(liveRaf); restEnd=0; }
function tickLive(){
  if(!LIVE){ const rb=$('restBar'); if(rb) rb.classList.remove('on'); return; } const el=$('lvClock'); if(el) el.textContent=mmss((Date.now()-LIVE.start)/1000);
  const bar=$('restBar'); if(!bar) return;
  if(restEnd){ const left=(restEnd-Date.now())/1000;
    if(left<=0){ restEnd=0; beep(); bar.classList.remove('on'); $('lvMsg').textContent='⏰ Pause vorbei – nächster Satz!'; }
    else { bar.classList.add('on'); $('restTime').textContent=mmss(left); $('restFill').style.width=(100*left/restTotal)+'%'; } }
  else bar.classList.remove('on');
}
function renderLive(){
  if(!LIVE){ closeLive(); return; }
  const it=LIVE.items[LIVE.idx], ex=exById(it.id), walk=it.id==='laufband', hold=isHold(it.target);
  const h=history(it.id)[0], sg=walk?null:suggestKg(it.id,it.target);
  const doneSets=LIVE.items.reduce((a,x)=>a+x.sets.filter(s=>s.done).length,0), allSets=LIVE.items.reduce((a,x)=>a+(x.skip?x.sets.filter(s=>s.done).length:x.sets.length),0);
  $('tbody').innerHTML=`
    <div class="lvtop"><div><small>${esc(LIVE.name)}</small><b id="lvClock">${mmss((Date.now()-LIVE.start)/1000)}</b></div>
      <div class="lvprog"><i style="width:${allSets?100*doneSets/allSets:0}%"></i></div><span>${doneSets}/${allSets} Sätze</span></div>
    ${LIVE.test?'<div class="lvtest">👀 <b>Testlauf</b> – schau dir alles in Ruhe an, es wird nichts gespeichert.</div>':''}
    <div class="lvchips" id="lvChips">${LIVE.items.map((x,i)=>{const f=x.sets.every(s=>s.done); return `<button data-i="${i}" class="${i===LIVE.idx?'on':''} ${f?'fin':''} ${x.skip&&!f?'skip':''}">${f?'✓':x.skip?'–':i+1}</button>`}).join('')}</div>
    <div class="lvcard">
      <div class="lvfig" id="lvFig">${figure(ex,.5)}</div>
      <div class="lvname"><small>Übung ${LIVE.idx+1} von ${LIVE.items.length}${it.ss&&LIVE.items[LIVE.idx+1]?` · <b class="sstag">🔗 Supersatz A</b> → ${esc((exById(LIVE.items[LIVE.idx+1].id)||{}).name||'')}`:(LIVE.idx>0&&LIVE.items[LIVE.idx-1].ss?` · <b class="sstag">🔗 Supersatz B</b>`:'')}</small><h3>${esc(ex.name)}</h3>
        <span class="tag p">🔥 ${esc(ex.prim)}</span> <button class="lvinfo" data-open="${ex.id}">ⓘ Anleitung</button></div>
      ${!walk&&optOn('avg')&&avgLine(it.id)?`<div class="lvlast lvavg">📊 ${avgLine(it.id)}</div>`:''}
      ${h&&!walk?`<div class="lvlast">Letztes Mal (${fmtD(parseD(h.date))}): <b>${h.sets.map(s=>(parseFloat(s.kg)?s.kg+' kg × ':'')+s.reps+(hold?' s':'')).join(' · ')}</b></div>`:''}
      ${(()=>{ if(walk) return ''; if(!MC.pro) return ''; const rc=maxKgRec(it.id), rr=maxRepRec(it.id); return rc?`<div class="lvrec">🏆 Dein Rekord: <b>${fmtKg(rc.kg)} kg × ${rc.reps}</b> <small>(${fmtD(parseD(rc.date))})</small> – schaffst du mehr?</div>`:rr?`<div class="lvrec">🏆 Dein Rekord: <b>${unitR(it.id,rr.reps)}</b> am Stück <small>(${fmtD(parseD(rr.date))})</small> – schaffst du mehr?</div>`:''; })()}
      ${liveHelpers(it,ex)}
      ${sg&&sg.up?`<div class="lvup">⬆️ Stark! Letztes Mal alle Wiederholungen geschafft – heute <b>${fmtKg(sg.kg)} kg</b> versuchen.</div>`:''}
      <div class="lvsets" id="lvSets">
        <div class="lvhd"><span>Satz</span><span>${walk?'km/h':'kg'}</span><span>${walk?'Minuten':hold?'Sekunden':'Wdh.'}</span><span></span></div>
        ${it.sets.map((s,i)=>`<div class="lvrow ${s.done?'done':''}" data-s="${i}"><span class="n">${i+1}</span>
          <input data-f="kg" inputmode="decimal" value="${esc(s.kg)}" placeholder="${walk?'4':'KG'}">
          <input data-f="reps" inputmode="numeric" value="${esc(s.reps)}">
          <button class="ck" data-ck="${i}">${s.done?'✓':''}</button></div>`).join('')}
        ${walk?'':`<button class="lvadd" id="lvAddSet">＋ Satz</button>`}
      </div>
      <div class="lvmsg" id="lvMsg">${walk?'Tempo & Dauer eintragen, dann abhaken.':'Gewicht & Wiederholungen anpassen, dann Satz abhaken ✓ – die Pause startet automatisch. Ohne Gewicht (Körpergewicht) kg leer lassen.'}</div>
    </div>
    <div class="lvnav"><button id="lvPrev" ${LIVE.idx===0?'disabled':''}>‹ Zurück</button>
      ${LIVE.idx<LIVE.items.length-1?'<button class="pri" id="lvNext">Nächste Übung ›</button>':'<button class="pri fin" id="lvFinish">🏁 Training beenden</button>'}</div>
    <button class="lvskip" id="lvSkip">${it.skip?'↩ Übung wieder aufnehmen':'⏭ Übung überspringen <small>(Gerät belegt/defekt, geht gerade nicht …)</small>'}</button>
    ${LIVE.idx<LIVE.items.length-1&&!LIVE.test?'<button class="lvend" id="lvFinish2">Training jetzt beenden &amp; speichern</button>':''}
    <div id="lvCx"><button class="lvend" id="lvCancel">${LIVE.test?'✕ Testlauf beenden':'✕ Training abbrechen …'}</button></div>`;
  $('lvChips').onclick=e=>{const b=e.target.closest('button'); if(!b)return; LIVE.idx=+b.dataset.i; saveLive(); renderLive();};
  $('lvSets').oninput=e=>{const f=e.target.dataset.f; if(!f)return; const i=+e.target.closest('.lvrow').dataset.s; it.sets[i][f]=e.target.value; saveLive();};
  $('lvSets').onclick=e=>{ const b=e.target.closest('[data-ck]'); if(!b) return; const i=+b.dataset.ck, s=it.sets[i];
    try{ if(!audioCtx) audioCtx=new (window.AudioContext||window.webkitAudioContext)(); if(audioCtx.state==='suspended') audioCtx.resume(); }catch(err){}
    s.done=!s.done; saveLive();
    if(s.done&&!walk){ restTotal=REST_CAT[CAT[it.id]||'iso']; restEnd=Date.now()+restTotal*1000; }
    const wasLast=it.sets.every(x=>x.done);
    let ssMsg='';
    if(s.done&&!walk){ const nx=it.ss?LIVE.items[LIVE.idx+1]:null, pv=LIVE.idx>0&&LIVE.items[LIVE.idx-1].ss?LIVE.items[LIVE.idx-1]:null;
      if(nx&&!nx.skip&&nx.sets.some(x=>!x.done)){ restEnd=0; LIVE.idx++; saveLive(); ssMsg='🔗 Supersatz: ohne Pause direkt weiter mit Übung B!'; }
      else if(pv&&!pv.skip&&pv.sets.some(x=>!x.done)){ LIVE.idx--; saveLive(); ssMsg='🔗 Supersatz geschafft – jetzt Pause, danach wieder Übung A.'; } }
    renderLive(); if(ssMsg){ $('tsheet').scrollTop=0; setTimeout(()=>{const m=$('lvMsg'); if(m) m.textContent=ssMsg;},0); }
    if(s.done&&!walk&&!LIVE.test&&MC.pro){ const k=kgNum(s.kg), r=parseFloat(s.reps)||0, rc=maxKgRec(it.id), nm=ex.name;
      const sess=it.sets.filter((x,j)=>j!==i&&x.done).reduce((m,x)=>Math.max(m,kgNum(x.kg)),0);
      if(k>0&&rc&&k>rc.kg&&k>sess){ celebrate('Du bist stärker geworden! 💪',`Zum ersten Mal <b>${fmtKg(k)} kg</b> bei ${esc(nm)} geschafft!<br><small>Bisher: ${fmtKg(rc.kg)} kg am ${fmtD(parseD(rc.date))}</small>`); setTimeout(()=>{const m=$('lvMsg'); if(m) m.innerHTML=`🏆 <b>Neuer Rekord: ${fmtKg(k)} kg!</b> Stark – die App hat ihn gespeichert.`;},0); return; }
      if(k===0&&r>0){ const rr=maxRepRec(it.id), sr=it.sets.filter((x,j)=>j!==i&&x.done&&kgNum(x.kg)===0).reduce((m,x)=>Math.max(m,parseFloat(x.reps)||0),0);
        if(rr&&r>rr.reps&&r>sr){ celebrate('Du bist stärker geworden! 💪',`Zum ersten Mal <b>${unitR(it.id,r)}</b> am Stück bei ${esc(nm)} geschafft!<br><small>Bisher: ${unitR(it.id,rr.reps)} am ${fmtD(parseD(rr.date))}</small>`); setTimeout(()=>{const m=$('lvMsg'); if(m) m.innerHTML=`🏆 <b>Neuer Rekord: ${unitR(it.id,r)}!</b> Stark – die App hat ihn gespeichert.`;},0); return; } }
      if(k>0&&rc&&k===rc.kg&&r>rc.reps&&k>=sess){ setTimeout(()=>{const m=$('lvMsg'); if(m) m.innerHTML=`💪 <b>Wiederholungs-Rekord:</b> ${fmtKg(k)} kg × ${r} (bisher × ${rc.reps})`;},0); }
    }
    if(s.done) $('lvMsg').textContent= wasLast ? (LIVE.idx<LIVE.items.length-1?'💪 Übung geschafft! Nach der Pause weiter zur nächsten.':'🏁 Letzte Übung geschafft – Training beenden!') : `Satz ${i+1} ✓ – Pause läuft.`; };
  if($('lvAddSet')) $('lvAddSet').onclick=()=>{ const l=it.sets[it.sets.length-1]||{kg:'',reps:'10'}; it.sets.push({kg:l.kg,reps:l.reps,done:false}); saveLive(); renderLive(); };
  $('lvPrev').onclick=()=>{ if(LIVE.idx>0){LIVE.idx--; saveLive(); renderLive();} };
  if($('lvNext')) $('lvNext').onclick=()=>{ LIVE.idx++; saveLive(); renderLive(); $('tsheet').scrollTop=0; };
  const fin=()=>finishLive(); if($('lvFinish')) $('lvFinish').onclick=fin; if($('lvFinish2')) $('lvFinish2').onclick=fin;
  $('lvSkip').onclick=()=>{ it.skip=!it.skip; if(it.skip){ restEnd=0; if(LIVE.idx<LIVE.items.length-1) LIVE.idx++; } saveLive(); renderLive(); $('tsheet').scrollTop=0;
    const m=$('lvMsg'); if(m&&it.skip) m.textContent='⏭ Übung übersprungen – du kannst sie jederzeit oben über die Nummer wieder aufrufen.'; };
  $('lvCancel').onclick=()=>{ if(LIVE.test){ finishLive(); return; }
    const done=LIVE.items.reduce((a,x)=>a+x.sets.filter(s=>s.done).length,0);
    $('lvCx').innerHTML=`<div class="lvcx"><b>Training abbrechen?</b><span>Dein Trainingsplan bleibt in jedem Fall erhalten.</span>
      ${done?`<button class="pri" id="cxSave">💾 Bisher Geschafftes speichern (${done} ${done===1?'Satz':'Sätze'})</button>`:''}
      <button id="cxDrop">🗑 Verwerfen – nichts speichern</button><button id="cxBack">Weiter trainieren</button></div>`;
    if($('cxSave')) $('cxSave').onclick=()=>finishLive();
    $('cxDrop').onclick=()=>{ LIVE=null; saveLive(); restEnd=0; closeLive(); try{ if(view==='plan') renderPlan(); if(view==='cal') renderCal(); }catch(e){} toast2('Training verworfen – Plan bleibt erhalten'); };
    $('cxBack').onclick=()=>renderLive(); };
  document.querySelectorAll('#tbody [data-open]').forEach(b=>b.onclick=()=>openEx(b.dataset.open));
  tickLive();
}
function finishLive(){
  if(!LIVE) return;
  if(LIVE.test){ LIVE=null; saveLive(); restEnd=0;
    $('tbody').innerHTML='<div class="sum2"><div style="font-size:58px">👀</div><h2>Testlauf beendet</h2><p class="muted">Es wurde nichts gespeichert – kein Kalender-Eintrag, keine Rekorde, dein Plan ist unverändert.</p><button class="savebtn" id="lvDone">Fertig</button></div>';
    $('lvDone').onclick=()=>{ closeLive(); try{ if(view==='plan') renderPlan(); }catch(e){} }; return; }
  const sets={}, prs=[]; let kcal=0, vol=0;
  for(const it of LIVE.items){ const done=it.sets.filter(s=>s.done); if(!done.length) continue;
    const clean=done.map(s=>({kg:String(s.kg||'').replace(',','.'),reps:String(s.reps||'')}));
    if(it.id==='laufband'){ kcal+=kcalFor('laufband',1,`${clean[0].reps} Min · ${clean[0].kg||4} km/h`); sets[it.id]=clean; continue; }
    const hold=isHold(it.target), prev=history(it.id), prevBest=prev.length?Math.max(...prev.map(p=>bestOf(p.sets))):0, nowBest=bestOf(clean);
    const rcPrev=maxKgRec(it.id), topKg=Math.max(0,...clean.map(x=>kgNum(x.kg)));
    const rrPrev=maxRepRec(it.id), topR=Math.max(0,...clean.filter(x=>kgNum(x.kg)===0).map(x=>parseFloat(x.reps)||0));
    if(rcPrev&&topKg>rcPrev.kg){ prs.push(`${exById(it.id).name}: zum ersten Mal ${fmtKg(topKg)} kg (bisher ${fmtKg(rcPrev.kg)} kg)`); }
    else if(rrPrev&&topR>rrPrev.reps){ prs.push(`${exById(it.id).name}: zum ersten Mal ${unitR(it.id,topR)} am Stück (bisher ${unitR(it.id,rrPrev.reps)})`); }
    else if(prev.length&&nowBest>prevBest+0.01){ const top=clean.reduce((a,s)=>e1rm(s)>e1rm(a)?s:a,clean[0]);
      prs.push(`${exById(it.id).name}: ${parseFloat(top.kg)?fmtKg(parseFloat(top.kg))+' kg × ':''}${top.reps}${hold?' s':''}`); }
    for(const s of clean){ kcal+=kcalFor(it.id,1,hold?`${s.reps} s`:String(s.reps||10)); vol+=(parseFloat(s.kg)||0)*(parseFloat(s.reps)||0); }
    sets[it.id]=clean;
    // Plan-Gewicht aktualisieren
    const pi=plan.days[LIVE.day]&&plan.days[LIVE.day].items.find(x=>x.id===it.id), tk=Math.max(...clean.map(s=>parseFloat(s.kg)||0));
    if(pi&&tk>0) pi.kg=fmtKg(tk);
  }
  savePlan();
  const mins=Math.round((Date.now()-LIVE.start)/60000), d=plan.days[LIVE.day]||{name:LIVE.name,items:[]};
  const groups=[...new Set(Object.keys(sets).flatMap(id=>(exById(id)||{g:[]}).g))].filter(g=>g!=='cardio');
  if(Object.keys(sets).length){ LOG.push({date:LIVE.date,day:LIVE.day,name:LIVE.name,groups,kcal:Math.round(kcal),mins,vol:Math.round(vol),sets,ts:Date.now()});
    LOG.sort((a,b)=>a.date<b.date?-1:a.date>b.date?1:a.ts-b.ts); saveLog(); }
  const nSets=Object.values(sets).reduce((a,x)=>a+x.length,0);
  LIVE=null; saveLive(); restEnd=0;
  $('tbody').innerHTML=`<div class="sum2">
    <div style="font-size:58px">${prs.length?'🏆':'💪'}</div>
    <h2>Training geschafft!</h2><p>${esc(d.name)}</p>
    <div class="stats3"><div><b>${mins}</b><small>Minuten</small></div><div><b>${Math.round(kcal)}</b><small>kcal</small></div><div><b>${nSets}</b><small>Sätze</small></div></div>
    ${vol?`<div class="vol">Bewegtes Gewicht: <b>${Math.round(vol).toLocaleString('de-DE')} kg</b></div>`:''}
    ${prs.length?`<div class="prs"><h4>🏆 Du bist stärker geworden!</h4>${prs.map(x=>`<div>${esc(x)}</div>`).join('')}</div>`:'<p class="muted">Tipp: Steigere dich nächstes Mal um eine Wiederholung oder 2,5 kg – die App zeigt dir den Vorschlag.</p>'}
    <a class="wa full" target="_blank" rel="noopener" href="${waHref('🏁 Training geschafft: '+d.name+'\n⏱ '+mins+' Min · 🔥 '+Math.round(kcal)+' kcal · '+nSets+' Sätze'+(vol?' · '+Math.round(vol).toLocaleString('de-DE')+' kg bewegt':'')+(prs.length?'\n🏆 Neue Rekorde: '+prs.join(', '):'')+'\n\nMit Muskel-Coach 💪 '+appUrl())}">${WA_ICON} Erfolg per WhatsApp teilen</a>
    <button class="savebtn" id="lvDone">Fertig – zum Kalender</button></div>`;
  $('lvDone').onclick=()=>{ closeLive(); setView('cal'); window.scrollTo({top:0}); renderSummary(); };
}
document.addEventListener('visibilitychange',()=>{ if(!document.hidden) tickLive(); });

/* Fortschritt einer Übung als Kurve */
function progressHTML(id){
  const hs=history(id).reverse().slice(-12); if(!hs.length) return '<p class="muted">Noch keine Daten – starte ein Training im Plan mit „▶ Training starten“, dann siehst du hier deine Entwicklung.</p>';
  const hold=/\d\s*s/.test((exById(id)||{}).sets||''), vals=hs.map(x=>{const top=x.sets.reduce((a,s)=>e1rm(s)>e1rm(a)?s:a,x.sets[0]); return {v:bestOf(x.sets),top,date:x.date};});
  const max=Math.max(...vals.map(v=>v.v)), min=Math.min(...vals.map(v=>v.v)), W2=300, H2=110, pad=14;
  const X=i=>vals.length===1?W2/2:pad+i*(W2-2*pad)/(vals.length-1), Y=v=>max===min?H2/2:H2-pad-(v-min)*(H2-2*pad)/(max-min);
  const pts=vals.map((v,i)=>`${X(i).toFixed(1)},${Y(v.v).toFixed(1)}`).join(' ');
  const last=vals[vals.length-1], first=vals[0], diff=last.v-first.v;
  const lbl=v=>parseFloat(v.top.kg)?`${fmtKg(parseFloat(v.top.kg))} kg × ${v.top.reps}`:`${v.top.reps}${hold?' s':' Wdh.'}`;
  return `<svg viewBox="0 0 ${W2} ${H2}" class="pchart"><defs><linearGradient id="pcg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c6ff3d" stop-opacity=".35"/><stop offset="1" stop-color="#c6ff3d" stop-opacity="0"/></linearGradient></defs>
    ${vals.length>1?`<polygon points="${X(0).toFixed(1)},${H2} ${pts} ${X(vals.length-1).toFixed(1)},${H2}" fill="url(#pcg)"/><polyline points="${pts}" fill="none" stroke="#c6ff3d" stroke-width="2.5" stroke-linejoin="round"/>`:''}
    ${vals.map((v,i)=>`<circle cx="${X(i).toFixed(1)}" cy="${Y(v.v).toFixed(1)}" r="${v.v===max?5:3.5}" fill="${v.v===max?'#ff9a48':'#c6ff3d'}"/>`).join('')}</svg>
    <div class="pstat"><span>Bestes: <b>${lbl(vals.find(v=>v.v===max))}</b> 🏆</span><span>Zuletzt: <b>${lbl(last)}</b></span>
    ${vals.length>1?`<span>Seit ${fmtD(parseD(first.date))}: <b style="color:${diff>=0?'#7dff9c':'#ff9a6e'}">${diff>=0?'+':''}${Math.round(diff/Math.max(first.v,1)*100)} %</b></span>`:''}</div>
    <p class="muted">Kurve zeigt deine Bestleistung je Training (Gewicht und Wiederholungen zusammengerechnet).</p>`;
}

/* ============ Profil & Bedarfsrechner ============ */
let prof={name:'',sex:'m',age:'',h:'',w:'',act:'1.55',goal:'aufbau',tempo:'0.5',zw:'',steps:'',job:'sitz'};
try{ Object.assign(prof, JSON.parse(testLocal.getItem('mc_prof')||'{}')); }catch(e){}
const fmt=(n,d=0)=>Number(n).toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d});

function calc(p){
  const w=parseFloat(String(p.w).replace(',','.')), h=parseFloat(p.h), a=parseFloat(p.age);
  if(!(w>=35&&w<=250&&h>=120&&h<=230&&a>=14&&a<=99)) return null;
  const bmr = 10*w + 6.25*h - 5*a + (p.sex==='w'?-161:5);
  /* Gesamtumsatz aus Bausteinen:
     1) Grundumsatz × 1,2 = Schlafen, Sitzen, Essen verdauen, ca. 2.500 Schritte Grundbewegung
     2) Schritte darüber: Schrittlänge ≈ 0,415 × Größe; Gehen kostet netto ≈ 0,55 kcal pro kg und km
     3) Arbeit (stehend/schwer) an 5 von 7 Tagen
     4) Krafttraining laut Plan (netto, ohne den Grundumsatz in dieser Zeit), auf die Woche verteilt */
  const steps = Math.max(0, parseFloat(p.steps)>=0 && p.steps!=='' ? parseFloat(p.steps) : 5000);
  const stride = 0.415*h/100, km = Math.max(0,steps-2500)*stride/1000;
  const base = bmr*1.2, stepK = w*km*0.55;
  const JOB={sitz:0,steh:0.12,schwer:0.30,keine:0}, job=p.job in JOB?p.job:'sitz';
  const jobK = bmr*JOB[job]*5/7;
  let trainK=0, perWeek=0;
  try{ perWeek=SCHED.wd.length; const days=plan.days.length||1, avg=plan.days.reduce((s,d)=>s+kcalDay(d),0)/days; trainK=avg*0.75*perWeek/7; }catch(e){}
  const tdee = base+stepK+jobK+trainK;
  const per1000 = w*stride*0.55;
  const ab = p.goal==='ab', tempo = Math.min(1,Math.max(0.25,parseFloat(p.tempo)||0.5));
  let adj = p.goal==='aufbau'?300 : p.goal==='def'?-400 : ab ? -Math.round(tempo*7700/7/10)*10 : 0;
  let kcal = Math.round((tdee+adj)/10)*10, capped=false;
  const kmin = p.sex==='w'?1200:1500;
  if(ab && kcal<kmin){ kcal=kmin; adj=kcal-Math.round(tdee); capped=true; }
  const zw = parseFloat(String(p.zw||'').replace(',','.'));
  const pPerKg = p.goal==='aufbau'?2.0 : p.goal==='def'?2.2 : ab?2.0 : 1.6;
  const protBase = ab && zw>=35 && zw<w ? zw : w;      // beim Abnehmen: Eiweiß am Zielgewicht ausrichten
  const prot = Math.round(protBase*pPerKg);
  const fat = Math.round(w*(ab?0.8:0.9));
  const carbs = Math.max(0, Math.round((kcal - prot*4 - fat*9)/4));
  const creaRaw = w/10;
  const crea = Math.round(creaRaw*2)/2;
  const water = Math.round((w*0.035 + 0.5)*10)/10;
  const bmi = w/((h/100)**2);
  return {w,a,bmr:Math.round(bmr),tdee:Math.round(tdee),parts:{base:Math.round(base),steps,stepK:Math.round(stepK),km:Math.round(km*10)/10,job,jobK:Math.round(jobK),trainK:Math.round(trainK),perWeek,per1000:Math.round(per1000),stepT:n=>Math.round(base+w*Math.max(0,n-2500)*stride/1000*0.55+jobK+trainK)},adj,kcal,pPerKg,prot,protMin:Math.round(w*1.6),protMax:Math.round(w*2.2),fat,carbs,creaRaw,crea,load:Math.round(w*0.3),water,bmi,
          gain: p.goal==='aufbau'?[Math.round(w*0.005*10)/10, Math.round(w*0.015*10)/10]:null,
          loss: ab?{tempo, def:-adj, perWeek:-adj*7/7700, capped, zw:zw>=35&&zw<w?zw:null}:null};
}

function readForm(){
  prof.zw=$('f_zw').value; prof.name=$('f_name').value.trim(); prof.age=$('f_age').value; prof.h=$('f_h').value; prof.w=$('f_w').value; prof.job=$('f_job').value; prof.steps=$('f_steps').value;
}
function fillForm(){
  $('f_name').value=prof.name||''; $('f_age').value=prof.age||''; $('f_h').value=prof.h||''; $('f_w').value=prof.w||''; $('f_job').value=prof.job||'sitz'; $('f_steps').value=prof.steps||''; document.querySelectorAll('#f_stepchips button').forEach(b=>b.classList.toggle('on',String(prof.steps)===b.dataset.s));
  document.querySelectorAll('#f_sex button').forEach(b=>b.classList.toggle('on',b.dataset.v===prof.sex));
  document.querySelectorAll('#f_goal button').forEach(b=>b.classList.toggle('on',b.dataset.v===prof.goal));
  $('abBox').style.display=prof.goal==='ab'?'':'none'; $('f_zw').value=prof.zw||'';
  document.querySelectorAll('#f_tempo button').forEach(b=>b.classList.toggle('on',+b.dataset.v===(parseFloat(prof.tempo)||0.5)));
}
function partsCard(r){ const P=r.parts, JN={sitz:'sitzend',steh:'stehend / viel unterwegs',schwer:'körperlich schwer',keine:'keine'};
  const row=(l,v,sub)=>`<div class="bdr"><span>${l}${sub?`<small>${sub}</small>`:''}</span><b>${v}</b></div>`;
  return `<div class="rc big parts"><small>So setzt sich dein Bedarf zusammen</small>
    ${row('Grundumsatz × 1,2',fmt(P.base)+' kcal',`Körper in Ruhe ${fmt(r.bmr)} kcal + Alltag (Essen, Sitzen, ~2.500 Schritte)`)}
    ${row(`🚶 ${fmt(P.steps)} Schritte`,'+ '+fmt(P.stepK)+' kcal',P.steps>2500?`${fmt(P.km,1)} km zusätzlich gegangen · ca. ${P.per1000} kcal pro 1.000 Schritte`:'nicht mehr als die Grundbewegung')}
    ${row('💼 Arbeit: '+JN[P.job],'+ '+fmt(P.jobK)+' kcal',P.jobK?'an 5 Tagen, auf die Woche verteilt':'')}
    ${row(`🏋️ Krafttraining ${P.perWeek}× pro Woche`,'+ '+fmt(P.trainK)+' kcal','laut deinem Plan, auf alle 7 Tage verteilt')}
    <div class="bdr bsum"><span>= Gesamtumsatz</span><b>${fmt(r.tdee)} kcal</b></div>
    <div class="bdr"><span>${r.adj>0?'+ Überschuss Muskelaufbau':r.adj<0?'− Defizit':'± Ziel halten'}</span><b>${r.adj>0?'+ ':r.adj<0?'− ':''}${fmt(Math.abs(r.adj))} kcal</b></div>
    <div class="bdr bsum bgoal"><span>= Dein Tagesziel</span><b>${fmt(r.kcal)} kcal</b></div>
    <div class="steptab"><small>Gesamtumsatz bei anderen Schrittzahlen:</small><div>${[2000,4000,6000,8000,10000,12000].map(n=>`<span class="${Math.abs(n-P.steps)<1000?'on':''}">${fmt(n/1000)}k<b>${fmt(P.stepT(n))}</b></span>`).join('')}</div></div></div>`; }
function lossCard(r){ const L=r.loss, pw=L.perWeek, now=new Date();
  const fc=wk=>`<div><small>in ${wk} Wochen</small><b>−${fmt(pw*wk,1)} kg</b><span>≈ ${fmt(r.w-pw*wk,1)} kg</span></div>`;
  let goal=''; if(L.zw){ const wks=Math.ceil((r.w-L.zw)/pw), d=addD(now,wks*7); goal=`<div class="abgoal">🎯 Ziel <b>${fmt(L.zw,1)} kg</b> (−${fmt(r.w-L.zw,1)} kg): in ca. <b>${wks} Wochen</b> – etwa <b>${d.getDate()}.${d.getMonth()+1}.${d.getFullYear()}</b></div>`; }
  // echter Verlauf aus „Körper & Maße“
  let real=''; try{ const ws=(typeof BODY!=='undefined'?BODY:[]).filter(b=>b.w&&b.date>=ymd(addD(now,-35))); if(ws.length>=2){ const a=ws[0], b=ws[ws.length-1], days=(parseD(b.date)-parseD(a.date))/864e5;
    if(days>=6){ const rw=(a.w-b.w)/days*7; const ok=rw>=pw*0.6&&rw<=pw*1.5;
      real=`<div class="abreal ${ok?'ok':''}">📉 Tatsächlich laut Waage: <b>${rw>=0?'−':'+'}${fmt(Math.abs(rw),2)} kg/Woche</b> – ${rw<=0?'die Waage steht – nimm ca. 150 kcal weniger oder bewege dich mehr.':rw<pw*0.6?'etwas langsamer als geplant. Dranbleiben – Schwankungen durch Wasser sind normal.':rw>pw*1.5?'schneller als geplant – iss ruhig etwas mehr, damit du keine Muskeln verlierst.':'genau im Plan, super! 💪'}</div>`; } } }catch(e){}
  return `<div class="rc big ab"><small>Dein Abnehm-Plan</small>
    <b style="font-size:26px">−${fmt(L.def)} kcal pro Tag</b>
    <span>${fmt(L.def)} kcal × 7 Tage = ${fmt(L.def*7)} kcal pro Woche. 1 kg Körperfett ≈ 7.700 kcal → <b style="font-size:inherit;display:inline;color:var(--acc)">ca. ${fmt(pw,2).replace(/0$/,'')} kg pro Woche</b>.</span>
    <div class="abfc">${fc(4)}${fc(8)}${fc(12)}</div>${goal}${real}
    ${L.capped?`<div class="warn">Für ${fmt(L.tempo,2).replace(/0$/,'')} kg/Woche müsstest du unter ${prof.sex==='w'?'1.200':'1.500'} kcal essen – das ist zu wenig. Die App rechnet deshalb mit ${fmt(r.kcal)} kcal (≈ ${fmt(pw,2)} kg/Woche).</div>`:''}
    <ul class="pts ok" style="margin-top:10px"><li>Eiweiß hoch halten (${r.prot} g) und weiter Krafttraining machen – so verlierst du Fett statt Muskeln.</li><li>Einmal pro Woche wiegen (gleicher Tag, morgens, nüchtern) und im Reiter „Fortschritt“ eintragen – die App passt die Kalorien automatisch an dein neues Gewicht an.</li><li>Die ersten 1–2 Wochen geht es oft schneller (Wasser), danach pendelt es sich ein.</li></ul></div>`; }
function renderResults(){
  const r=calc(prof);
  if(!r){ $('results').innerHTML='<div class="rc"><span>Trag Alter, Größe und Gewicht ein – die Werte erscheinen sofort.</span></div>'; return; }
  const goalTxt = prof.goal==='aufbau'?'Muskelaufbau (+300 kcal Überschuss)':prof.goal==='def'?'Definieren (−400 kcal Defizit)':prof.goal==='ab'?`Abnehmen (−${fmt(r.loss.def)} kcal Defizit · ca. ${fmt(r.loss.perWeek,2).replace(/0$/,'')} kg/Woche)`:'Gewicht halten';
  const pk=r.prot*4, fk=r.fat*9, ck=r.carbs*4, tot=pk+fk+ck||1;
  let warn='';
  if(r.a<18) warn+='<div class="warn">⚠️ Unter 18: Kreatin und eine gezielte Kalorien-Planung bitte nur nach Rücksprache mit Arzt oder Eltern.</div>';
  if((prof.goal==='def'||prof.goal==='ab') && r.kcal < r.bmr && !(r.loss&&r.loss.capped)) warn+='<div class="warn">Hinweis: Die Zielkalorien liegen unter deinem Grundumsatz – das Defizit lieber etwas kleiner halten.</div>';
  $('results').innerHTML=`
    <h4>${prof.name?'Tagesbedarf für '+esc(prof.name):'Dein Tagesbedarf'}</h4>
    <div class="res">
      <div class="rc big"><small>Kalorien pro Tag · ${goalTxt}</small><b>${fmt(r.kcal)} kcal</b>
        <div class="macro"><i style="width:${pk/tot*100}%;background:var(--acc)"></i><i style="width:${ck/tot*100}%;background:#4fb3ff"></i><i style="width:${fk/tot*100}%;background:var(--acc2)"></i></div>
        <div class="legend"><span><i style="background:var(--acc)"></i>Eiweiß ${r.prot} g</span><span><i style="background:#4fb3ff"></i>Kohlenhydrate ${r.carbs} g</span><span><i style="background:var(--acc2)"></i>Fett ${r.fat} g</span></div>
      </div>
      ${partsCard(r)}
      <div class="rc"><small>Eiweiß / Tag</small><b>${r.prot} g</b><span>${fmt(r.pPerKg,1)} g pro kg · Spanne ${r.protMin}–${r.protMax} g</span></div>
      <div class="rc"><small>Kreatin / Tag</small><b>${fmt(r.crea,1)} g</b><span>1 g pro 10 kg · täglich, auch an Ruhetagen</span></div>
      <div class="rc"><small>Grundumsatz</small><b>${fmt(r.bmr)}</b><span>kcal in völliger Ruhe</span></div>
      <div class="rc"><small>Gesamtumsatz</small><b>${fmt(r.tdee)}</b><span>kcal inkl. Alltag &amp; Training</span></div>
      <div class="rc"><small>Wasser / Tag</small><b>${fmt(r.water,1)} l</b><span>mit Kreatin eher etwas mehr</span></div>
      <div class="rc"><small>BMI</small><b>${fmt(r.bmi,1)}</b><span>bei viel Muskelmasse nur bedingt aussagekräftig</span></div>
      ${r.loss?lossCard(r):''}
      ${r.gain?`<div class="rc big" style="background:var(--card);border-color:var(--line)"><small>Realistische Zunahme beim Aufbau</small><b style="font-size:26px">${fmt(r.gain[0],1)}–${fmt(r.gain[1],1)} kg / Monat</b><span>Nimmst du mehr zu, eher etwas weniger essen. Steht die Waage 3 Wochen still, ~150 kcal mehr.</span></div>`:''}
    </div>
    <div class="block"><h4>Kreatin richtig einnehmen</h4>
      <ul class="pts ok">
        <li>${fmt(r.crea,1)} g Kreatin-Monohydrat jeden Tag (1 g pro 10 kg: ${fmt(r.w,1)} kg ÷ 10 = ${fmt(r.creaRaw,1)} g, auf 0,5 g gerundet).</li>
        <li>Bei Magen-Darm-Problemen die Menge auf 2 Portionen aufteilen oder auf 3–5 g (Standardmenge) reduzieren.</li>
        <li>Die Uhrzeit ist egal – am einfachsten mit einer Mahlzeit oder dem Shake nach dem Training.</li>
        <li>Eine Ladephase ist nicht nötig – nach etwa 2–4 Wochen sind die Speicher voll.</li>
        <li>1–2 kg mehr auf der Waage am Anfang sind normal – das ist Wasser im Muskel, kein Fett.</li>
      </ul></div>
    <div class="block"><h4>Eiweiß über den Tag verteilen</h4>
      <ul class="pts ok">
        <li>3–5 Mahlzeiten mit je ca. ${Math.round(r.prot/4)} g Eiweiß sind ideal.</li>
        <li>Gute Quellen: Hähnchen, Pute, Fisch, Eier, Magerquark, Skyr, Hüttenkäse, Linsen, Tofu, Whey.</li>
      </ul></div>
    ${warn}`;
}
const QUOTES=['Disziplin schlägt Motivation.','Stärker als gestern – das ist das einzige Ziel.','Jede Wiederholung bringt dich näher ans Ziel.','Ausreden bauen keine Muskeln.','Du trainierst für dich in 6 Monaten.','Heute ist ein guter Tag für einen neuen Rekord.','Klein anfangen. Dranbleiben. Groß werden.','Der härteste Satz ist der, der dich verändert.','Komm nicht nur zum Training – komm, um besser zu werden.','Muskeln wachsen durch Geduld und Konstanz.','Kein Shortcut. Nur harte Arbeit.','Der Wille ist der stärkste Muskel.'];
const quoteOfDay=()=>{const d=new Date(); const n=Math.floor((d-new Date(d.getFullYear(),0,0))/864e5); return QUOTES[n%QUOTES.length];};
const HERO={anim:'flexF',prop:'',hl:['bicep','delt','chest','abs']};
const heroSvg=ph=>figure(HERO,ph).replace('viewBox="0 0 200 200"','viewBox="38 4 124 184"');
let heroT0=performance.now();
function heroLoop(){
  const el=$('heroFig');
  if(el && !el.classList.contains('h3d') && !document.querySelector('.sheet.open')){ const x=((performance.now()-heroT0)%2600)/2600; el.innerHTML=heroSvg(0.5-0.5*Math.cos(2*Math.PI*x)); }
  requestAnimationFrame(heroLoop);
}
const HERO3={id:'_hero',noeq:1,anim:'flexF',prop:'',hl:['bicep','delt','chest','abs'],prim:'',sec:'',g:[]};
function heroKey(){ return 'h|'+(typeof curLookIdx==='function'?curLookIdx():0)+'|'+APP_VERSION; }
function heroShow(u){ const el=$('heroFig'); if(!el||!u) return; el.classList.add('h3d'); el.innerHTML=`<img src="${u}" alt="">`; }
function hero3D(){ try{ const c=JSON.parse(testLocal.getItem('mc_hero')||'null'); if(c&&c.k===heroKey()){ heroShow(c.u); return; } }catch(e){}
  if(typeof G3==='undefined'||hero3D.busy) return; hero3D.busy=true;
  setTimeout(()=>{ try{ if(G3.busy&&G3.busy()){ hero3D.busy=false; setTimeout(hero3D,1500); return; } delete G3.TH['_hero']; G3.thumbs([HERO3],()=>{ hero3D.busy=false; const u=G3.TH['_hero']; if(!u) return; heroShow(u); try{ testLocal.setItem('mc_hero',JSON.stringify({k:heroKey(),u})); }catch(e){} }); }catch(e){ hero3D.busy=false; } },400); }

function weekRow(){ if(!MC.pro||!LOG.length) return ''; const m=ymd(monOf(new Date())); const wk=new Set(LOG.filter(l=>l.date>=m).map(l=>l.date)).size; const st=weekStreak(); let pr=0; try{ pr=allRecords().length; }catch(e){}
  return `<div class="wkrow"><div><b>${wk}</b><small>${LX('Trainings diese Woche','workouts this week')}</small></div><div><b>${st} 🔥</b><small>${LX('Wochen-Serie','week streak')}</small></div><div><b>${pr} 🏆</b><small>${LX('Rekorde','records')}</small></div></div>`; }
function renderRecords(){
  const nb=$('nagBox'); if(nb){ nb.innerHTML=(typeof newBanner==='function'?newBanner():'')+backupNag(); const wb=$('wnBan'); if(wb) wb.onclick=()=>showWhatsNew(true); const n=$('nagBak'); if(n) n.onclick=()=>{ setView('prof'); setTimeout(()=>{const b=$('bakMake'); if(b) b.scrollIntoView({behavior:'smooth',block:'center'});},120); }; }
  const box=$('recBox'); if(!box) return; if(!MC.pro){ box.innerHTML=`<button class="recempty" style="text-align:left;width:100%" onclick="upsell('Rekorde')">🔒 <b>Rekord-Speicher</b> – merkt sich dein schwerstes Gewicht und feiert jeden neuen Rekord. In der Vollversion.</button>`; return; } const all=allRecords(), wk=ymd(new Date(Date.now()-7*864e5));
  box.innerHTML = all.length ? `<div class="reclist">${all.map(x=>`<button class="recrow" data-rex="${x.id}"><span class="rn">${esc(x.ex.name)}${x.rec.date>=wk?' <em>NEU</em>':''}</span><span class="rk">${x.rec.kg?`${fmtKg(x.rec.kg)} kg <small>× ${x.rec.reps}</small>`:`${x.rec.reps} <small>${holdOf(x.id)?'Sek.':'Wdh.'}</small>`}</span><span class="rd">${fmtD(parseD(x.rec.date))}</span></button>`).join('')}</div>`
    : `<div class="recempty"><div class="recico">🏆</div><div>${LX('Noch keine Rekorde. Trag beim Training deine Kilo ein – die App merkt sich automatisch dein schwerstes Gewicht pro Übung und feiert jeden neuen Rekord mit dir.','No records yet. Log your weights during your workout – the app automatically remembers your heaviest weight per exercise and celebrates every new record with you.')}</div><button type="button" class="recgo" onclick="setView('plan')">▶ ${LX('Erstes Training starten','Start your first workout')}</button></div>`;
  box.onclick=e=>{const b=e.target.closest('[data-rex]'); if(b) openEx(b.dataset.rex);};
}
function renderSummary(){ setTimeout(renderRecords,0); setTimeout(()=>{ try{ renderInstallCard(); }catch(e){} },0);
  const r=calc(prof), nm=(prof.name||'').trim();
  $('summary').innerHTML=`<button class="hero" id="sumbtn">
    <span class="hfig" id="heroFig">${heroSvg(0.5)}</span>
    <span>
      <small>💪 Motivation des Tages</small>
      <h2>${nm?`Los geht's,<br><span>${esc(nm)}!</span>`:`Los geht's,<br><span>Champion!</span>`}</h2>
      <div class="quote">„${quoteOfDay()}“</div>
      ${r?`<div class="mini4"><span><b>${fmt(r.kcal)}</b> kcal</span><span><b>${r.prot} g</b> Eiweiß</span><span><b>${fmt(r.crea,1)} g</b> Kreatin</span><span><b>${fmt(r.water,1)} l</b> Wasser</span></div><span class="go">Antippen für Details ›</span>`
         :`<span class="go">👤 Antippen und Profil anlegen ›</span>`}
      <div class="nexttr">${heroNext()}</div>
    </span></button>${weekRow()}`;
  $('sumbtn').onclick=openProfile; hero3D();
}
function renderSummaryOld(){
  const r=calc(prof);
  $('summary').innerHTML = r ? `<button class="sum" id="sumbtn">
      <div class="hi">💪 ${prof.name?'Hallo '+esc(prof.name)+' – dein':'Dein'} Tagesziel</div>
      <div class="row">
        <div><b>${fmt(r.kcal)}</b><small>kcal</small></div>
        <div><b>${r.prot} g</b><small>Eiweiß</small></div>
        <div><b>${fmt(r.crea,1)} g</b><small>Kreatin</small></div>
        <div><b>${fmt(r.water,1)} l</b><small>Wasser</small></div>
      </div>
      <div class="edit">Antippen für Details oder zum Ändern</div></button>`
    : `<button class="sum" id="sumbtn"><div class="hi">👤 Profil anlegen</div><div class="edit">Name, Alter, Größe und Gewicht eintragen – Kalorien, Eiweiß und Kreatin werden automatisch berechnet.</div></button>`;
  $('sumbtn').onclick=openProfile;
}
function openProfile(){ setView('prof'); }
function closeProfile(){ renderSummary(); setView('home'); }
function saveProf(){ try{testLocal.setItem('mc_prof',JSON.stringify(prof))}catch(e){} }
$('f_stepchips').onclick=e=>{const b=e.target.closest('button'); if(!b)return; prof.steps=b.dataset.s; fillForm(); renderResults(); saveProf();};
/* Profilbild */
function avatarSrc(){ try{ return testLocal.getItem('mc_avatar')||''; }catch(e){ return ''; } }
function applyAvatar(){ const src=avatarSrc(); const css=src?`url("${src}")`:'';
  const tb=$('openProfile'); if(tb){ tb.classList.toggle('hasimg',!!src); tb.style.backgroundImage=css; }
  const big=$('avPick'); if(big){ big.style.backgroundImage=css; big.textContent=src?'':'👤'; }
  const del=$('avDel'); if(del) del.hidden=!src; }
function cropSquare(file,size){ return new Promise((res,rej)=>{ const fr=new FileReader(); fr.onerror=rej; fr.onload=()=>{ const im=new Image(); im.onerror=rej; im.onload=()=>{
  const m=Math.min(im.width,im.height), c=document.createElement('canvas'); c.width=c.height=size;
  c.getContext('2d').drawImage(im,(im.width-m)/2,(im.height-m)/2,m,m,0,0,size,size); res(c.toDataURL('image/jpeg',.82)); }; im.src=fr.result; }; fr.readAsDataURL(file); }); }
$('avBtn').onclick=$('avPick').onclick=()=>$('avIn').click();
$('avIn').onchange=async e=>{ const f=e.target.files&&e.target.files[0]; e.target.value=''; if(!f) return;
  try{ const d=await cropSquare(f,240); testLocal.setItem('mc_avatar',d); applyAvatar(); toast2('Profilbild gespeichert ✓'); }catch(err){ toast2('Bild konnte nicht gespeichert werden'); } };
$('avDel').onclick=()=>{ try{ testLocal.removeItem('mc_avatar'); }catch(e){} applyAvatar(); toast2('Profilbild entfernt'); };
applyAvatar();
['f_name','f_age','f_h','f_w','f_job','f_steps'].forEach(id=>$(id).addEventListener('input',()=>{readForm(); renderResults(); saveProf();}));
$('f_sex').onclick=e=>{const b=e.target.closest('button'); if(!b)return; prof.sex=b.dataset.v; fillForm(); renderResults(); saveProf();};
$('f_tempo').onclick=e=>{const b=e.target.closest('button'); if(!b)return; prof.tempo=b.dataset.v; fillForm(); renderResults(); saveProf();};
$('f_zw').addEventListener('input',()=>{readForm(); renderResults(); saveProf();});
$('f_goal').onclick=e=>{const b=e.target.closest('button'); if(!b)return; prof.goal=b.dataset.v; fillForm(); renderResults(); saveProf();};
$('psave').onclick=()=>{readForm(); saveProf(); toast2('Gespeichert ✓'); closeProfile();};
{ const op=$('openProfile'); if(op) op.onclick=openProfile; }



/* =====================================================================
   3D-BODYBUILDER  (eigener WebGL-Renderer, ohne externe Bibliothek)
   Nutzt die vorhandenen Bewegungsdaten (T[anim]) und baut daraus
   eine schattierte 3D-Figur mit Muskeln, Geräten und Kamera zum Drehen.
   ===================================================================== */
const G3=(()=>{
const K=0.01;                                   // 1 px der 2D-Daten = 1 cm
const V=(x,y,z)=>[x,y,z], add=(a,b)=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]], sub=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]],
  mul=(a,s)=>[a[0]*s,a[1]*s,a[2]*s], dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2],
  crs=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]], len=a=>Math.hypot(a[0],a[1],a[2]),
  nrm=a=>{const l=len(a)||1;return [a[0]/l,a[1]/l,a[2]/l];}, mix=(a,b,t)=>add(a,mul(sub(b,a),t));

/* ---------- Geometrie ---------- */
function sphere(n=22,m=16){const p=[],i=[];for(let y=0;y<=m;y++){const v=y/m*Math.PI;for(let x=0;x<=n;x++){const u=x/n*2*Math.PI;p.push(Math.sin(v)*Math.cos(u),Math.cos(v),Math.sin(v)*Math.sin(u));}}
  for(let y=0;y<m;y++)for(let x=0;x<n;x++){const a=y*(n+1)+x,b=a+n+1;i.push(a,b,a+1,b,b+1,a+1);}return {p,n:p.slice(),i};}
function cyl(n=20){const p=[],N=[],i=[];for(let k=0;k<=1;k++)for(let x=0;x<=n;x++){const u=x/n*2*Math.PI,c=Math.cos(u),s=Math.sin(u);p.push(c,k-0.5,s);N.push(c,0,s);}
  for(let x=0;x<n;x++){const a=x,b=x+n+1;i.push(a,b,a+1,b,b+1,a+1);}
  for(const k of [0,1]){const y=k-0.5,c0=p.length/3;p.push(0,y,0);N.push(0,k?1:-1,0);for(let x=0;x<=n;x++){const u=x/n*2*Math.PI;p.push(Math.cos(u),y,Math.sin(u));N.push(0,k?1:-1,0);}
    for(let x=0;x<n;x++) k?i.push(c0,c0+x+2,c0+x+1):i.push(c0,c0+x+1,c0+x+2);} return {p,n:N,i};}
function box(){const p=[],N=[],i=[];const F=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
  for(const f of F){const a=f.map(Math.abs),u=a[0]?[0,1,0]:[1,0,0],v=crs(f,u),b=p.length/3;
    for(const [s,t] of [[-1,-1],[1,-1],[1,1],[-1,1]]){p.push(.5*(f[0]+u[0]*s+v[0]*t),.5*(f[1]+u[1]*s+v[1]*t),.5*(f[2]+u[2]*s+v[2]*t));N.push(...f);}
    i.push(b,b+1,b+2,b,b+2,b+3);} return {p,n:N,i};}

const VS=`attribute vec3 aP,aN;attribute float aMu;attribute vec4 aR;uniform mat4 uM,uVP;uniform mat3 uNm;uniform float uTp;uniform float uHot[17];varying vec3 vN,vW;varying float vHot;varying vec4 vR;
void main(){vec3 p=aP;float s=mix(1.0,uTp,p.y+0.5);p.xz*=s;vec4 w=uM*vec4(p,1.0);vW=w.xyz;vN=normalize(uNm*aN);vHot=uHot[int(aMu+0.5)];vR=aR;gl_Position=uVP*w;}`;
const FS=`precision mediump float;varying vec3 vN,vW;varying float vHot;varying vec4 vR;uniform vec3 uC,uE,uCam,uR0,uR1,uR2,uR3,uHc,uHe;uniform float uSp,uSh,uFl,uAn;uniform vec4 uSd[6];
void main(){
 if(uFl>0.5){float d=length(vW.xz);vec3 c=vec3(0.13,0.14,0.15)*(1.0-smoothstep(0.4,2.6,d));
  vec2 gq=abs(fract(vW.xz*4.0)-0.5);float gl=1.0-smoothstep(0.0,0.03,0.5-max(gq.x,gq.y));c+=vec3(0.05,0.085,0.095)*gl*(1.0-smoothstep(0.5,2.3,d));
  vec2 mq=abs(vW.xz);float mm2=max(mq.x,mq.y);float mt=1.0-smoothstep(0.7,0.72,mm2);c=mix(c,vec3(0.12,0.27,0.28),mt*0.9);c+=vec3(0.12,0.3,0.3)*mt*smoothstep(0.62,0.71,mm2);
  float sh=0.0;for(int i=0;i<6;i++){vec2 q=(vW.xz-uSd[i].xy)/max(uSd[i].z,0.001);sh=max(sh,uSd[i].w*(1.0-smoothstep(0.2,1.0,length(q))));}
  c*=1.0-sh*0.75;float a=1.0-smoothstep(1.2,2.9,d);gl_FragColor=vec4(pow(c,vec3(0.4545)),a);return;}
 vec3 n=normalize(vN);vec3 v=normalize(uCam-vW);if(dot(n,v)<0.0)n=-n;
 vec3 base=uC;base=mix(base,uR0,vR.x);base=mix(base,uR1,vR.y);base=mix(base,uR2,vR.z);base=mix(base,uR3,vR.w);
 float matte=max(max(vR.x,vR.y),vR.w);
 base=mix(base,uHc,vHot);
 vec3 l1=normalize(vec3(-0.55,0.85,0.75)),l2=normalize(vec3(0.8,0.25,0.5)),l3=normalize(vec3(0.15,0.35,-1.0)),l4=normalize(vec3(-0.6,0.2,-0.8));
 vec3 amb=mix(vec3(0.05,0.045,0.045),vec3(0.30,0.31,0.35),n.y*0.5+0.5)*0.75;
 float wrap=max((dot(n,l1)+0.25)/1.25,0.0);
 vec3 d=amb+vec3(1.0,0.92,0.82)*wrap*1.0+vec3(0.42,0.5,0.65)*max(dot(n,l2),0.0)*0.45;
 vec3 rim=(vec3(0.62,0.68,0.8)*pow(max(dot(n,l3),0.0),1.5)*0.55+vec3(0.95,0.62,0.48)*pow(max(dot(n,l4),0.0),2.0)*0.3)*(1.0-0.5*uAn)+vec3(0.55,0.55,0.6)*max(dot(n,normalize(vec3(0.3,0.7,-0.6))),0.0)*0.35;
 vec3 h=normalize(l1+v);float sp=pow(max(dot(n,h),0.0),uSh)*uSp*(1.0-0.85*matte);
 float fr=pow(1.0-max(dot(n,v),0.0),3.0);
 vec3 sss=vec3(0.16,0.05,0.03)*(1.0-wrap)*(1.0-matte)*(1.0-uAn);
 vec3 c=base*(d+rim)+sss*base+vec3(1.0,0.95,0.9)*sp+fr*vec3(0.9,0.3,0.2)*0.2+uE+uHe*vHot;
 c=1.0-exp(-c*1.25);gl_FragColor=vec4(pow(c,vec3(0.4545)),1.0);}`;

function Engine(canvas){
  const gl=canvas.getContext('webgl',{antialias:true,alpha:true,premultipliedAlpha:false,preserveDrawingBuffer:true});
  if(!gl) throw new Error('kein WebGL');
  const sh=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(o));return o;};
  const pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,VS));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(pr);gl.useProgram(pr);
  const U={};['uM','uVP','uNm','uTp','uC','uE','uCam','uSp','uSh','uFl','uSd','uHot','uR0','uR1','uR2','uR3','uHc','uHe','uAn'].forEach(k=>U[k]=gl.getUniformLocation(pr,k));
  const aMu=gl.getAttribLocation(pr,'aMu'),aR=gl.getAttribLocation(pr,'aR'), U32=gl.getExtension('OES_element_index_uint'), MC=new Map();
  const aP=gl.getAttribLocation(pr,'aP'),aN=gl.getAttribLocation(pr,'aN');
  const mk=g=>{const b=[gl.createBuffer(),gl.createBuffer(),gl.createBuffer()];gl.bindBuffer(gl.ARRAY_BUFFER,b[0]);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(g.p),gl.STATIC_DRAW);
    gl.bindBuffer(gl.ARRAY_BUFFER,b[1]);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(g.n),gl.STATIC_DRAW);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,b[2]);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(g.i),gl.STATIC_DRAW);return {b,c:g.i.length};};
  const M={s:mk(sphere()),c:mk(cyl()),b:mk(box())};
  gl.enable(gl.DEPTH_TEST);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
  let cur=null;
  function bindMesh(m){ let o=MC.get(m.id); if(!o){ const big=m.p.length/3>65535; const b=[gl.createBuffer(),gl.createBuffer(),gl.createBuffer(),gl.createBuffer(),gl.createBuffer()];
      gl.bindBuffer(gl.ARRAY_BUFFER,b[0]);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(m.p),gl.STATIC_DRAW);gl.bindBuffer(gl.ARRAY_BUFFER,b[1]);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(m.n),gl.STATIC_DRAW);
      gl.bindBuffer(gl.ARRAY_BUFFER,b[3]);gl.bufferData(gl.ARRAY_BUFFER,m.mu,gl.STATIC_DRAW);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,b[2]);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,big?new Uint32Array(m.i):new Uint16Array(m.i),gl.STATIC_DRAW);
      o={b,c:m.i.length,ver:-1,t:big?gl.UNSIGNED_INT:gl.UNSIGNED_SHORT}; MC.set(m.id,o); }
    if(o.ver!==m.ver){ gl.bindBuffer(gl.ARRAY_BUFFER,o.b[4]); gl.bufferData(gl.ARRAY_BUFFER,m.reg,gl.DYNAMIC_DRAW); o.ver=m.ver; }
    cur=null; gl.bindBuffer(gl.ARRAY_BUFFER,o.b[0]);gl.enableVertexAttribArray(aP);gl.vertexAttribPointer(aP,3,gl.FLOAT,false,0,0);
    gl.bindBuffer(gl.ARRAY_BUFFER,o.b[1]);gl.enableVertexAttribArray(aN);gl.vertexAttribPointer(aN,3,gl.FLOAT,false,0,0);
    gl.bindBuffer(gl.ARRAY_BUFFER,o.b[3]);gl.enableVertexAttribArray(aMu);gl.vertexAttribPointer(aMu,1,gl.FLOAT,false,0,0);
    gl.bindBuffer(gl.ARRAY_BUFFER,o.b[4]);gl.enableVertexAttribArray(aR);gl.vertexAttribPointer(aR,4,gl.FLOAT,false,0,0);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,o.b[2]); return o; }
  function bind(m){if(cur===m)return;cur=m;const o=M[m];gl.disableVertexAttribArray(aMu);gl.vertexAttrib1f(aMu,0);gl.disableVertexAttribArray(aR);gl.vertexAttrib4f(aR,0,0,0,0);gl.bindBuffer(gl.ARRAY_BUFFER,o.b[0]);gl.enableVertexAttribArray(aP);gl.vertexAttribPointer(aP,3,gl.FLOAT,false,0,0);
    gl.bindBuffer(gl.ARRAY_BUFFER,o.b[1]);gl.enableVertexAttribArray(aN);gl.vertexAttribPointer(aN,3,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,o.b[2]);}
  function persp(f,a,n,fa){const t=1/Math.tan(f/2);return [t/a,0,0,0,0,t,0,0,0,0,(fa+n)/(n-fa),-1,0,0,2*fa*n/(n-fa),0];}
  function look(e,c){const z=nrm(sub(e,c)),x=nrm(crs([0,1,0],z)),y=crs(z,x);return [x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,e),-dot(y,e),-dot(z,e),1];}
  function mm(a,b){const o=new Array(16);for(let i=0;i<4;i++)for(let j=0;j<4;j++){let s=0;for(let k=0;k<4;k++)s+=a[k*4+j]*b[i*4+k];o[i*4+j]=s;}return o;}
  function render(items,cam,shadows){
    const w=canvas.width,h=canvas.height;gl.viewport(0,0,w,h);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    gl.uniformMatrix4fv(U.uVP,false,mm(persp(cam.fov,w/h,0.05,30),look(cam.eye,cam.target)));gl.uniform3fv(U.uCam,cam.eye);
    const sd=new Float32Array(24);(shadows||[]).slice(0,6).forEach((s,i)=>sd.set(s,i*4));gl.uniform4fv(U.uSd,sd);
    // Boden
    if(!NOFL){ gl.uniform1f(U.uFl,1);bind('c');gl.uniformMatrix4fv(U.uM,false,[3,0,0,0,0,0.002,0,0,0,0,3,0,cam.target[0],-0.001,cam.target[2],1]);gl.uniformMatrix3fv(U.uNm,false,[1,0,0,0,1,0,0,0,1]);gl.uniform1f(U.uTp,1);
    gl.depthMask(false);gl.drawElements(gl.TRIANGLES,M.c.c,gl.UNSIGNED_SHORT,0);gl.depthMask(true);gl.uniform1f(U.uFl,0); }
    const R=REGC(); gl.uniform3fv(U.uR0,R[0]);gl.uniform3fv(U.uR1,R[1]);gl.uniform3fv(U.uR2,R[2]);gl.uniform3fv(U.uR3,R[3]);gl.uniform1fv(U.uHot,R[4]);gl.uniform3fv(U.uHc,R[5]);gl.uniform3fv(U.uHe,R[6]);gl.uniform1f(U.uAn,LOOK.anat||LOOK.skin==='pro'?1:0);
    for(const it of items){ let cnt,typ=gl.UNSIGNED_SHORT; if(typeof it.m==='object'){ const o=bindMesh(it.m); cnt=o.c; typ=o.t; } else { bind(it.m); cnt=M[it.m].c; }
      gl.uniformMatrix4fv(U.uM,false,it.M);gl.uniformMatrix3fv(U.uNm,false,it.N);gl.uniform1f(U.uTp,it.tp||1);
      gl.uniform3fv(U.uC,it.c);gl.uniform3fv(U.uE,it.e||[0,0,0]);gl.uniform1f(U.uSp,it.sp??0.25);gl.uniform1f(U.uSh,it.sh??30);gl.drawElements(gl.TRIANGLES,cnt,typ,0);}
  }
  return {gl,render,canvas};
}

/* ---------- Materialien ---------- */
let SKIN=[0.56,0.30,0.17], SKIN2=[0.48,0.25,0.14], SHORTS=[0.035,0.035,0.04], HAIR=[0.05,0.035,0.03], LOOK={hair:'quiff',beard:'full'}, SHOE=[0.06,0.06,0.07], SOLE=[0.85,0.85,0.85],
  FRAME=[0.16,0.18,0.2], STEEL=[0.62,0.65,0.68], PAD=[0.09,0.09,0.1], PLATE=[0.07,0.07,0.08], CABLE=[0.75,0.77,0.8];
let HOT=new Set(), HOT2=new Set(), PULSE=0;
const AN_RED=[0.40,0.02,0.035], AN_PINK=[0.86,0.5,0.47];
function REGC(){ const hot=new Float32Array(17); for(let i=1;i<17;i++) hot[i]=HOT.has(MUS[i])?1:(HOT2.has(MUS[i])?(LOOK.anat?0.42:0.3):0);
  if(LOOK.anat) return [SKIN,SKIN,SKIN,SKIN,hot,AN_RED,[0.05+0.05*PULSE,0.0,0.0]];
  const BEARD=HAIR.map((v,i)=>v*1.3+[0.035,0.022,0.015][i]);
  const HC=LOOK.hot||[0.95,0.28,0.08], HE=LOOK.hot?[0.32+0.18*PULSE,0.02,0.01]:[0.35+0.25*PULSE,0.07,0.0];
  return [SHORTS,BEARD,LOOK.skin==='pro'?[0.45,0.4,0.4]:LOOK.g==='w'?[0.56,0.26,0.25]:[0.46,0.2,0.15],HAIR,hot,HC,HE]; }
const SKINS={pro:[0.6,0.61,0.63],anat:[0.80,0.78,0.74],tan:[0.56,0.30,0.17],light:[0.72,0.47,0.34],olive:[0.5,0.32,0.18],dark:[0.22,0.11,0.06]};
function setLook(o){ LOOK=Object.assign({g:'m',legs:'shorts',hair:'quiff',beard:'full',skin:'tan',hairCol:[0.05,0.035,0.03],shorts:[0.035,0.035,0.04]},o||{});
  if(LOOK.anat){ LOOK.skin='anat'; LOOK.hair='bald'; LOOK.beard='none'; }
  SKIN=SKINS[LOOK.skin]||SKINS.tan; SKIN2=SKIN.map(v=>v*0.86); HAIR=LOOK.anat?SKIN:LOOK.hairCol; SHORTS=LOOK.anat?SKIN:LOOK.shorts; SHOE=LOOK.anat?SKIN.map(v=>v*0.9):[0.06,0.06,0.07]; scene.cache=null; for(const k in MESHES){ const m=MESHES[k]; if(m) [m.head,m.th,m.sh].forEach(setRegions); } }
const mat=(key,base)=>HOT.has(key)?(LOOK.anat?{c:AN_RED,e:[0.05,0,0],sp:0.45,sh:40}:{c:LOOK.hot||[0.95,0.28,0.08],e:LOOK.hot?[0.32+0.18*PULSE,0.02,0.01]:[0.35+0.25*PULSE,0.07,0.0],sp:0.45,sh:40}):(HOT2.has(key)?(LOOK.anat?{c:AN_PINK,sp:0.4,sh:34}:{c:(base||SKIN).map((v,i)=>v*0.7+(LOOK.hot||[0.95,0.28,0.08])[i]*0.3),sp:0.4,sh:34}):{c:base||SKIN,sp:0.38,sh:34});

/* Teil-Matrix: Ursprung o, Basis x,y,z (orthonormal), Skalierung s, lokaler Versatz off */
function part(m,o,x,y,z,s,off,mt,tp){const p=add(o,add(add(mul(x,off[0]),mul(y,off[1])),mul(z,off[2])));
  return Object.assign({m,tp,M:[x[0]*s[0],x[1]*s[0],x[2]*s[0],0,y[0]*s[1],y[1]*s[1],y[2]*s[1],0,z[0]*s[2],z[1]*s[2],z[2]*s[2],0,p[0],p[1],p[2],1],
    N:[x[0]/s[0],x[1]/s[0],x[2]/s[0],y[0]/s[1],y[1]/s[1],y[2]/s[1],z[0]/s[2],z[1]/s[2],z[2]/s[2]]},mt);}
function frame(a,b,front){const d=sub(b,a),L=len(d)||1e-4,y=mul(d,1/L);let z=sub(front,mul(y,dot(front,y)));if(len(z)<0.15)z=sub([0,1,0],mul(y,y[1]));if(len(z)<0.15)z=crs(y,[1,0,0]);z=nrm(z);const x=crs(y,z);return {a,b,x,y,z,L};}
const ell=(F,t,off,r,mt)=>part('s',F.a,F.x,F.y,F.z,r,[off[0],F.L*t,off[1]],mt);
const tube=(F,r0,r1,mt,t0=0,t1=1)=>part('c',F.a,F.x,F.y,F.z,[r0,F.L*(t1-t0),r0],[0,F.L*(t0+t1)/2,0],mt,r1/r0);
const ball=(p,r,mt)=>part('s',p,[1,0,0],[0,1,0],[0,0,1],[r,r,r],[0,0,0],mt);
function rod(a,b,r,c,sp=0.5){const F=frame(a,b,[0,0,1]);return tube(F,r,r,{c,sp,sh:60});}
function slab(a,b,w,t,c,lat){const F=frame(a,b,lat);return part('b',F.a,F.x,F.y,F.z,[t,F.L,w],[0,F.L/2,0],{c,sp:0.15,sh:20});}

/* ---------- 2D-Pose -> 3D-Gelenke ---------- */
function joints(tp,ex,p){
  const v=tp.view, Y=y=>(184-y)*K;
  const J={};
  if(v==='s'){
    const P3=(k,lat)=>p[k]?[lat,Y(p[k][1]),(p[k][0]-100)*K]:null;
    const wide=ex.prop==='bar'||tp.barAt?0.3:0.2;
    J.H=P3('hp',0);J.S=P3('sh',0);J.hd=P3('hd',0);J.f=tp.prone?[0,-1,0]:[0,0,1];
    if(tp.dynFront){ const d=nrm(sub(J.S,J.H)); J.f=nrm([0,-d[2],d[1]]); }
    for(const [s,sg] of [['R',-1],['L',1]]){ const two=s==='L'&&p.el2, ek=two?'el2':'el', hk=two?'ha2':'ha', lw=two&&p.lw2?p.lw2:p.lw;
      J['sh'+s]=P3('sh',0.19*sg);J['el'+s]=P3(ek,(lw?lw[0]*K:(wide>0.2?0.3:0.22))*sg);J['ha'+s]=P3(hk,(lw?lw[1]*K:wide)*sg);}
    J.hpR=P3('hp',-0.095);J.hpL=P3('hp',0.095);
    const k2=p.kn2?'kn2':'kn',f2=p.kn2?'ft2':'ft',t2=p.kn2?'to2':'to';
    const lk=p.lwl?p.lwl[0]*K:0.1, lf=p.lwl?p.lwl[1]*K:0.11; J.knR=P3('kn',-lk);J.ftR=P3('ft',-lf);J.toR=P3('to',-lf-0.01);J.knL=P3(k2,lk);J.ftL=P3(f2,lf);J.toL=P3(t2,lf+0.01);
  } else {
    const fz=v==='b'?-1:1, P3=k=>p[k]?[(p[k][0]-100)*K,Y(p[k][1]),(p[k][2]||0)*K*fz]:null;
    for(const k of ['shL','shR','elL','elR','haL','haR','hpL','hpR','knL','knR','ftL','ftR','hd','nk','pv']) J[k]=P3(k);
    J.S=mix(J.shL,J.shR,.5);J.H=J.pv||mix(J.hpL,J.hpR,.5);J.f=[0,0,fz];
    J.toL=add(J.ftL,[0,0,0.15*fz]);J.toR=add(J.ftR,[0,0,0.15*fz]);
  }
  return J;
}

/* ---------- Körper bauen ---------- */
/* ---------- Glatte Haut: Formen verschmelzen (Signed Distance Fields + Surface Nets) ---------- */
const sdE=(p,c,r)=>{const x=(p[0]-c[0])/r[0],y=(p[1]-c[1])/r[1],z=(p[2]-c[2])/r[2],k0=Math.hypot(x,y,z),k1=Math.hypot(x/r[0],y/r[1],z/r[2]);return k1?k0*(k0-1)/k1:-Math.min(...r);};
const sdRC=(p,a,b,r1,r2)=>{const ba=sub(b,a),pa=sub(p,a),L=len(ba),h=Math.max(0,Math.min(1,dot(pa,ba)/(L*L)));const r=r1+(r2-r1)*h;return len(sub(pa,mul(ba,h)))-r;};
const smin=(a,b,k)=>{const h=Math.max(k-Math.abs(a-b),0)/k;return Math.min(a,b)-h*h*k*0.25;};
const smax=(a,b,k)=>-smin(-a,-b,k);
const sstep=(e0,e1,x)=>{const t=Math.max(0,Math.min(1,(x-e0)/(e1-e0)));return t*t*(3-2*t);};
const MUS=['','chest','abs','oblique','lat','back','erector','trap','glute','delt','bicep','tricep','forearm','quad','ham','calf','neck'];
/* Form: Liste von Teilen {t:'e'|'rc', ..., k:Verschmelzung, mu:Muskel-Nr, neg:abziehen} */
function shapeSDF(parts){
  /* Beschleunigung: Hüllkugel je Teil – weit entfernte Teile beeinflussen das Ergebnis nicht und werden übersprungen */
  for(const q of parts){ if(q.t==='e'){ q._c=q.c; q._R=Math.max(...q.r); } else { q._c=mix(q.a,q.b,0.5); q._R=len(sub(q.b,q.a))/2+Math.max(q.r1,q.r2); } }
  return p=>{ let d=1e9; for(const q of parts){
    if(!q.neg&&d<1e8){ const dx=p[0]-q._c[0],dy=p[1]-q._c[1],dz=p[2]-q._c[2], lb=Math.sqrt(dx*dx+dy*dy+dz*dz)-q._R*1.05; if(lb>d+(q.k||0.02)) continue; }
    if(q.neg&&d<1e8){ const dx=p[0]-q._c[0],dy=p[1]-q._c[1],dz=p[2]-q._c[2], lb=Math.sqrt(dx*dx+dy*dy+dz*dz)-q._R*1.05; if(lb>(q.k||0.01)&&-lb<d-(q.k||0.01)) continue; }
    const v=q.t==='e'?sdE(p,q.c,q.r):sdRC(p,q.a,q.b,q.r1,q.r2);
    d=q.neg?smax(d,-v,q.k||0.01):(d>1e8?v:smin(d,v,q.k||0.02)); } return d; }; }
function surfaceNet(sdf,mn,mx,h){
  const nx=Math.ceil((mx[0]-mn[0])/h)+1,ny=Math.ceil((mx[1]-mn[1])/h)+1,nz=Math.ceil((mx[2]-mn[2])/h)+1, F=new Float32Array(nx*ny*nz);
  const I=(i,j,k)=>i+nx*(j+ny*k);
  for(let k=0;k<nz;k++)for(let j=0;j<ny;j++)for(let i=0;i<nx;i++) F[I(i,j,k)]=sdf([mn[0]+i*h,mn[1]+j*h,mn[2]+k*h]);
  const C=new Int32Array((nx-1)*(ny-1)*(nz-1)).fill(-1), CI=(i,j,k)=>i+(nx-1)*(j+(ny-1)*k), P=[];
  const E=[[0,1],[2,3],[4,5],[6,7],[0,2],[1,3],[4,6],[5,7],[0,4],[1,5],[2,6],[3,7]];
  for(let k=0;k<nz-1;k++)for(let j=0;j<ny-1;j++)for(let i=0;i<nx-1;i++){
    const v=[],q=[];for(let c=0;c<8;c++){const a=c&1,b=(c>>1)&1,d=(c>>2)&1;v.push(F[I(i+a,j+b,k+d)]);q.push([a,b,d]);}
    let neg=0;for(const x of v) if(x<0) neg++; if(!neg||neg===8) continue;
    let s=[0,0,0],n=0;for(const [a,b] of E){ if((v[a]<0)!==(v[b]<0)){const t=v[a]/(v[a]-v[b]);for(let z=0;z<3;z++) s[z]+=q[a][z]+(q[b][z]-q[a][z])*t; n++;} }
    C[CI(i,j,k)]=P.length/3; P.push(mn[0]+(i+s[0]/n)*h,mn[1]+(j+s[1]/n)*h,mn[2]+(k+s[2]/n)*h);
  }
  const T=[];
  const quad=(a,b,c,d,flip)=>{ if(a<0||b<0||c<0||d<0) return; flip?T.push(a,c,b,a,d,c):T.push(a,b,c,a,c,d); };
  for(let k=1;k<nz-1;k++)for(let j=1;j<ny-1;j++)for(let i=0;i<nx-1;i++){ const a=F[I(i,j,k)],b=F[I(i+1,j,k)]; if((a<0)===(b<0)) continue;
    quad(C[CI(i,j-1,k-1)],C[CI(i,j,k-1)],C[CI(i,j,k)],C[CI(i,j-1,k)],a<0); }
  for(let k=1;k<nz-1;k++)for(let j=0;j<ny-1;j++)for(let i=1;i<nx-1;i++){ const a=F[I(i,j,k)],b=F[I(i,j+1,k)]; if((a<0)===(b<0)) continue;
    quad(C[CI(i-1,j,k-1)],C[CI(i-1,j,k)],C[CI(i,j,k)],C[CI(i,j,k-1)],a<0); }
  for(let k=0;k<nz-1;k++)for(let j=1;j<ny-1;j++)for(let i=1;i<nx-1;i++){ const a=F[I(i,j,k)],b=F[I(i,j,k+1)]; if((a<0)===(b<0)) continue;
    quad(C[CI(i-1,j-1,k)],C[CI(i,j-1,k)],C[CI(i,j,k)],C[CI(i-1,j,k)],a<0); }
  const N=[], e=h*0.5;
  for(let o=0;o<P.length;o+=3){ const p=[P[o],P[o+1],P[o+2]];
    const g=nrm([sdf([p[0]+e,p[1],p[2]])-sdf([p[0]-e,p[1],p[2]]),sdf([p[0],p[1]+e,p[2]])-sdf([p[0],p[1]-e,p[2]]),sdf([p[0],p[1],p[2]+e])-sdf([p[0],p[1],p[2]-e])]); N.push(...g); }
  return {p:P,n:N,i:T};
}
let MESHID=0;
function buildMesh(parts,mn,mx,h,regFn){ const g=surfaceNet(shapeSDF(parts),mn,mx,h), nv=g.p.length/3, mu=new Float32Array(nv), muP=parts.filter(q=>q.mu);
  for(let v=0;v<nv;v++){ const p=[g.p[v*3],g.p[v*3+1],g.p[v*3+2]]; let best=0,bd=0.014; for(const q of muP){ const d=q.t==='e'?sdE(p,q.c,q.r):sdRC(p,q.a,q.b,q.r1,q.r2); if(d<bd){bd=d;best=q.mu;} } mu[v]=best; }
  const m={id:++MESHID,p:g.p,n:g.n,i:g.i,mu,reg:new Float32Array(nv*4),ver:1,regFn};
  setRegions(m); return m; }
function setRegions(m){ if(!m.regFn) return; for(let v=0;v<m.mu.length;v++){ const r=m.regFn([m.p[v*3],m.p[v*3+1],m.p[v*3+2]]); m.reg.set(r,v*4); } m.ver++; }

/* Nennlängen der Körperteile (aus der 2D-Grundhaltung) */
const LN={ua:0.26,fa:0.25,th:0.35,sh:0.34,to:0.5};
const E_=(c,r,k,mu)=>({t:'e',c,r,k,mu}), RC=(a,b,r1,r2,k,mu)=>({t:'rc',a,b,r1,r2,k,mu});
let MESH=null, MESHES={};
function headRegions(p){ const [x,y,z]=p, L=LOOK; let beard=0,lip=0,hair=0,shorts=0;
  // Lippen
  const ly=(y+0.0495)/0.0095, lx=x/0.021; if(z>0.075&&lx*lx+ly*ly<1) lip=1-sstep(0.6,1,Math.sqrt(lx*lx+ly*ly));
  // Augenbrauen
  for(const s of [-1,1]){ const bx=(x-0.031*s)/0.021, by=(y-0.034)/0.0055; if(z>0.06){ const d=bx*bx+by*by; if(d<1) hair=Math.max(hair,1-sstep(0.5,1,d)); } }
  // Bart
  if(L.beard!=='none'){ const ylim=-0.04+0.016*sstep(0.02,0.06,Math.abs(x)), lower=1-sstep(ylim-0.006,ylim+0.006,y), front=sstep(-0.025,0.005,z), side=1-sstep(0.064,0.075,Math.abs(x)), neck=sstep(-0.118,-0.1,y);
    let b=lower*front*side*neck;
    const ms=(1-sstep(0.022,0.03,Math.abs(x)))*sstep(-0.05,-0.046,y)*(1-sstep(-0.038,-0.034,y))*sstep(0.075,0.08,z); // Oberlippenbart
    if(L.beard==='goatee') b*=1-sstep(0.022,0.032,Math.abs(x));
    if(L.beard!=='stubble'&&L.beard!=='goatee'){} b=Math.max(b,L.beard==='none'?0:ms);
    b*=1-lip; beard=b*(L.beard==='stubble'?0.55:1); }
  // Haaransatz (kurze Seiten / Buzzcut)
  if(L.hair!=='bald'){ const top=sstep(0.0,0.03,y-(z>0.03?0.045:0.0)), back=sstep(-0.01,-0.05,z)*sstep(-0.06,-0.02,y);
    const ear=sstep(0.06,0.075,Math.abs(x))*sstep(-0.02,0.0,y);
    let hl=Math.max(top*(1-sstep(0.05,0.085,z)),back,ear*0.9); if(y<-0.07) hl=0;
    hair=Math.max(hair,hl*(L.hair==='buzz'?0.85:0.7)); }
  // Hals unten etwas dunkler? nein
  return [shorts,beard,lip,hair]; }
function buildMeshes(){
  const t0=performance.now();
  // Kopf + Hals (Ursprung Kopfmitte, y oben, z vorne)
  const head=[E_([0,0.012,-0.006],[0.075,0.098,0.092]), E_([0.036,-0.02,0.045],[0.033,0.036,0.038],0.025), E_([-0.036,-0.02,0.045],[0.033,0.036,0.038],0.025),
    E_([0,-0.056,0.02],[0.057,0.034,0.058],0.025), E_([0.047,-0.05,-0.005],[0.026,0.034,0.04],0.03), E_([-0.047,-0.05,-0.005],[0.026,0.034,0.04],0.03),
    E_([0,-0.082,0.058],[0.026,0.022,0.024],0.025), E_([0,0.031,0.074],[0.058,0.013,0.02],0.02),
    RC([0,0.024,0.084],[0,-0.016,0.101],0.0085,0.012,0.012), E_([0.011,-0.02,0.093],[0.009,0.008,0.009],0.006), E_([-0.011,-0.02,0.093],[0.009,0.008,0.009],0.006),
    E_([0,-0.045,0.086],[0.018,0.0045,0.009],0.006), E_([0,-0.054,0.084],[0.017,0.0055,0.009],0.006),
    E_([0.078,0.0,-0.008],[0.012,0.026,0.017],0.008), E_([-0.078,0.0,-0.008],[0.012,0.026,0.017],0.008),
    RC([0,-0.05,-0.02],[0,-0.19,-0.025],0.056,0.064,0.03,16),
    {t:'e',c:[0.031,0.014,0.088],r:[0.017,0.012,0.012],k:0.008,neg:1},{t:'e',c:[-0.031,0.014,0.088],r:[0.017,0.012,0.012],k:0.008,neg:1}];
  const mHead=buildMesh(head,[-0.11,-0.2,-0.12],[0.11,0.13,0.13],0.0048,headRegions);
  // Rumpf (Ursprung Hüfte, Höhe 0..0.5 = Hüfte..Schulter)
  const tor=[E_([0,0.02,0],[0.165,0.12,0.12]), E_([0.07,-0.015,-0.07],[0.088,0.095,0.08],0.03,8), E_([-0.07,-0.015,-0.07],[0.088,0.095,0.08],0.03,8),
    E_([0,0.17,0],[0.128,0.12,0.1],0.05), E_([0,0.32,0],[0.16,0.16,0.122],0.05), E_([0,0.43,-0.005],[0.215,0.11,0.12],0.05), E_([0,0.49,-0.02],[0.228,0.06,0.1],0.04),
    E_([0,0.4,-0.085],[0.15,0.085,0.05],0.04,5), E_([0,0.505,-0.03],[0.13,0.055,0.07],0.04,7)];
  for(const s of [-1,1]){ tor.push(E_([0.088*s,0.4,0.076],[0.104,0.072,0.062],0.014,1), E_([0.08*s,0.448,0.068],[0.085,0.036,0.046],0.016,1), E_([0.122*s,0.19,0.03],[0.042,0.085,0.065],0.03,3),
    E_([0.146*s,0.34,-0.035],[0.074,0.14,0.075],0.035,4), E_([0.036*s,0.16,-0.085],[0.03,0.1,0.03],0.02,6),
    E_([0.075*s,0.498,-0.03],[0.075,0.034,0.052],0.03,7), E_([0.058*s,0.33,-0.09],[0.05,0.07,0.03],0.02,5), E_([0.1*s,0.4,-0.092],[0.055,0.048,0.032],0.014,5));
    for(const y of [0.262,0.3,0.338]) tor.push(E_([0.138*s,y,0.045],[0.022,0.013,0.024],0.009,3));
    tor.push(E_([0.105*s,0.115,0.055],[0.03,0.06,0.04],0.02,3));
    for(const y of [0.115,0.192,0.268]) tor.push(E_([0.036*s,y,0.095],[0.032,0.033,0.021],0.009,2)); }
  tor.push({t:'e',c:[0,0.19,0.122],r:[0.0045,0.13,0.012],k:0.008,neg:1});
  const mTorso=buildMesh(tor,[-0.27,-0.14,-0.17],[0.27,0.57,0.17],0.0081,p=>[sstep(0.105,0.075,p[1]),0,0,0]);
  // Oberarm (Ursprung Schulter, y Richtung Ellbogen, z vorne)
  const U=LN.ua, arm=[RC([0,0,0],[0,U,0],0.056,0.044,0.02), E_([0,0.016,-0.005],[0.082,0.088,0.08],0.03,9), E_([0,0.04,0.036],[0.052,0.075,0.042],0.018,9), E_([0,0.04,-0.042],[0.05,0.072,0.04],0.018,9),
    E_([0,0.52*U,0.032],[0.05,0.31*U,0.052],0.02,10), E_([0,0.62*U,0.048],[0.04,0.15*U,0.038],0.014,10),
    E_([0,0.42*U,-0.036],[0.053,0.35*U,0.05],0.02,11), E_([0.02,0.36*U,-0.05],[0.034,0.19*U,0.032],0.013,11), E_([-0.016,0.5*U,-0.054],[0.034,0.2*U,0.03],0.013,11), E_([0,U,0],[0.042,0.042,0.042],0.02)];
  const mUA=buildMesh(arm,[-0.1,-0.08,-0.1],[0.1,U+0.05,0.1],0.0062);
  const A=LN.fa, fa=[RC([0,0,0],[0,A,0],0.044,0.03,0.02), E_([0,0.27*A,0.005],[0.054,0.3*A,0.05],0.022,12), E_([0.018,0.17*A,0.022],[0.036,0.2*A,0.036],0.015,12),
    E_([0,A+0.038,0.006],[0.036,0.048,0.044],0.014), E_([0,A+0.074,0.018],[0.034,0.013,0.03],0.01), E_([0.031,A+0.022,0.03],[0.013,0.028,0.013],0.01)];
  const mFA=buildMesh(fa,[-0.08,-0.05,-0.08],[0.08,A+0.1,0.08],0.0058);
  const Tl=LN.th, th=[RC([0,0,0],[0,Tl,0],0.088,0.058,0.02), E_([0,0.46*Tl,0.044],[0.082,0.38*Tl,0.065],0.024,13), E_([0.03,0.42*Tl,0.03],[0.058,0.33*Tl,0.05],0.018,13), E_([-0.03,0.8*Tl,0.042],[0.04,0.11*Tl,0.036],0.013,13),
    E_([0,0.5*Tl,-0.045],[0.07,0.36*Tl,0.055],0.024,14), E_([0,Tl,0.012],[0.056,0.056,0.056],0.025)];
  const mTH=buildMesh(th,[-0.13,-0.1,-0.13],[0.13,Tl+0.07,0.13],0.0071,p=>[sstep(0.4*Tl,0.33*Tl,p[1]),0,0,0]);
  const Sl=LN.sh, sh=[RC([0,0,0],[0,Sl,0],0.055,0.034,0.02), E_([0,0.3*Sl,-0.037],[0.057,0.26*Sl,0.054],0.025,15), E_([0.021,0.25*Sl,-0.05],[0.033,0.17*Sl,0.036],0.013,15), E_([-0.021,0.27*Sl,-0.05],[0.033,0.17*Sl,0.036],0.013,15), E_([0,0.3*Sl,0.03],[0.03,0.25*Sl,0.03],0.02)];
  const mSH=buildMesh(sh,[-0.1,-0.07,-0.1],[0.1,Sl+0.05,0.1],0.0063);
  MESHES.m=MESH={head:mHead,torso:mTorso,ua:mUA,fa:mFA,th:mTH,sh:mSH,hair:{},g:'m'};
  console.log('Körper-Meshes in',Math.round(performance.now()-t0),'ms');
}

/* ---------- Frauen-Figur ---------- */
function headRegionsW(p){ const [x,y,z]=p; let lip=0,hair=0;
  const ly=(y+0.047)/0.0115, lx=x/0.021; if(z>0.07&&lx*lx+ly*ly<1) lip=1-sstep(0.55,1,Math.sqrt(lx*lx+ly*ly));
  for(const s of [-1,1]){ // schmal geschwungene Brauen + Lidstrich
    const bx=(x-0.031*s)/0.019, by=(y-0.034-0.004*(1-bx*bx))/0.0033; if(z>0.06){ const d=bx*bx+by*by; if(d<1) hair=Math.max(hair,1-sstep(0.4,1,d)); }
    const ex=(x-0.031*s)/0.014, ey=(y-0.0205)/0.0022; if(z>0.07){ const d=ex*ex+ey*ey; if(d<1) hair=Math.max(hair,0.9*(1-sstep(0.4,1,d))); } }
  const top=sstep(0.02,0.05,y)*(1-sstep(0.06,0.085,z)), back=sstep(-0.01,-0.05,z)*sstep(-0.05,-0.01,y);
  hair=Math.max(hair,Math.max(top,back)*0.85);
  return [0,0,lip,hair]; }
function buildMeshesW(){
  const t0=performance.now();
  const head=[E_([0,0.012,-0.006],[0.071,0.093,0.087]), E_([0.036,-0.012,0.044],[0.03,0.03,0.034],0.022), E_([-0.036,-0.012,0.044],[0.03,0.03,0.034],0.022),
    E_([0,-0.052,0.017],[0.047,0.03,0.05],0.024), E_([0.039,-0.046,-0.006],[0.021,0.027,0.034],0.026), E_([-0.039,-0.046,-0.006],[0.021,0.027,0.034],0.026),
    E_([0,-0.075,0.05],[0.019,0.017,0.02],0.022), E_([0,0.03,0.07],[0.05,0.009,0.015],0.02),
    RC([0,0.02,0.081],[0,-0.013,0.094],0.0068,0.0092,0.012), E_([0.009,-0.017,0.088],[0.0072,0.0065,0.007],0.006), E_([-0.009,-0.017,0.088],[0.0072,0.0065,0.007],0.006),
    E_([0,-0.041,0.083],[0.018,0.0055,0.01],0.006), E_([0,-0.051,0.081],[0.017,0.0075,0.011],0.006),
    E_([0.073,0.0,-0.008],[0.01,0.022,0.014],0.008), E_([-0.073,0.0,-0.008],[0.01,0.022,0.014],0.008),
    RC([0,-0.05,-0.02],[0,-0.19,-0.022],0.041,0.047,0.03,16),
    {t:'e',c:[0.031,0.015,0.086],r:[0.017,0.012,0.012],k:0.008,neg:1},{t:'e',c:[-0.031,0.015,0.086],r:[0.017,0.012,0.012],k:0.008,neg:1}];
  const mHead=buildMesh(head,[-0.1,-0.2,-0.11],[0.1,0.12,0.12],0.0046,headRegionsW);
  const tor=[E_([0,0.03,0],[0.175,0.12,0.118]), E_([0.072,-0.01,-0.075],[0.095,0.1,0.088],0.03,8), E_([-0.072,-0.01,-0.075],[0.095,0.1,0.088],0.03,8),
    E_([0,0.17,0],[0.112,0.11,0.088],0.05), E_([0,0.31,0],[0.135,0.14,0.105],0.05), E_([0,0.42,-0.005],[0.165,0.1,0.1],0.05), E_([0,0.48,-0.02],[0.175,0.055,0.085],0.04),
    E_([0,0.39,-0.075],[0.12,0.08,0.04],0.04,5), E_([0,0.5,-0.03],[0.1,0.045,0.06],0.04,7)];
  for(const s of [-1,1]){ tor.push(E_([0.058*s,0.385,0.074],[0.066,0.062,0.06],0.022,1), E_([0.105*s,0.19,0.025],[0.032,0.07,0.05],0.03,3),
    E_([0.115*s,0.33,-0.03],[0.05,0.12,0.06],0.04,4), E_([0.03*s,0.16,-0.075],[0.024,0.09,0.024],0.02,6));
    for(const y of [0.14,0.22]) tor.push(E_([0.03*s,y,0.083],[0.026,0.03,0.016],0.014,2)); }
  const clothT=p=>{ const bottom=sstep(0.11,0.085,p[1]), top=sstep(0.325,0.345,p[1])*(1-sstep(0.455,0.475,p[1])); return [Math.max(bottom,top),0,0,0]; };
  const mTorso=buildMesh(tor,[-0.25,-0.14,-0.17],[0.25,0.56,0.17],0.0085,clothT);
  const U=LN.ua, arm=[RC([0,0,0],[0,U,0],0.045,0.036,0.02), E_([0,0.016,-0.005],[0.062,0.07,0.062],0.03,9), E_([0,0.52*U,0.026],[0.038,0.28*U,0.04],0.025,10),
    E_([0,0.42*U,-0.03],[0.042,0.32*U,0.04],0.025,11), E_([0,U,0],[0.034,0.034,0.034],0.02)];
  const mUA=buildMesh(arm,[-0.09,-0.07,-0.09],[0.09,U+0.05,0.09],0.0062);
  const A=LN.fa, fa=[RC([0,0,0],[0,A,0],0.036,0.025,0.02), E_([0,0.27*A,0.004],[0.042,0.28*A,0.038],0.025,12),
    E_([0,A+0.032,0.004],[0.033,0.044,0.04],0.02), E_([0.025,A+0.012,0.026],[0.011,0.026,0.011],0.012)];
  const mFA=buildMesh(fa,[-0.07,-0.05,-0.07],[0.07,A+0.09,0.07],0.0055);
  const Tl=LN.th, th=[RC([0,0,0],[0,Tl,0],0.088,0.05,0.02), E_([0,0.46*Tl,0.04],[0.072,0.38*Tl,0.058],0.03,13), E_([0,0.45*Tl,-0.042],[0.07,0.38*Tl,0.054],0.03,14),
    E_([0.035,0.2*Tl,-0.01],[0.05,0.2*Tl,0.06],0.03), E_([0,Tl,0.01],[0.047,0.047,0.047],0.025)];
  const mTH=buildMesh(th,[-0.13,-0.1,-0.13],[0.13,Tl+0.06,0.13],0.0072,p=>[LOOK.legs==='leggings'?1:sstep(0.3*Tl,0.24*Tl,p[1]),0,0,0]);
  const Sl=LN.sh, sh=[RC([0,0,0],[0,Sl,0],0.048,0.029,0.02), E_([0,0.3*Sl,-0.033],[0.048,0.25*Sl,0.046],0.03,15)];
  const mSH=buildMesh(sh,[-0.09,-0.07,-0.09],[0.09,Sl+0.05,0.09],0.006,p=>[LOOK.legs==='leggings'?(1-sstep(0.86*Sl,0.9*Sl,p[1])):0,0,0,0]);
  console.log('Frauen-Meshes in',Math.round(performance.now()-t0),'ms');
  return {head:mHead,torso:mTorso,ua:mUA,fa:mFA,th:mTH,sh:mSH,hair:{},g:'w'};
}
function hairPartsW(style){
  const cap=[E_([0,0.035,-0.012],[0.08,0.083,0.095]), {t:'e',c:[0,-0.03,0.075],r:[0.068,0.072,0.06],k:0.012,neg:1}, {t:'e',c:[0,-0.095,-0.02],r:[0.1,0.05,0.13],k:0.01,neg:1}];
  const face={t:'e',c:[0,-0.04,0.08],r:[0.066,0.1,0.065],k:0.012,neg:1};
  if(style==='ponytail') return [...cap, E_([0,0.04,-0.098],[0.022,0.022,0.022],0.01), RC([0,0.035,-0.105],[0,-0.07,-0.135],0.028,0.02,0.015), RC([0,-0.07,-0.135],[0,-0.16,-0.115],0.02,0.007,0.015)];
  if(style==='long') return [E_([0,0.035,-0.012],[0.082,0.085,0.096]), E_([0,-0.08,-0.06],[0.088,0.14,0.05],0.04), E_([0.07,-0.06,-0.005],[0.022,0.11,0.045],0.03), E_([-0.07,-0.06,-0.005],[0.022,0.11,0.045],0.03),
    face, {t:'e',c:[0,-0.25,0],r:[0.2,0.05,0.2],k:0.01,neg:1}];
  if(style==='bob') return [E_([0,0.03,-0.012],[0.084,0.088,0.098]), E_([0,-0.025,-0.015],[0.09,0.06,0.098],0.03), face, {t:'e',c:[0,-0.13,0],r:[0.2,0.05,0.2],k:0.01,neg:1}];
  if(style==='bun') return [...cap, E_([0,0.1,-0.045],[0.036,0.034,0.036],0.015)];
  if(style==='braid'){ const p=[...cap]; [[0,0.0,-0.098,0.024],[0,-0.038,-0.108,0.022],[0,-0.075,-0.11,0.02],[0,-0.11,-0.106,0.018],[0,-0.145,-0.1,0.015],[0,-0.175,-0.094,0.012]].forEach(([x,y,z,r])=>p.push(E_([x,y,z],[r,r*1.15,r],0.008))); return p; }
  if(style==='pixie') return [E_([0,0.04,-0.008],[0.081,0.08,0.097]), {t:'e',c:[0,-0.03,0.08],r:[0.068,0.07,0.058],k:0.012,neg:1}, {t:'e',c:[0,-0.08,-0.02],r:[0.1,0.05,0.13],k:0.01,neg:1}, E_([0.025,0.062,0.072],[0.05,0.02,0.03],0.02)];
  return null; }

function hairMesh(style){ if(MESH.hair[style]!==undefined) return MESH.hair[style]; let parts=null;
  if(MESH.g==='w'){ parts=hairPartsW(style); MESH.hair[style]=parts?buildMesh(parts,[-0.13,-0.27,-0.17],[0.13,0.16,0.13],0.005):null; return MESH.hair[style]; }
  if(style==='quiff') parts=[E_([0,0.07,0.0],[0.078,0.042,0.088]),E_([0,0.088,0.05],[0.056,0.034,0.04],0.03),E_([0,0.06,-0.04],[0.074,0.045,0.06],0.03)];
  if(style==='slick') parts=[E_([0,0.07,-0.012],[0.08,0.045,0.094]),E_([0,0.08,0.04],[0.062,0.028,0.048],0.03)];
  if(style==='curly'){ parts=[E_([0,0.06,-0.01],[0.08,0.055,0.09])]; for(const [x,y,z] of [[0,0.09,0.03],[0.04,0.085,0.01],[-0.04,0.085,0.01],[0.02,0.095,-0.03],[-0.025,0.09,-0.035],[0,0.085,0.06],[0.045,0.075,0.045],[-0.045,0.075,0.045],[0.06,0.06,-0.03],[-0.06,0.06,-0.03]]) parts.push(E_([x,y,z],[0.032,0.028,0.032],0.012)); }
  if(style==='man-bun') parts=[E_([0,0.04,-0.012],[0.081,0.078,0.095]),E_([0,0.095,-0.075],[0.03,0.028,0.03],0.015)];
  if(style==='cap'){ parts=[E_([0,0.05,-0.008],[0.088,0.07,0.099]),{t:'e',c:[0,-0.035,0],r:[0.2,0.06,0.2],k:0.006,neg:1},E_([0,0.03,0.105],[0.072,0.008,0.055],0.012),E_([0,0.122,-0.01],[0.012,0.006,0.012],0.004)];
    MESH.hair[style]=buildMesh(parts,[-0.12,0.0,-0.13],[0.12,0.15,0.18],0.005); return MESH.hair[style]; }
  MESH.hair[style]=parts?buildMesh(parts,[-0.12,-0.05,-0.13],[0.12,0.14,0.13],0.005):null; return MESH.hair[style]; }

function body(J){
  const G=LOOK.g==='w'?'w':'m'; if(!MESHES[G]){ if(G==='w') MESHES.w=buildMeshesW(); else buildMeshes(); } MESH=MESHES[G];
  const out=[], up=nrm(sub(J.S,J.H)); let f=sub(J.f,mul(up,dot(J.f,up))); if(len(f)<0.1) f=[0,1,0]; f=nrm(f); const x=crs(up,f), Lt=len(sub(J.S,J.H));
  const skin={c:SKIN,sp:0.34,sh:34};
  out.push(part(MESH.torso,J.H,x,up,f,[1,Lt/0.5,1],[0,0,0],skin));
  // Kopf
  const hd=J.hd||add(J.S,mul(up,0.2)), hu=nrm(sub(hd,J.S)), Hf=frame(add(hd,mul(hu,-0.1)),add(hd,mul(hu,0.1)),f);
  out.push(part(MESH.head,hd,Hf.x,Hf.y,Hf.z,[1,1,1],[0,0,0],skin));
  const hm=hairMesh(LOOK.hair); if(hm) out.push(part(hm,hd,Hf.x,Hf.y,Hf.z,[1,1,1],[0,0,0],{c:HAIR,sp:LOOK.hair==='slick'?0.7:0.3,sh:LOOK.hair==='slick'?60:24}));
  for(const sx of [-1,1]){ out.push(part('s',hd,Hf.x,Hf.y,Hf.z,G==='w'?[0.011,0.0068,0.005]:[0.0105,0.0062,0.005],[0.031*sx,G==='w'?0.015:0.0135,G==='w'?0.08:0.0815],{c:[0.86,0.83,0.8],sp:0.6,sh:70}));
    out.push(part('s',hd,Hf.x,Hf.y,Hf.z,[0.0056,0.0056,0.0025],[0.031*sx,G==='w'?0.015:0.0135,G==='w'?0.0845:0.0858],{c:[0.1,0.06,0.035],sp:1.0,sh:120})); }
  // Arme
  for(const sd of ['L','R']){ const Sh=J['sh'+sd],El=J['el'+sd],Ha=J['ha'+sd]; if(!Sh||!El||!Ha) continue;
    const Fu=frame(Sh,El,f),Fa=frame(El,Ha,f);
    out.push(part(MESH.ua,Sh,Fu.x,Fu.y,Fu.z,[1,Fu.L/LN.ua,1],[0,0,0],skin));
    out.push(part(MESH.fa,El,Fa.x,Fa.y,Fa.z,[1,Fa.L/LN.fa,1],[0,0,0],skin)); }
  // Beine
  for(const sd of ['L','R']){ const Hp=J['hp'+sd],Kn=J['kn'+sd],Ft=J['ft'+sd],To=J['to'+sd]; if(!Hp||!Kn||!Ft) continue;
    const Ft_=frame(Hp,Kn,f),Fs=frame(Kn,Ft,f);
    out.push(part(MESH.th,Hp,Ft_.x,Ft_.y,Ft_.z,[1,Ft_.L/LN.th,1],[0,0,0],skin));
    out.push(part(MESH.sh,Kn,Fs.x,Fs.y,Fs.z,[1,Fs.L/LN.sh,1],[0,0,0],skin));
    const toe=To||add(Ft,mul(f,0.15));
    const Fo=frame(add(Ft,mul(nrm(sub(toe,Ft)),-0.05)),add(toe,mul(nrm(sub(toe,Ft)),0.03)),[0,1,0]);
    out.push(part('s',Fo.a,Fo.x,Fo.y,Fo.z,[0.05,Fo.L/2,0.045],[0,Fo.L/2,0.005],{c:SHOE,sp:0.35,sh:40}));
    out.push(part('b',Fo.a,Fo.x,Fo.y,Fo.z,[0.1,Fo.L*0.98,0.02],[0,Fo.L/2,-0.035],{c:SOLE,sp:0.1})); }
  return out;
}

/* ---------- Geräte ---------- */
const COLOR={'#3b4249':FRAME,'#3a4146':FRAME,'#8a949b':STEEL};
function parseStatics(str){
  const out=[]; if(!str) return out;
  str.replace(/<rect([^>]*)>/g,(m,a)=>{const g=k=>{const r=a.match(new RegExp(' '+k+'="([^"]+)"'));return r?r[1]:null;};out.push({t:'r',x:+g('x'),y:+g('y'),w:+g('width'),h:+g('height'),c:g('fill')});});
  str.replace(/<path([^>]*)>/g,(m,a)=>{const d=(a.match(/ d="([^"]+)"/)||[])[1],c=(a.match(/stroke="([^"]+)"/)||[])[1],w=+((a.match(/stroke-width="([^"]+)"/)||[])[1]||4);
    if(!d) return; let pts=[],cx=0,cy=0;const tok=d.match(/[MLHV]|-?\d+(\.\d+)?/g);let cmd='M';
    for(let i=0;i<tok.length;){const t=tok[i];if(/[MLHV]/.test(t)){cmd=t;i++;continue;}
      if(cmd==='M'){ if(pts.length>1) out.push({t:'p',pts,c,w}); cx=+tok[i];cy=+tok[i+1];i+=2;pts=[[cx,cy]];cmd='L';}
      else if(cmd==='L'){cx=+tok[i];cy=+tok[i+1];i+=2;pts.push([cx,cy]);} else if(cmd==='H'){cx=+tok[i];i++;pts.push([cx,cy]);} else {cy=+tok[i];i++;pts.push([cx,cy]);}}
    if(pts.length>1) out.push({t:'p',pts,c,w});});
  return out;
}
function equipment(tp,ex,JA){
  const items=[], v=tp.view, Yp=y=>(184-y)*K, side=v==='s';
  const ez=tp.eqZ||0, P3=(x,y,lat=0)=>side?[lat,Yp(y),(x-100)*K]:[(x-100)*K,Yp(y),lat+ez];
  const handZ=side?(JA.haR?JA.haR[2]:0):0;
  for(const o of parseStatics(tp.statics)){
    const col=COLOR[o.c]||FRAME;
    if(o.t==='r'){ const tall=o.h>o.w*3, lat=side?(tall?0.16:0.42):0.42;
      const c=P3(o.x+o.w/2,o.y+o.h/2), sz=side?[lat,o.h*K,o.w*K]:[o.w*K,o.h*K,lat];
      items.push(part('b',c,[1,0,0],[0,1,0],[0,0,1],sz,[0,0,0],{c:o.h<=10&&!tall?PAD:col,sp:0.2,sh:20}));
      continue; }
    const isBar=o.c==='#8a949b', hor=o.pts.length===2&&Math.abs(o.pts[0][1]-o.pts[1][1])<1;
    if(isBar&&hor&&o.pts[0][1]<45){ // Klimmzugstange
      const y=Yp(o.pts[0][1]); items.push(rod([-0.8,y,handZ],[0.8,y,handZ],0.018,STEEL,0.8));
      const pz=handZ-0.38; for(const sx of [-0.8,0.8]){ items.push(rod([sx,0,pz],[sx,y+0.06,pz],0.04,FRAME)); items.push(rod([sx,y,handZ],[sx,y,pz],0.03,FRAME)); }
      continue; }
    for(let i=0;i<o.pts.length-1;i++){ const [a,b]=[o.pts[i],o.pts[i+1]];
      if(o.w>=7){ const A=P3(a[0],a[1]),B=P3(b[0],b[1]); items.push(slab(A,B,side?0.42:0.42,o.w*K,PAD,side?[1,0,0]:[0,0,1])); continue; }
      const vert=Math.abs(a[0]-b[0])<2;
      const lats=side&&(vert||isBar)?[-0.22,0.22]:[0];
      for(const l of lats) items.push(rod(P3(a[0],a[1],isBar?l*1.2:l),P3(b[0],b[1],isBar?l*1.2:l),o.w*K*0.6,isBar?STEEL:col,isBar?0.8:0.4));
    }
  }
  return items;
}
function handProps(tp,ex,J,p){
  const it=[], side=tp.view==='s', lat=side?[1,0,0]:[1,0,0];
  const hL=J.haL,hR=J.haR; if(!hL||!hR) return it;
  const cen=tp.barAt&&p[tp.barAt]?(side?[0,(184-p[tp.barAt][1])*K,(p[tp.barAt][0]-100)*K]:mix(hL,hR,.5)):mix(hL,hR,.5);
  const Y=y=>(184-y)*K, AP=a=>side?[0,Y(a[1]),(a[0]-100)*K]:[(a[0]-100)*K,Y(a[1]),tp.eqZ||0];
  if(ex.prop==='bar'){
    const a=add(cen,[-0.85,0,0]),b=add(cen,[0.85,0,0]); it.push(rod(a,b,0.014,STEEL,0.9));
    for(const sx of [-1,1]){ const c=add(cen,[0.62*sx,0,0]); it.push(rod(add(c,[-0.035,0,0]),add(c,[0.035,0,0]),0.2,PLATE,0.5)); it.push(rod(add(c,[0.04*sx,0,0]),add(c,[0.07*sx,0,0]),0.03,STEEL,0.8)); }
  } else if(ex.prop==='db'){
    for(const h of (tp.oneHand?[hR]:[hL,hR])){ const ax=side?[1,0,0]:[0,0,1]; const a=add(h,mul(ax,-0.1)),b=add(h,mul(ax,0.1)); it.push(rod(a,b,0.014,STEEL,0.9));
      for(const e of [a,b]) it.push(rod(add(e,mul(ax,-0.03)),add(e,mul(ax,0.03)),0.058,PLATE,0.5)); }
  } else if(ex.prop==='handle'){
    if(tp.cableMid){ it.push(rod(add(hL,[-0.12,0,0]),add(hR,[0.12,0,0]),0.016,STEEL,0.9)); }
    else for(const h of [hL,hR]) it.push(rod(add(h,[-0.07,0,0]),add(h,[0.07,0,0]),0.02,PAD,0.3));
  }
  // Seilzüge
  if(tp.cable&&ex.prop==='rope'){ const A=AP(tp.cable), m=mix(hL,hR,.5), j=add(m,mul(nrm(sub(A,m)),0.1));
    it.push(rod(A,j,0.005,CABLE,0.6)); it.push(ball(A,0.05,{c:STEEL,sp:0.8,sh:60})); it.push(ball(j,0.02,{c:STEEL,sp:0.8}));
    for(const h of [hL,hR]){ const dir=nrm(sub(h,j)); it.push(rod(j,add(h,mul(dir,0.035)),0.012,[0.08,0.08,0.09],0.2)); it.push(ball(add(h,mul(dir,0.045)),0.026,{c:[0.08,0.08,0.09],sp:0.2})); } }
  else if(tp.cable){ const A=AP(tp.cable),c=mix(hL,hR,.5); it.push(rod(A,c,0.005,CABLE,0.6)); it.push(ball(A,0.05,{c:STEEL,sp:0.8,sh:60})); }
  if(tp.cables){ const ps=tp.cables.map(AP).sort((a,b)=>a[0]-b[0]), hs=[hL,hR].sort((a,b)=>a[0]-b[0]); ps.forEach((A,i)=>{it.push(rod(A,hs[i],0.005,CABLE,0.6));it.push(ball(A,0.045,{c:STEEL,sp:0.8}));}); }
  if(tp.cableMid){ const A=AP(tp.cableMid); it.push(rod(A,mix(hL,hR,.5),0.005,CABLE,0.6)); }
  if(tp.cableFoot&&J.ftL){ const A=AP(tp.cableFoot); it.push(rod(A,J.ftL,0.005,CABLE,0.6)); it.push(ball(A,0.045,{c:STEEL,sp:0.8})); }
  if(tp.backPad&&J.S&&J.H){ const d=sub(J.S,J.H), n=nrm([0,d[2],-d[1]]), c=add(add(J.H,mul(d,0.78)),mul(n,0.14)); it.push(rod(add(c,[-0.2,0,0]),add(c,[0.2,0,0]),0.06,PAD,0.3)); it.push(rod(add(c,mul(n,0.05)),add(J.H,mul(n,0.2)),0.025,FRAME,0.4)); }
  if(tp.pad){ const kn=J.knR,ft=J.ftR; if(kn&&ft){ const F=frame(kn,ft,J.f); const c=add(add(kn,mul(F.y,F.L*0.85)),mul(F.z,(ex.anim==='legcurl'||ex.anim==='legCurlLy')?-0.08:0.08)); it.push(rod(add(c,[-0.2,0,0]),add(c,[0.2,0,0]),0.05,PAD,0.3)); } }
  return it;
}

/* ---------- Szene & Kamera ---------- */
let NOFL=false;
function scene(ex,ph){
  const tp=T[ex.anim], p=poseAt(tp,ph), J=joints(tp,ex,p);
  HOT=hlOf(ex); HOT2=secOf(ex);
  const items=body(J).concat(handProps(tp,ex,J,p));
  if(!scene.cache||scene.cache.id!==ex.id){ const JA=joints(tp,ex,poseAt(tp,0)); scene.cache={id:ex.id,eq:equipment(tp,ex,JA),fit:fit(tp,ex)}; }
  const sh=[];for(const k of ['ftL','ftR']) if(J[k]) sh.push([J[k][0],J[k][2],0.16,Math.max(0,1-J[k][1]*3)]);
  sh.push([J.H[0],J.H[2],0.35,Math.max(0,0.8-J.H[1]*0.7)]);
  return {items:(ex.noeq?[]:scene.cache.eq).concat(items),fit:scene.cache.fit,shadows:sh,view:tp.view,J};
}
function fit(tp,ex){ const pts=[]; for(const ph of [0,1]){ const J=joints(tp,ex,poseAt(tp,ph)); for(const k in J) if(Array.isArray(J[k])&&J[k].length===3&&k!=='f') pts.push(J[k]); }
  let mn=[9,9,9],mx=[-9,-9,-9]; for(const q of pts) for(let i=0;i<3;i++){mn[i]=Math.min(mn[i],q[i]);mx[i]=Math.max(mx[i],q[i]);}
  mn[1]=Math.min(mn[1],0); const c=mix(mn,mx,.5), r=Math.max(0.55,len(sub(mx,mn))/2+0.12); return {c,r}; }
function camFor(view,az,el,fitv,zoom,aspect){
  const fov=36*Math.PI/180, d=fitv.r/Math.sin(fov/2)*(aspect<1?1.08/aspect*0.9:1.0)*zoom, a=az*Math.PI/180, e=el*Math.PI/180;
  const t=fitv.c; return {fov,target:t,eye:[t[0]+d*Math.cos(e)*Math.sin(a),t[1]+d*Math.sin(e),t[2]+d*Math.cos(e)*Math.cos(a)]}; }
const DEF_AZ={s:62,f:22,b:22};

/* ---------- Haupt-Ansicht (Detail & Training) ---------- */
let eng=null, ok=null, st={az:62,el:12,zoom:1,auto:false,ex:null,view:'s',drag:null,pins:{}};
function init(){ if(ok!==null) return ok; if(!MC.pro){ ok=false; return ok; } try{ const c=document.createElement('canvas'); c.className='g3d'; eng=Engine(c); ok=true; controls(c); }catch(e){ console.warn('3D nicht verfügbar',e); ok=false; } return ok; }
function controls(c){
  c.addEventListener('pointerdown',e=>{c.setPointerCapture(e.pointerId);st.pins[e.pointerId]=[e.clientX,e.clientY];st.auto=false;st.cam=null;updBtns();});
  c.addEventListener('pointermove',e=>{const pv=st.pins[e.pointerId];if(!pv)return;const ids=Object.keys(st.pins);
    if(ids.length===1){st.az-=(e.clientX-pv[0])*0.5;st.el=Math.max(-8,Math.min(75,st.el+(e.clientY-pv[1])*0.35));}
    else if(ids.length===2){const o=st.pins[ids.find(i=>+i!==e.pointerId)];const d0=Math.hypot(pv[0]-o[0],pv[1]-o[1]),d1=Math.hypot(e.clientX-o[0],e.clientY-o[1]);if(d0>0)st.zoom=Math.max(0.45,Math.min(1.8,st.zoom*d0/d1));}
    st.pins[e.pointerId]=[e.clientX,e.clientY]; window.mlRedraw&&window.mlRedraw();});
  const up=e=>{delete st.pins[e.pointerId];}; c.addEventListener('pointerup',up); c.addEventListener('pointercancel',up);
  c.addEventListener('wheel',e=>{e.preventDefault();st.zoom=Math.max(0.45,Math.min(1.8,st.zoom*(e.deltaY>0?1.08:0.93))); window.mlRedraw&&window.mlRedraw();},{passive:false});
  c.addEventListener('dblclick',()=>{st.az=DEF_AZ[st.view];st.el=12;st.zoom=1;});
}
function updBtns(){ document.querySelectorAll('[data-cam]').forEach(b=>b.classList.toggle('on',b.dataset.cam==='auto'?st.auto:b.dataset.cam===st.cam)); }
function camButtons(){ return `<div class="v3btn"><button data-cam="side">Seite</button><button data-cam="front">Vorne</button><button data-cam="back">Hinten</button><button data-cam="auto">🔄 360°</button></div><div class="v3hint">👆 Wischen zum Drehen · 2 Finger zoomen</div>${LOOK.anat?'<div class="v3leg"><span><i style="background:#8f1318"></i>Hauptmuskeln</span><span><i style="background:#e3a59e"></i>Hilfsmuskeln</span></div>':''}`; }
function bindButtons(root){ root.querySelectorAll('[data-cam]').forEach(b=>b.onclick=()=>{ const k=b.dataset.cam, fz=st.view==='b'?180:0;
  if(k==='auto'){ st.auto=!st.auto; st.cam=st.auto?'auto':null; } else { st.auto=false; st.cam=k; if(k==='oblique'){ st.az=DEF_AZ[st.view]; st.el=14; st.zoom=1; } else { st.az=k==='side'?(st.sideAz||90):k==='front'?fz:fz+180; st.el=10; } } updBtns(); window.mlRedraw&&window.mlRedraw(); }); }
function mount(host,ex){ if(!init()) return false; const c=eng.canvas; if(c.parentNode!==host){ host.innerHTML=''; host.appendChild(c); }
  if(st.ex!==ex.id){ st.ex=ex.id; st.view=T[ex.anim].view; st.az=DEF_AZ[st.view]; st.el=12; st.zoom=1; st.auto=false; st.cam='oblique'; } st.sideAz=T[ex.anim].sideAz||90;
  resize(); return true; }
function resize(){ const c=eng.canvas,r=c.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1),w=Math.round(r.width*dpr),h=Math.round(r.height*dpr); if(w&&h&&(c.width!==w||c.height!==h)){c.width=w;c.height=h;} }
let lastT=performance.now();
let camOv=null;
function draw(ex,ph){ if(!ok) return; resize(); const now=performance.now(), dt=Math.min(0.1,(now-lastT)/1000); lastT=now; if(st.auto) st.az+=dt*30; PULSE=0.5+0.5*Math.sin(now/260);
  const sc=scene(ex,ph), c=eng.canvas, cam=camOv?camOv(sc):camFor(sc.view,st.az,st.el,sc.fit,st.zoom,c.width/c.height); eng.render(sc.items,cam,sc.shadows); callout(ex,sc,cam); }
/* Beschriftung „Brust (Pectoralis major)“ mit Linie zum Hauptmuskel */
const LAT={chest:['Brust','Pectoralis major'],abs:['Bauch','Rectus abdominis'],oblique:['Seitl. Bauch','Obliquus externus'],lat:['Breiter Rücken','Latissimus dorsi'],back:['Oberer Rücken','Rhomboideus'],erector:['Unterer Rücken','Erector spinae'],trap:['Nacken','Trapezius'],glute:['Po','Gluteus maximus'],delt:['Schulter','Deltoideus'],bicep:['Bizeps','Biceps brachii'],tricep:['Trizeps','Triceps brachii'],forearm:['Unterarm','Flexoren & Extensoren'],quad:['Oberschenkel','Quadriceps femoris'],ham:['Beinbeuger','Biceps femoris'],calf:['Wade','Gastrocnemius'],neck:['Hals','Sternocleidomastoideus']};
function muscleAnchor(k,J){ const S=J.S,H=J.H,f=J.f||[0,0,1], m=(a,b,t)=>mix(a,b,t), R_=(a,b)=>J[a]||J[b];
  const shR=R_('shR','shL'), elR=R_('elR','elL'), haR=R_('haR','haL'), hpR=R_('hpR','hpL')||H, knR=R_('knR','knL'), ftR=R_('ftR','ftL');
  switch(k){ case 'chest': return add(m(S,H,0.2),mul(f,0.12)); case 'abs': case 'oblique': return add(m(S,H,0.62),mul(f,0.12)); case 'lat': return add(m(S,H,0.35),mul(f,-0.08));
    case 'back': return add(m(S,H,0.18),mul(f,-0.12)); case 'erector': return add(m(S,H,0.8),mul(f,-0.1)); case 'trap': return add(S,[0,0.05,0]); case 'glute': return add(H,mul(f,-0.12));
    case 'delt': return shR; case 'bicep': case 'tricep': return elR&&shR?m(shR,elR,0.5):S; case 'forearm': return elR&&haR?m(elR,haR,0.5):S;
    case 'quad': return knR?add(m(hpR,knR,0.5),mul(f,0.07)):H; case 'ham': return knR?add(m(hpR,knR,0.5),mul(f,-0.07)):H; case 'calf': return knR&&ftR?m(knR,ftR,0.4):H; case 'neck': return J.hd?m(S,J.hd,0.4):S; }
  return S; }
function callout(ex,sc,cam){ const c=eng.canvas, stg=c.closest('.stage'); if(!stg) return; let el=stg.querySelector('.mlcall');
  const keys=[...HOT]; if(!keys.length||!sc.J||stg.classList.contains('nocall')){ if(el) el.style.display='none'; return; }
  if(!el){ el=document.createElement('div'); el.className='mlcall'; el.innerHTML='<svg><line/><circle r="4"/></svg><span></span>'; el.onclick=()=>stg.classList.add('nocall'); stg.appendChild(el); }
  const PRI=['chest','lat','quad','glute','delt','bicep','tricep','ham','abs','calf','trap','back','erector','oblique','forearm','neck']; const k=PRI.find(x=>HOT.has(x))||keys[0], L=LAT[k]||[k,''], p=muscleAnchor(k,sc.J);
  const eye=cam.eye, z=nrm(sub(eye,cam.target)), x=nrm(crs([0,1,0],z)), y=crs(z,x), d=sub(p,eye), vz=dot(d,z); if(vz>=-0.05){ el.style.display='none'; return; }
  const r=c.getBoundingClientRect(), sr=stg.getBoundingClientRect(), t=1/Math.tan(cam.fov/2), asp=r.width/r.height;
  const px=r.left-sr.left+(1+(t/asp)*dot(d,x)/-vz)/2*r.width, py=r.top-sr.top+(1-t*dot(d,y)/-vz)/2*r.height;
  el.style.display='block'; const sp=el.querySelector('span'); const txt=tr(L[0])+(L[1]?' <i>('+L[1]+')</i>':''); if(sp.dataset.t!==txt){ sp.innerHTML=txt; sp.dataset.t=txt; }
  const lw=sp.offsetWidth||150, right=px<sr.width/2, lx=right?Math.min(sr.width-lw-10,px+60):Math.max(10,px-60-lw), ly=Math.max(52,Math.min(r.bottom-sr.top-40,py-46));
  sp.style.left=lx+'px'; sp.style.top=ly+'px';
  const ln=el.querySelector('line'), ci=el.querySelector('circle'), ax=right?lx:lx+lw, ay=ly+sp.offsetHeight/2;
  ln.setAttribute('x1',ax); ln.setAttribute('y1',ay); ln.setAttribute('x2',px); ln.setAttribute('y2',py); ci.setAttribute('cx',px); ci.setAttribute('cy',py); }

/* ---------- 3D-Vorschaubilder ---------- */
const TH={}; let thBusy=false, thVer=0, thAgain=null;
function thumbs(list,done){ if(!init()) return; if(thBusy){ thAgain=[list,done]; return; } thBusy=true; const myVer=thVer; let e2; try{ const c=document.createElement('canvas'); c.width=300; c.height=300; e2=Engine(c); }catch(err){ thBusy=false; return; }
  const todo=list.filter(x=>!TH[x.id]); let i=0;
  const step=()=>{ if(myVer===thVer&&performance.now()-(window.__mcTouch||0)<700){ setTimeout(step,250); return; } const t0=performance.now(); while(i<todo.length&&performance.now()-t0<12){ const ex=todo[i++]; try{ PULSE=0.6; NOFL=!!ex.noeq; const sc=scene(ex,0.62); e2.render(sc.items,camFor(sc.view,DEF_AZ[sc.view],12,sc.fit,0.92,1),sc.shadows); TH[ex.id]=e2.canvas.toDataURL('image/png'); }catch(err){} NOFL=false; }
    if(myVer!==thVer){ i=todo.length; }
    if(i<todo.length) setTimeout(step,60); else { thBusy=false; scene.cache=null; try{e2.gl.getExtension('WEBGL_lose_context').loseContext();}catch(e){} if(myVer===thVer) done&&done(); if(thAgain){ const a=thAgain; thAgain=null; thumbs(a[0],a[1]); } } };
  step(); }
return {busy:()=>thBusy,anat:()=>!!LOOK.anat,pro:()=>LOOK.skin==='pro',resetThumbs:()=>{thVer++; for(const k in TH) delete TH[k];},setLook,setCam:f=>{camOv=f;},init,mount,draw,camButtons,bindButtons,thumbs,TH,get ok(){return ok;}};
})();

/* ---- Einbindung: Vorschaubilder & Animation ---- */
const _figure2d=figure;
figure=function(ex,ph){ if(ex&&ex.id&&G3.TH[ex.id]) return `<img class="th3d" src="${G3.TH[ex.id]}" alt="" loading="lazy" decoding="async">`; return _figure2d(ex,ph); };
const COACH_LOOKS=[
 ['Classic','Tolle · Vollbart',{hair:'quiff',beard:'full',skin:'tan'}],
 ['Clean Pro','Zurückgegelt · rasiert',{hair:'slick',beard:'none',skin:'light',shorts:[0.03,0.06,0.16]}],
 ['Street','Buzzcut · 3-Tage-Bart',{hair:'buzz',beard:'stubble',skin:'olive',shorts:[0.45,0.03,0.03]}],
 ['Locken','Locken · Kinnbart',{hair:'curly',beard:'goatee',skin:'tan',shorts:[0.22,0.23,0.25]}],
 ['Glatze & Bart','Glatze · Vollbart',{hair:'bald',beard:'full',skin:'dark',hairCol:[0.03,0.02,0.02],shorts:[0.05,0.09,0.06]}],
 ['Man Bun','Haarknoten · Vollbart',{hair:'man-bun',beard:'full',skin:'light',hairCol:[0.22,0.13,0.06]}],
 ['Fitness','Pferdeschwanz · pink',{g:'w',hair:'ponytail',beard:'none',skin:'tan',hairCol:[0.12,0.07,0.04],shorts:[0.75,0.16,0.42]}],
 ['Blond','Lange Haare · Leggings',{g:'w',hair:'long',beard:'none',skin:'light',hairCol:[0.72,0.55,0.3],shorts:[0.2,0.42,0.7],legs:'leggings'}],
 ['Bob','Bob · rot',{g:'w',hair:'bob',beard:'none',skin:'olive',hairCol:[0.03,0.025,0.025],shorts:[0.62,0.05,0.08]}],
 ['Dutt','Dutt · Leggings',{g:'w',hair:'bun',beard:'none',skin:'dark',hairCol:[0.05,0.03,0.02],shorts:[0.45,0.3,0.72],legs:'leggings'}],
 ['Zopf','Rote Haare · grün',{g:'w',hair:'braid',beard:'none',skin:'light',hairCol:[0.45,0.14,0.05],shorts:[0.08,0.42,0.3]}],
 ['Pixie','Kurzhaar · schwarz',{g:'w',hair:'pixie',beard:'none',skin:'tan',hairCol:[0.04,0.03,0.03],shorts:[0.06,0.06,0.07],legs:'leggings'}],
 ['Anatomie','Muskel-Ansicht · Rot = Hauptmuskel',{anat:true}],
 ['Pro Athlet','Cap · Rot leuchtende Muskeln',{hair:'cap',beard:'stubble',skin:'pro',hairCol:[0.035,0.035,0.04],shorts:[0.03,0.03,0.035],hot:[0.98,0.12,0.09]}]];
const DEF_LOOK=13;
function curLookIdx(){ try{ const v=testLocal.getItem('mc_look'); const n=v==null?DEF_LOOK:+v; return COACH_LOOKS[n]?n:DEF_LOOK; }catch(e){ return DEF_LOOK; } }
function applyLook(i,save){ const l=COACH_LOOKS[i]||COACH_LOOKS[0]; G3.setLook(l[2]); if(save){ try{testLocal.setItem('mc_look',String(i))}catch(e){} G3.resetThumbs(); start3DThumbs(); } }
try{ applyLook(curLookIdx(),false); }catch(e){ console.warn('Look',e); }
/* Scrollen/Tippen merken: solange der Finger aktiv ist, pausiert das Zeichnen der Vorschaubilder */
['touchstart','touchmove','scroll','wheel'].forEach(t=>addEventListener(t,()=>{ window.__mcTouch=performance.now(); },{passive:true,capture:true}));
/* Vorschaubilder im Handy speichern (IndexedDB) – dann muss nicht bei jedem Start neu gezeichnet werden */
const TH_DB={ key:()=> 'th|'+curLookIdx()+'|'+(typeof APP_VERSION!=='undefined'?APP_VERSION:''),
  open(){ return new Promise((res,rej)=>{ try{ const r=indexedDB.open(testKey('mc_thumbs'),1); r.onupgradeneeded=()=>r.result.createObjectStore('t'); r.onsuccess=()=>res(r.result); r.onerror=()=>rej(r.error); }catch(e){ rej(e); } }); },
  async load(){ try{ const db=await this.open(); return await new Promise(res=>{ const q=db.transaction('t').objectStore('t').get(this.key()); q.onsuccess=()=>res(q.result||null); q.onerror=()=>res(null); }); }catch(e){ return null; } },
  async save(obj){ try{ const db=await this.open(); const tx=db.transaction('t','readwrite'), st=tx.objectStore('t'); st.clear(); st.put(obj,this.key()); }catch(e){} } };
function swapThumbs(){ /* Bilder direkt austauschen statt die ganze Liste neu aufzubauen */
  document.querySelectorAll('.card[data-id] .fig').forEach(f=>{ const id=f.parentNode.dataset.id, src=G3.TH[id]; if(!src) return; const old=f.querySelector('svg,img.th3d'); if(old&&old.tagName==='IMG'&&old.getAttribute('src')===src) return;
    const im=document.createElement('img'); im.className='th3d'; im.alt=''; im.decoding='async'; im.src=src; if(old) old.replaceWith(im); else f.prepend(im); }); }
async function start3DThumbs(){ if(!MC.pro) return;
  /* erst gespeicherte Vorschaubilder laden – sind alle da, wird die 3D-Engine beim Start gar nicht gebraucht (schneller Start) */
  const key=TH_DB.key(), c=await TH_DB.load();
  if(c&&typeof c==='object'){ for(const k in c) if(!G3.TH[k]) G3.TH[k]=c[k]; try{ swapThumbs(); if(view==='plan') renderPlan(); }catch(e){} }
  if(EX.every(x=>G3.TH[x.id])) return;
  if(!G3.init()) return;
  G3.thumbs(EX,()=>{ try{ swapThumbs(); if(view==='plan') renderPlan(); }catch(e){} if(key===TH_DB.key()){ const o={}; EX.forEach(x=>{ if(G3.TH[x.id]) o[x.id]=G3.TH[x.id]; }); TH_DB.save(o); } }); }

/* =====================================================================
   ERWEITERUNGEN: Fortschritt, Körper & Fotos, Abzeichen, Rechner,
   Erinnerungen, Datensicherung
   ===================================================================== */
let BODY=[]; try{BODY=JSON.parse(testLocal.getItem('mc_body')||'[]')}catch(e){}
const saveBody=()=>{try{testLocal.setItem('mc_body',JSON.stringify(BODY))}catch(e){}};
const numDE=v=>{const n=parseFloat(String(v||'').replace(',','.'));return isFinite(n)?n:NaN;};
const fd1=v=>String(Math.round(v*10)/10).replace('.',',');
const round25=v=>Math.round(v/2.5)*2.5;

/* ---------- Fotos (IndexedDB) ---------- */
function idb(){ return new Promise((res,rej)=>{ try{ const r=indexedDB.open(testKey('mc_photos'),1);
  r.onupgradeneeded=()=>r.result.createObjectStore('p',{keyPath:'id'}); r.onsuccess=()=>res(r.result); r.onerror=()=>rej(r.error);}catch(e){rej(e);} }); }
async function photoAll(){ try{ const db=await idb(); return await new Promise(res=>{ const q=db.transaction('p').objectStore('p').getAll(); q.onsuccess=()=>res((q.result||[]).sort((a,b)=>a.date<b.date?-1:1)); q.onerror=()=>res([]); }); }catch(e){ return []; } }
async function photoPut(o){ const db=await idb(); return new Promise(res=>{ const t=db.transaction('p','readwrite'); t.objectStore('p').put(o); t.oncomplete=()=>res(); t.onerror=()=>res(); }); }
async function photoDel(id){ const db=await idb(); return new Promise(res=>{ const t=db.transaction('p','readwrite'); t.objectStore('p').delete(id); t.oncomplete=()=>res(); }); }
function shrink(file){ return new Promise((res,rej)=>{ const fr=new FileReader(); fr.onerror=rej; fr.onload=()=>{ const im=new Image(); im.onerror=rej; im.onload=()=>{
  const M=800, sc=Math.min(1,M/Math.max(im.width,im.height)), c=document.createElement('canvas'); c.width=Math.round(im.width*sc); c.height=Math.round(im.height*sc);
  c.getContext('2d').drawImage(im,0,0,c.width,c.height); res(c.toDataURL('image/jpeg',0.72)); }; im.src=fr.result; }; fr.readAsDataURL(file); }); }

/* ---------- Statistik-Helfer ---------- */
const monOf=d=>addD(new Date(d.getFullYear(),d.getMonth(),d.getDate()),-wdOf(d));
function weekStreak(){ const wk=new Set(LOG.map(l=>ymd(monOf(parseD(l.date))))); let m=monOf(new Date()), s=0;
  if(!wk.has(ymd(m))) m=addD(m,-7); while(wk.has(ymd(m))){ s++; m=addD(m,-7); } return s; }
function prCount(){ const bk={}, br={}; let n=0;
  for(const l of LOG){ for(const id in (l.sets||{})){ if(id==='laufband') continue; const ss=l.sets[id];
    const k=Math.max(0,...ss.map(x=>kgNum(x.kg))), r=Math.max(0,...ss.filter(x=>kgNum(x.kg)===0).map(x=>parseFloat(x.reps)||0));
    if(k>0){ if(bk[id]!==undefined&&k>bk[id]) n++; bk[id]=Math.max(bk[id]||0,k); }
    if(r>0){ if(br[id]!==undefined&&r>br[id]) n++; br[id]=Math.max(br[id]||0,r); } } }
  return n; }
const totalVol=()=>LOG.reduce((a,l)=>a+(l.vol||0),0);
function bestWeek(){ const c={}; LOG.forEach(l=>{const k=ymd(monOf(parseD(l.date))); c[k]=(c[k]||0)+1;}); return Math.max(0,...Object.values(c)); }

/* ---------- Abzeichen ---------- */
const BADGES=[
 ['first','🎯','Der Anfang','Erstes Training abgeschlossen',s=>s.n>=1],
 ['t5','🥉','Dranbleiber','5 Trainings',s=>s.n>=5],
 ['t10','🥈','Zweistellig','10 Trainings',s=>s.n>=10],
 ['t25','🥇','Gewohnheit','25 Trainings',s=>s.n>=25],
 ['t50','🏅','Maschine','50 Trainings',s=>s.n>=50],
 ['t100','👑','Legende','100 Trainings',s=>s.n>=100],
 ['w2','🔥','Am Ball','2 Wochen am Stück trainiert',s=>s.streak>=2],
 ['w4','⚡','Ein Monat stark','4 Wochen am Stück',s=>s.streak>=4],
 ['w8','💪','Unaufhaltsam','8 Wochen am Stück',s=>s.streak>=8],
 ['w12','💎','Eiserner Wille','12 Wochen am Stück',s=>s.streak>=12],
 ['wk','📅','Wochenziel','Alle geplanten Trainings einer Woche',s=>s.bestWeek>=Math.max(1,SCHED.wd.length)],
 ['v1','🏋️','Erste Tonne','1.000 kg bewegt',s=>s.vol>=1000],
 ['v10','🚚','10 Tonnen','10.000 kg bewegt',s=>s.vol>=10000],
 ['v50','🏗️','50 Tonnen','50.000 kg bewegt',s=>s.vol>=50000],
 ['v100','🚀','100 Tonnen','100.000 kg bewegt',s=>s.vol>=100000],
 ['pr1','🏆','Stärker geworden','Erster persönlicher Rekord',s=>s.pr>=1],
 ['pr10','🏆','Rekordjäger','10 persönliche Rekorde',s=>s.pr>=10],
 ['pr25','🌟','Kraftpaket','25 persönliche Rekorde',s=>s.pr>=25],
 ['early','🌅','Frühaufsteher','Training vor 8 Uhr beendet',s=>s.early],
 ['body','⚖️','Körper im Blick','4× Gewicht eingetragen',s=>s.body>=4],
 ['bak','💾','Gut gesichert','Erstes Backup erstellt',s=>s.bak]
];
function badgeStats(){ return {n:LOG.length,streak:weekStreak(),bestWeek:bestWeek(),vol:totalVol(),pr:prCount(),
  early:LOG.some(l=>l.ts&&new Date(l.ts).getHours()<8), body:BODY.length, bak:!!testLocal.getItem('mc_bak')}; }
function unlockedBadges(){ const s=badgeStats(); return BADGES.filter(b=>b[4](s)).map(b=>b[0]); }
let BSEEN=null; try{BSEEN=JSON.parse(testLocal.getItem('mc_badges')||'null')}catch(e){}
if(!BSEEN){ BSEEN=unlockedBadges(); try{testLocal.setItem('mc_badges',JSON.stringify(BSEEN))}catch(e){} }
function checkBadges(container){ const now=unlockedBadges(), neu=now.filter(id=>!BSEEN.includes(id)); if(!neu.length) return [];
  BSEEN=now; try{testLocal.setItem('mc_badges',JSON.stringify(BSEEN))}catch(e){}
  const list=neu.map(id=>BADGES.find(b=>b[0]===id));
  if(container){ const d=document.createElement('div'); d.className='newbadges'; d.innerHTML=`<h4>🎖 Neues Abzeichen!</h4>${list.map(b=>`<div><span>${b[1]}</span><b>${b[2]}</b><small>${b[3]}</small></div>`).join('')}`; container.appendChild(d); }
  else toast2(`🎖 Neues Abzeichen: ${list[0][2]}`);
  return list; }
/* Training beenden → neue Abzeichen zeigen */
const _finishLive=finishLive;
finishLive=function(){ _finishLive(); const rb=$('restBar'); if(rb) rb.classList.remove('on'); const box=document.querySelector('#tbody .sum2'); const nb=checkBadges(box); if(box&&nb.length){ const pr=box.querySelector('.prs'); if(!pr) box.querySelector('div').textContent='🎖'; } };

/* ---------- Rechner ---------- */
const PLATES=[25,20,15,10,5,2.5,1.25];
function platesFor(total,bar){ let side=(total-bar)/2; if(side<0) return null; const out=[];
  for(const p of PLATES){ while(side>=p-1e-9){ out.push(p); side=Math.round((side-p)*100)/100; } } return {out,rest:side}; }
const platesTxt=r=>r.out.length?r.out.map(p=>String(p).replace('.',',')).join(' + '):'keine Scheiben';
const e1rmCalc=(kg,r)=>r<=1?kg:kg*(1+r/30);

/* ---------- Fortschritt-Ansicht ---------- */
function barChart(vals,labels,color,unit){ const W=320,H=130,pad=18,n=vals.length,max=Math.max(1,...vals),bw=(W-pad*2)/n;
  return `<svg viewBox="0 0 ${W} ${H+18}" class="pchart">${vals.map((v,i)=>{const h=Math.max(v?3:0,(H-pad)*v/max),x=pad+i*bw+bw*.18,y=H-h;
    return `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${(bw*.64).toFixed(1)}" height="${h.toFixed(1)}" rx="4" fill="${i===n-1?color:color+'99'}"/>${v?`<text x="${(x+bw*.32).toFixed(1)}" y="${(y-4).toFixed(1)}" text-anchor="middle" font-size="9.5" fill="#cfd6d9">${unit(v)}</text>`:''}<text x="${(x+bw*.32).toFixed(1)}" y="${H+13}" text-anchor="middle" font-size="9.5" fill="#8b959a">${labels[i]}</text>`;}).join('')}</svg>`; }
function lineChart(pts,color){ if(!pts.length) return ''; const W=320,H=120,pad=16, vs=pts.map(p=>p.v), mx=Math.max(...vs), mn=Math.min(...vs);
  const X=i=>pts.length===1?W/2:pad+i*(W-2*pad)/(pts.length-1), Y=v=>mx===mn?H/2:H-pad-(v-mn)*(H-2*pad)/(mx-mn);
  const pl=pts.map((p,i)=>`${X(i).toFixed(1)},${Y(p.v).toFixed(1)}`).join(' ');
  return `<svg viewBox="0 0 ${W} ${H}" class="pchart"><polyline points="${pl}" fill="none" stroke="${color}" stroke-width="2.5" stroke-linejoin="round"/>${pts.map((p,i)=>`<circle cx="${X(i).toFixed(1)}" cy="${Y(p.v).toFixed(1)}" r="3.5" fill="${color}"/>`).join('')}
    <text x="4" y="12" font-size="10" fill="#8b959a">${fd1(mx)}</text><text x="4" y="${H-4}" font-size="10" fill="#8b959a">${fd1(mn)}</text></svg>`; }

function renderProg(){
  const now=new Date(), m0=monOf(now), weeks=[...Array(8)].map((_,i)=>addD(m0,-7*(7-i)));
  const wVol=weeks.map(w=>LOG.filter(l=>{const d=parseD(l.date);return d>=w&&d<addD(w,7);}).reduce((a,l)=>a+(l.vol||0),0));
  const wCnt=weeks.map(w=>LOG.filter(l=>{const d=parseD(l.date);return d>=w&&d<addD(w,7);}).length);
  const lbl=weeks.map(w=>w.getDate()+'.'+(w.getMonth()+1)+'.');
  const since=ymd(addD(now,-30)), gs={};
  GROUPS.forEach(g=>{ if(g[0]!=='cardio') gs[g[0]]=0; });
  LOG.filter(l=>l.date>=since).forEach(l=>{ for(const id in (l.sets||{})){ const e=exById(id); if(!e) continue; e.g.forEach(g=>{ if(g in gs) gs[g]+=l.sets[id].length; }); } });
  const gmax=Math.max(1,...Object.values(gs)), weak=Object.entries(gs).filter(([k,v])=>v===0&&k!=='po').map(([k])=>gname(k));
  const vol=totalVol(), mins=LOG.length?Math.round(LOG.reduce((a,l)=>a+(l.mins||0),0)/LOG.length):0;
  const st=badgeStats(), un=unlockedBadges();
  const bw=BODY.filter(b=>b.w), last=BODY[BODY.length-1]||{};
  const MEAS=[['w','Gewicht','kg'],['bauch','Bauch','cm'],['brust','Brust','cm'],['arm','Oberarm','cm'],['bein','Oberschenkel','cm']];
  const diffTxt=k=>{ const xs=BODY.filter(b=>b[k]); if(xs.length<2) return ''; const d=xs[xs.length-1][k]-xs[0][k]; return `<em style="color:${(k==='bauch'||(k==='w'&&['ab','def'].includes(prof.goal))?-d:d)>=0?'#7dff9c':'#ff9a6e'}">${d>=0?'+':''}${fd1(d)}</em>`; };
  $('vProg').innerHTML=`
  <h3 class="vh first">📊 Statistik</h3>
  <div class="stats3" style="margin-top:0"><div><b>${LOG.length}</b><small>Trainings</small></div><div><b>${vol>=1000?fd1(vol/1000)+' t':Math.round(vol)+' kg'}</b><small>bewegt gesamt</small></div><div><b>${st.streak} 🔥</b><small>Wochen-Serie</small></div></div>
  <div class="pc"><div class="pch"><b>Trainingsvolumen pro Woche</b><small>kg × Wdh., letzte 8 Wochen</small></div>
    ${LOG.length?barChart(wVol,lbl,'#c6ff3d',v=>v>=1000?fd1(v/1000)+'t':Math.round(v)):'<p class="muted">Noch keine Trainings – starte im Plan mit „▶ Training starten“.</p>'}
    ${LOG.length?`<div class="pch" style="margin-top:6px"><b>Trainings pro Woche</b><small>Ø ${mins} Min. pro Training</small></div>${barChart(wCnt,lbl,'#ff9a48',v=>v)}`:''}</div>
  <div class="pc"><div class="pch"><b>Sätze pro Muskelgruppe</b><small>letzte 30 Tage</small></div>
    ${Object.entries(gs).map(([k,v])=>`<div class="gbar"><span>${gname(k)}</span><i><u style="width:${100*v/gmax}%"></u></i><b>${v}</b></div>`).join('')}
    ${LOG.length&&weak.length?`<p class="muted">💡 Zuletzt nicht trainiert: <b style="color:var(--txt)">${weak.join(', ')}</b></p>`:''}</div>

  <h3 class="vh">⚖️ Körper &amp; Maße</h3>
  <div class="pc">
    <div class="form" style="margin-top:0">
      <label class="full">Datum<input id="bDate" type="date" value="${ymd(now)}"></label>
      ${MEAS.map(([k,n,u])=>`<label>${n} (${u})<input id="b_${k}" inputmode="decimal" placeholder="${last[k]?fd1(last[k]):'–'}"></label>`).join('')}
    </div>
    <button class="savebtn" id="bSave">Eintragen</button>
    ${bw.length?`<div class="pch" style="margin-top:16px"><b>Gewichtsverlauf</b><small>${fd1(bw[bw.length-1].w)} kg ${diffTxt('w')}</small></div>${lineChart(bw.slice(-20).map(b=>({v:b.w})),'#c6ff3d')}`:''}
    ${BODY.length?`<div class="mgrid">${MEAS.map(([k,n,u])=>{const xs=BODY.filter(b=>b[k]);return xs.length?`<div><small>${n}</small><b>${fd1(xs[xs.length-1][k])} ${u}</b>${diffTxt(k)}</div>`:'';}).join('')}</div>
      <details class="info" style="margin-top:12px"><summary>Alle Einträge (${BODY.length})</summary>${[...BODY].reverse().map(b=>`<div class="brow"><span>${fmtD(parseD(b.date))}</span><span>${MEAS.filter(([k])=>b[k]).map(([k,n,u])=>`${n.slice(0,5)} ${fd1(b[k])}`).join(' · ')}</span><button data-bdel="${b.date}">✕</button></div>`).join('')}</details>`:'<p class="muted">Trag regelmäßig (z. B. jeden Montag morgens) dein Gewicht ein – das neueste Gewicht wird automatisch für deinen Kalorien- und Eiweißbedarf übernommen.</p>'}
  </div>

  <h3 class="vh">📸 Fortschrittsfotos</h3>
  <div class="pc"><div id="photoBox"><p class="muted" style="margin:0">Lade …</p></div>
    <label class="photobtn">📷 Foto aufnehmen / auswählen<input type="file" id="phIn" accept="image/*" hidden></label>
    <p class="muted">Fotos bleiben nur auf deinem Handy (und in deinem Backup). Tipp: immer gleiches Licht, gleiche Pose.</p></div>

  <h3 class="vh">🎖 Abzeichen <small style="text-transform:none;letter-spacing:0">${un.length}/${BADGES.length}</small></h3>
  <div class="bgrid">${BADGES.map(b=>`<div class="bdg ${un.includes(b[0])?'on':''}"><span>${b[1]}</span><b>${b[2]}</b><small>${b[3]}</small></div>`).join('')}</div>

  <h3 class="vh">🧮 Rechner</h3>
  <div class="pc"><div class="pch"><b>Scheiben-Rechner</b><small>Was kommt auf jede Seite?</small></div>
    <div class="form" style="margin-top:8px"><label>Zielgewicht (kg)<input id="plKg" inputmode="decimal" value="60"></label><label>Stange<select id="plBar"><option value="20">20 kg (Langhantel)</option><option value="15">15 kg</option><option value="10">10 kg (SZ)</option><option value="0">ohne Stange</option></select></label></div>
    <div class="calcout" id="plOut"></div></div>
  <div class="pc"><div class="pch"><b>Maximalkraft (1RM)</b><small>Wie viel schaffst du für 1 Wiederholung?</small></div>
    <div class="form" style="margin-top:8px"><label>Gewicht (kg)<input id="rmKg" inputmode="decimal" value="60"></label><label>Wiederholungen<input id="rmR" inputmode="numeric" value="8"></label></div>
    <div class="calcout" id="rmOut"></div></div>`;
  // Körper speichern
  $('bSave').onclick=()=>{ const date=$('bDate').value||ymd(new Date()), e={date}; let any=false;
    MEAS.forEach(([k])=>{ const v=numDE($('b_'+k).value); if(v>0){ e[k]=v; any=true; } });
    if(!any){ toast2('Bitte mindestens einen Wert eintragen'); return; }
    const i=BODY.findIndex(b=>b.date===date); if(i>=0) BODY[i]=Object.assign(BODY[i],e); else BODY.push(e);
    BODY.sort((a,b)=>a.date<b.date?-1:1); saveBody();
    const lw=[...BODY].reverse().find(b=>b.w); if(lw&&typeof prof==='object'){ prof.w=String(lw.w); saveProf(); }
    toast2('Eingetragen ✓'); checkBadges(); renderProg(); };
  document.querySelectorAll('[data-bdel]').forEach(b=>b.onclick=()=>{ if(!confirm('Eintrag löschen?')) return; BODY=BODY.filter(x=>x.date!==b.dataset.bdel); saveBody(); renderProg(); });
  // Rechner
  const pl=()=>{ const kg=numDE($('plKg').value), bar=+$('plBar').value; const r=kg>0?platesFor(kg,bar):null;
    $('plOut').innerHTML=!(kg>0)?'':!r?`Zielgewicht ist leichter als die Stange.`:`Pro Seite: <b>${platesTxt(r)}</b>${r.rest>0.01?`<br><small>Rest ${fd1(r.rest*2)} kg nicht mit Standard-Scheiben möglich</small>`:''}`; };
  $('plKg').oninput=pl; $('plBar').onchange=pl; pl();
  const rm=()=>{ const kg=numDE($('rmKg').value), r=parseInt($('rmR').value); if(!(kg>0&&r>0)){ $('rmOut').innerHTML=''; return; }
    const one=e1rmCalc(kg,r); $('rmOut').innerHTML=`Geschätztes Maximum: <b>${fd1(round25(one))} kg</b><div class="rmt">${[[95,2],[90,4],[85,6],[80,8],[75,10],[70,12],[60,15]].map(([p,w])=>`<span>${p}%<b>${fd1(round25(one*p/100))} kg</b><small>~${w} Wdh.</small></span>`).join('')}</div>`; };
  $('rmKg').oninput=rm; $('rmR').oninput=rm; rm();
  // Fotos
  $('phIn').onchange=async e=>{ const f=e.target.files&&e.target.files[0]; if(!f) return; try{ const data=await shrink(f); await photoPut({id:'p'+Date.now(),date:ymd(new Date()),data}); toast2('Foto gespeichert ✓'); }catch(err){ toast2('Foto konnte nicht gespeichert werden'); } e.target.value=''; renderPhotos(); };
  renderPhotos();
}
async function renderPhotos(){ const box=$('photoBox'); if(!box) return; const ps=await photoAll();
  if(!ps.length){ box.innerHTML='<p class="muted" style="margin:0 0 4px">Noch keine Fotos. Mach heute dein Vorher-Bild – in ein paar Wochen siehst du den Unterschied!</p>'; return; }
  const a=ps[0], b=ps[ps.length-1];
  box.innerHTML=`${ps.length>1?`<div class="cmp"><figure><img src="${a.data}" alt=""><figcaption>Vorher · ${fmtD(parseD(a.date))}</figcaption></figure><figure><img src="${b.data}" alt=""><figcaption>Jetzt · ${fmtD(parseD(b.date))}</figcaption></figure></div>`:''}
    <div class="phgrid">${[...ps].reverse().map(p=>`<button data-ph="${p.id}"><img src="${p.data}" alt=""><span>${parseD(p.date).getDate()}.${parseD(p.date).getMonth()+1}.</span></button>`).join('')}</div>`;
  box.querySelectorAll('[data-ph]').forEach(btn=>btn.onclick=()=>{ const p=ps.find(x=>x.id===btn.dataset.ph); let ov=$('phView');
    if(!ov){ ov=document.createElement('div'); ov.id='phView'; ov.className='prpop'; document.body.appendChild(ov); }
    ov.innerHTML=`<div class="phbig"><img src="${p.data}" alt=""><div>${fmtD(parseD(p.date))}</div><div class="row2"><button id="phClose">Schließen</button><button id="phDel" class="del">Löschen</button></div></div>`;
    ov.classList.add('on'); $('phClose').onclick=()=>ov.classList.remove('on');
    $('phDel').onclick=async()=>{ if(!confirm('Foto löschen?')) return; await photoDel(p.id); ov.classList.remove('on'); renderPhotos(); }; }); }

/* ---------- Profil: Erinnerungen & Backup ---------- */
const ICS_DAY=['MO','TU','WE','TH','FR','SA','SU'];
document.addEventListener('click',e=>{ const b=e.target.closest&&e.target.closest('[data-lang]'); if(b&&b.dataset.lang!==LANG) setLang(b.dataset.lang); });
function renderSettings(){
  const box=$('setBox'); if(!box) return; let rt={time:'17:00',pre:'30'}; try{Object.assign(rt,JSON.parse(testLocal.getItem('mc_rem')||'{}'))}catch(e){}
  const bak=testLocal.getItem('mc_bak');
  box.innerHTML=`
  <h3 class="vh">🌐 Sprache · Language</h3>
  <div class="pcard"><div class="langsw"><button data-lang="de" class="${LANG==='de'?'on':''}">🇩🇪 Deutsch</button><button data-lang="en" class="${LANG==='en'?'on':''}">🇬🇧 English</button></div></div>
  <h3 class="vh">⭐ Vollversion</h3>
  <div class="pcard"><p style="font-size:14px;margin-bottom:${MC.unlocked&&MC.kind!=='master'?'10px':'0'}">${MC.unlocked?(MC.kind==='master'?LX('Freigeschaltet – <b>unbegrenzt</b> (Master-Code).','Unlocked – <b>unlimited</b> (master code).'):LX(`Gültig bis <b>${new Date(MC.until).toLocaleDateString('de-DE')}</b> · noch <b>${MC.daysLeft} Tage</b>. Die Vollversion gilt jeweils 1 Jahr.`,`Valid until <b>${new Date(MC.until).toLocaleDateString('en-GB')}</b> · <b>${MC.daysLeft} days</b> left. The full version is valid for 1 year at a time.`)):(MC.expired?LX('<b style="color:#ff9a6e">Abgelaufen.</b> Mit einem neuen Code hast du wieder 1 Jahr die Vollversion.','<b style="color:#ff9a6e">Expired.</b> With a new code you get the full version for another year.'):(MC.trial?LX(`Demo – noch <b>${MC.left} Tage</b>. Die Vollversion gilt danach jeweils 1 Jahr.`,`Demo – <b>${MC.left} days</b> left. After that the full version is valid for 1 year at a time.`):LX('Basis-Version. Die Vollversion gilt jeweils 1 Jahr.','Basic version. The full version is valid for 1 year at a time.')))}</p>
  ${MC.kind==='master'&&MC.unlocked?'':`<button class="savebtn" onclick="MC_GATE.${MC.unlocked?'show(\'renew\')':'code()'}">🔑 ${MC.unlocked?'Mit neuem Code verlängern':'Code eingeben'}</button>`}</div>
  <h3 class="vh">💬 Fragen &amp; Kontakt</h3>
  <div class="pcard"><p style="font-size:14px;margin-bottom:10px">Der Live-Chat ist in der TESTVERSION deaktiviert.</p><button class="savebtn" onclick="openChat()">💬 Chat öffnen</button></div>
  <h3 class="vh">🧍 Dein Coach-Look</h3>
  ${MC.pro?'':'<div class="pcard"><p style="font-size:14px">🔒 3D-Coach mit 14 Looks (Männer, Frauen & Anatomie) gibt es in der <b>Vollversion</b>.</p><button class="savebtn" onclick="upsell()">Vollversion holen</button></div><div hidden>'}<div class="pcard"><div class="lookhd">👨 Männer</div><div class="lookgrid" id="lookGrid">${COACH_LOOKS.map((l,i)=>`${i===6?'</div><div class="lookhd">👩 Frauen</div><div class="lookgrid">':''}${i===12?'</div><div class="lookhd">🔬 Anatomie & Pro</div><div class="lookgrid">':''}<button data-look="${i}" class="${(curLookIdx()===i)?'on':''}"><b>${l[0]}</b><small>${l[1]}</small></button>`).join('')}</div>
    <p class="muted">So sieht deine 3D-Figur in allen Übungen aus.</p></div>${MC.pro?'':'</div>'}
  ${INST.standalone()?'':'<h3 class="vh">📲 App</h3><div class="pcard"><p style="font-size:14px">Leg Muskel-Coach als App auf deinen Startbildschirm – mit eigenem Icon, Vollbild und offline nutzbar.</p><button class="savebtn" onclick="openInstall()">Als App installieren</button></div>'}
  <h3 class="vh">⚙️ Trainings-Optionen</h3>
  <div class="pcard"><label class="optrow"><span><b>📊 Durchschnitt im Training</b><small>Ø Gewicht und Ø Wiederholungen bei jeder Übung anzeigen</small></span><input type="checkbox" id="optAvg" ${optOn('avg')?'checked':''}></label>
    <p class="muted">🔗 <b>Supersätze</b> stellst du im Plan ein: zwischen zwei Übungen auf „Als Supersatz verbinden“ tippen.</p></div>
  <h3 class="vh">⏰ Trainings-Erinnerung</h3>
  <div class="pcard">
    <p style="font-size:14px">Deine Trainingstage: <b>${SCHED.wd.map(i=>WD[i]).join(', ')||'–'}</b> <span class="muted" style="margin:0">(änderbar im Kalender)</span></p>
    <div class="form"><label>Uhrzeit<input type="time" id="remTime" value="${rt.time}"></label>
      <label>Erinnern<select id="remPre"><option value="0">zur Trainingszeit</option><option value="15">15 Min. vorher</option><option value="30">30 Min. vorher</option><option value="60">1 Std. vorher</option><option value="120">2 Std. vorher</option></select></label></div>
    <button class="savebtn" id="remIcs">📅 In Handy-Kalender eintragen</button>
    <a class="gcal" id="remG" target="_blank" rel="noopener">Google Kalender (Android) öffnen</a>
    <p class="muted">Es werden wöchentlich wiederkehrende Termine mit Erinnerung angelegt. iPhone: Datei öffnen → „Alle hinzufügen“. Hast du deine Trainingstage geändert, einfach nochmal eintragen (alte Termine vorher im Kalender löschen).</p>
  </div>
  <h3 class="vh">💾 Datensicherung</h3>
  <div class="pcard">
    <p style="font-size:14px">Letzte Sicherung: <b style="color:${bak?'#7dff9c':'#ff9a6e'}">${bak?fmtD(parseD(bak)):'noch nie'}</b></p>
    <p class="muted" style="margin-top:4px">Sichert Trainings, Rekorde, Plan, Profil, Körperwerte und Fotos in einer Datei. Speichere sie in „Dateien“/iCloud oder schick sie dir per WhatsApp. Damit kannst du alles auf ein neues Handy übertragen.</p>
    <button class="savebtn" id="bakMake">💾 Backup erstellen</button>
    <label class="savebtn sec2">📂 Backup laden<input type="file" id="bakIn" accept=".json,application/json" hidden></label>
  </div>`;
  $('remPre').value=rt.pre;
  $('optAvg').onchange=e=>{ setOpt('avg',e.target.checked); toast2(e.target.checked?'Durchschnitt wird angezeigt':'Durchschnitt ausgeblendet'); };
  document.querySelectorAll('.lookgrid').forEach(g=>g.onclick=e=>{const b=e.target.closest('[data-look]'); if(!b) return; applyLook(+b.dataset.look,true); renderSettings(); toast2('Look übernommen ✓'); });
  const saveRt=()=>{ rt={time:$('remTime').value||'17:00',pre:$('remPre').value}; try{testLocal.setItem('mc_rem',JSON.stringify(rt))}catch(e){} $('remG').href=gcalUrl(rt); };
  $('remTime').onchange=saveRt; $('remPre').onchange=saveRt; $('remG').href=gcalUrl(rt);
  $('remIcs').onclick=()=>{ saveRt(); deliverFile(new Blob([icsText(rt)],{type:'text/calendar'}),'muskel-coach-training.ics','Muskel-Coach Trainingstermine'); };
  $('bakMake').onclick=makeBackup;
  $('bakIn').onchange=e=>{ const f=e.target.files&&e.target.files[0]; if(f) loadBackup(f); e.target.value=''; };
}
function nextDateFor(wd){ let d=new Date(); d.setHours(0,0,0,0); while(wdOf(d)!==wd) d=addD(d,1); return d; }
const icsDT=(d,t)=>ymd(d).replace(/-/g,'')+'T'+t.replace(':','')+'00';
function icsText(rt){ const stamp=new Date().toISOString().replace(/[-:]/g,'').slice(0,15)+'Z';
  const ev=SCHED.wd.map(w=>['BEGIN:VEVENT','UID:mc-'+w+'-'+Date.now()+'@muskel-coach','DTSTAMP:'+stamp,'DTSTART:'+icsDT(nextDateFor(w),rt.time),'DURATION:PT1H15M',
    'RRULE:FREQ=WEEKLY;BYDAY='+ICS_DAY[w],'SUMMARY:💪 Training – Muskel-Coach','DESCRIPTION:Zeit für dein Training! Öffne Muskel-Coach: '+appUrl(),
    'BEGIN:VALARM','ACTION:DISPLAY','DESCRIPTION:Gleich Training! 💪','TRIGGER:-PT'+(+rt.pre||0)+'M','END:VALARM','END:VEVENT'].join('\r\n'));
  return ['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Muskel-Coach//DE','CALSCALE:GREGORIAN',...ev,'END:VCALENDAR'].join('\r\n'); }
function gcalUrl(rt){ const w=SCHED.wd.length?SCHED.wd:[0], d=nextDateFor(w[0]), [h,m]=rt.time.split(':').map(Number), e=new Date(d); d.setHours(h,m); e.setHours(h,m+75);
  const f=x=>ymd(x).replace(/-/g,'')+'T'+String(x.getHours()).padStart(2,'0')+String(x.getMinutes()).padStart(2,'0')+'00';
  return 'https://calendar.google.com/calendar/render?action=TEMPLATE&text='+encodeURIComponent('💪 Training – Muskel-Coach')+'&dates='+f(d)+'/'+f(e)+'&recur='+encodeURIComponent('RRULE:FREQ=WEEKLY;BYDAY='+w.map(i=>ICS_DAY[i]).join(','))+'&details='+encodeURIComponent('Öffne Muskel-Coach: '+appUrl()); }
async function deliverFile(blob,name,title){
  try{ const file=new File([blob],name,{type:blob.type}); if(navigator.canShare&&navigator.canShare({files:[file]})){ await navigator.share({files:[file],title}); return true; } }catch(e){ if(e&&e.name==='AbortError') return false; }
  const url=URL.createObjectURL(blob), a=document.createElement('a'); a.href=url; a.download=name; document.body.appendChild(a); a.click(); setTimeout(()=>{URL.revokeObjectURL(url); a.remove();},4000); return true; }
const BAK_KEYS=['mc_log','mc_plan','mc_prof','mc_sched','mc_favs','mc_body','mc_badges','mc_rem','mc_look','mc_tests','mc_opts','mc_avatar'];
async function makeBackup(){ const data={}; BAK_KEYS.forEach(k=>{ const v=testLocal.getItem(k); if(v!==null) data[k]=v; });
  const photos=await photoAll(); const obj={app:'muskel-coach-test',v:1,date:new Date().toISOString(),data,photos};
  const ok=await deliverFile(new Blob([JSON.stringify(obj)],{type:'application/json'}),'muskel-coach-test-backup-'+ymd(new Date())+'.json','Muskel-Coach Backup');
  if(ok){ try{testLocal.setItem('mc_bak',ymd(new Date()))}catch(e){} checkBadges(); renderSettings(); toast2('Backup erstellt ✓'); } }
function loadBackup(file){ const fr=new FileReader(); fr.onload=async()=>{ try{ const o=JSON.parse(fr.result); if(o.app!=='muskel-coach-test'||!o.data) throw 0;
    if(!confirm('Backup vom '+new Date(o.date).toLocaleDateString('de-DE')+' laden? Die aktuellen Daten auf diesem Handy werden ersetzt.')) return;
    Object.entries(o.data).forEach(([k,v])=>{ if(BAK_KEYS.includes(k)) testLocal.setItem(k,v); });
    for(const p of (o.photos||[])) await photoPut(p);
    alert('Backup geladen ✓ – die App startet neu.'); location.reload(); }catch(e){ alert('Das ist keine gültige Muskel-Coach-Sicherung.'); } }; fr.readAsText(file); }

/* ---------- Training: Scheiben & Aufwärmsätze ---------- */
function liveHelpers(it,ex){ if(!MC.pro||!it||it.id==='laufband') return ''; const cur=it.sets.find(s=>!s.done)||it.sets[0], kg=kgNum(cur&&cur.kg); let h='';
  if(/Langhantel/.test(ex.equip||'')&&kg>=20){ const r=platesFor(kg,20); if(r) h+=`<div class="lvhelp">🧮 <b>${fd1(kg)} kg</b> = Stange 20 kg + pro Seite <b>${platesTxt(r)}</b></div>`; }
  if(CAT[it.id]==='big'&&kg>=30&&!it.sets.some(s=>s.done)) h+=`<div class="lvhelp warm">🔥 <b>Aufwärmsätze:</b> 10 × ${fd1(round25(kg*.5))} kg · 5 × ${fd1(round25(kg*.7))} kg · 3 × ${fd1(round25(kg*.85))} kg – dann Arbeitssätze</div>`;
  return h; }

/* ---------- Start: Backup-Hinweis ---------- */
function backupNag(){ const bak=testLocal.getItem('mc_bak'); if(LOG.length<3) return ''; if(bak&&ymd(addD(new Date(),-14))<=bak) return '';
  return `<button class="nag" id="nagBak">💾 <span><b>${bak?'Letzte Sicherung ist über 2 Wochen alt':'Deine Daten sind noch nicht gesichert'}</b><small>Jetzt Backup erstellen, damit nichts verloren geht ›</small></span></button>`; }


/* =====================================================================
   „WAS IST NEU“ – bei jedem Update einmal anzeigen, 5 Tage als NEU markieren
   Für ein neues Update: APP_VERSION ändern, RELEASE-Datum setzen, CHANGES ausfüllen.
   ===================================================================== */
const APP_VERSION='2026-11-24b';
const RELEASE='2026-11-22';
const CHANGES=[
  ['🏠','Neue Startseite','3D-Pro-Athlet als Motivation, Black-Friday-Angebot mit Countdown, Wochen-Statistik (Trainings, Serie, Rekorde) und neue Schnellzugriff-Kacheln'],
  ['🧢','Pro Athlet ist Standard','Die 3D-Figur startet jetzt im Look „Pro Athlet“. Andere Looks kannst du weiter im Profil wählen.'],
  ['📷','Bild-Modus für Übungen','Übungen können jetzt als realistische Bilder (Start · Mitte · Ende) mit flüssiger Überblendung laufen – mit Muskel-Beschriftung. Oben rechts wechselst du jederzeit zwischen Bild und 3D.'],
  ['💪','Besserer Körper','Mehr Muskeldetails (Brust, Schultern, Sägezahn, Rücken, Oberschenkel, Waden), feinere Oberfläche, natürlicheres Licht – und die 3D-Figur lädt schneller'],
  ['🧢','Neuer Look: Pro Athlet','Graue Profi-Figur mit Cap und rot leuchtenden Muskeln – dazu Beschriftung am Muskel mit Fachnamen (z. B. Pectoralis major)'],
  ['💳','Einfach bezahlen','Vollversion jetzt direkt mit Karte, Apple Pay oder Google Pay kaufen – der Freischalt-Code kommt per E-Mail'],
  ['⭐','Vollversion jetzt 1 Jahr','Die Vollversion gilt 365 Tage ab Freischaltung. Im Profil siehst du, bis wann – verlängern geht jederzeit mit einem neuen Code.'],
  ['🦾','Bewegungen überarbeitet','Alle 90 Übungen geprüft: Dips, Butterfly, Kabel-Crossover, Sitz-Maschinen, Klimmzüge u. a. jetzt realistischer und besser nachzumachen'],
  ['🎬','Neue 3D-Ansicht','Wie ein Bewegungslabor: Muskel-Karte, Ablauf mit Schieberegler zum Vor- und Zurückspulen, Tempo, Kamera schräg/seitlich/hinten'],
  ['🔬','Neuer Look: Anatomie','Muskelfigur wie im Anatomie-Atlas – Hauptmuskeln rot, Hilfsmuskeln rosa. Im Profil unter „Coach-Look“'],
  ['🔑','Code eingeben','Neuer Knopf „Code eingeben“ unten im Demo-Feld – direkt zum Freischalten'],
  ['🔥','Black Friday −50 %','Verlängert bis 02.12.: Vollversion nur 4,99 € statt 9,99 € – auch schon während der 10-Tage-Demo sichtbar'],
  ['🌐','Jetzt auch auf Englisch','Im Profil unter „Sprache“ zwischen Deutsch und Englisch umschalten – Übungen, Pläne und alle Texte'],
  ['💬','Vollversion per Chat','Direkt in der App „Vollversion“ schreiben → PayPal-Adresse kommt → persönlicher Code, der nur einmal gilt'],
  ['👩','6 Frauen-Figuren','Im Profil unter „Coach-Look“: Pferdeschwanz, Blond, Bob, Dutt, Zopf, Pixie – mit Sport-BH, Shorts oder Leggings'],
  ['🔗','Supersätze','Zwei Übungen im Plan verbinden – im Training ohne Pause hintereinander, Pause erst danach'],
  ['📊','Durchschnittswerte','Ø Gewicht & Ø Wiederholungen im Training und bei jeder Übung (im Profil abschaltbar)'],
  ['🔥','Grenztest','Maximalkraft testen, Verlauf sehen und passende Trainingsgewichte (60–90 %) bekommen'],
  ['⚙️','15 neue Maschinen-Übungen','Butterfly, Latzug eng & Untergriff, Rudermaschine, Rückenstrecker, Abduktor/Adduktor, Po-Kickback … – ideal für Einsteiger'],
  ['🗂️','Neue Gruppe „Maschinen“','Alle geführten Übungen auf einen Blick – mit Tipps zur passenden Gewichtsstufe'],
  ['⏭','Übung überspringen','Gerät belegt oder defekt? Einzelne Übung im Training überspringen – der Rest läuft weiter'],
  ['💾','Abbrechen ohne Verlust','Beim Abbrechen wählen: Bisher Geschafftes speichern oder verwerfen – der Plan bleibt immer erhalten'],
  ['👀','Testlauf','Training nur ansehen und ausprobieren – es wird nichts gespeichert'],
  ['🏋️','31 neue Übungen','Brust, Bauch, Schultern, Trizeps, Bizeps – mit Kurzhantel, Langhantel & Seilzug'],
  ['✊','Neue Gruppe „Unterarme“','Handgelenk-Curls, Farmer’s Walk, Handgelenk-Roller, Dead Hang u. v. m.'],
  ['🧍','Menschlichere 3D-Figur','Glatte Haut, echtes Gesicht – und im Profil 6 Coach-Looks zur Auswahl'],
  ['📋','Deine Pläne bleiben gleich','Neue Übungen kannst du im Plan über „Übung hinzufügen“ einbauen']
];
/* Black-Friday-Hinweis ab 1.12.2026 aus „Was ist neu“ entfernen */
if(Date.now()>=new Date(2026,11,3).getTime()){ const i=CHANGES.findIndex(c=>c[1]==='Black Friday −50 %'); if(i>=0) CHANGES.splice(i,1); }
const NEW_DAYS=5;
const isFresh=(d)=>{ const until=addD(parseD(d||RELEASE),NEW_DAYS); return ymd(new Date())<=ymd(until); };
const isNewEx=e=>!!(e&&e.neu&&isFresh(e.neuDate||RELEASE));
const WN_SHOW=5; /* so viele Neuigkeiten sieht man sofort, der Rest per „weitere anzeigen“ */
function whatsNewHTML(all){ const d=parseD(RELEASE); const n=CHANGES.length;
  const list=all?CHANGES:CHANGES.slice(0,WN_SHOW);
  /* je mehr Einträge, desto kompakter: Schriftgröße, Abstand, Textzeilen */
  const k=list.length, f=k<=3?15:k<=5?14:k<=8?13:12.5, gap=k<=5?10:7, lines=k<=3?3:k<=6?2:1;
  return `<div class="wnbox wnfit" style="--wf:${f}px;--wg:${gap}px;--wl:${lines}"><button class="wnx" id="wnX" aria-label="Schließen">✕</button>
    <div class="wnhd"><span>✨</span><div><b>Neu in Muskel-Coach</b><small>Update vom ${d.getDate()}.${d.getMonth()+1}.${d.getFullYear()}</small></div></div>
    <ul>${list.map(c=>`<li><i>${c[0]}</i><div><b>${esc(c[1])}</b><small>${esc(c[2])}</small></div></li>`).join('')}</ul>
    ${!all&&n>WN_SHOW?`<button class="wnmore" id="wnMore">+ ${n-WN_SHOW} weitere Neuerung${n-WN_SHOW>1?'en':''} anzeigen</button>`:''}
    <button class="savebtn" id="wnOk">Alles klar 💪</button></div>`; }
function showWhatsNew(force){ let seen=''; try{ seen=testLocal.getItem('mc_seen_ver')||''; }catch(e){}
  if(!force&&seen===APP_VERSION) return;
  let ov=$('wnPop'); if(!ov){ ov=document.createElement('div'); ov.id='wnPop'; ov.className='wnpop'; document.body.appendChild(ov); }
  ov.classList.add('wn');
  const close=()=>{ ov.classList.remove('on'); try{ testLocal.setItem('mc_seen_ver',APP_VERSION); }catch(e){} };
  const draw=all=>{ ov.innerHTML=whatsNewHTML(all); $('wnX').onclick=close; $('wnOk').onclick=close; const m=$('wnMore'); if(m) m.onclick=e=>{ e.stopPropagation(); draw(true); }; };
  draw(false); ov.classList.add('on'); ov.onclick=e=>{ if(e.target===ov) close(); }; }
function newBanner(){ if(!isFresh(RELEASE)) return '';
  return `<button class="wnbanner" id="wnBan"><span>✨</span><div><b>Neu: ${esc(CHANGES[0][1])}${CHANGES.length>1?` &amp; ${CHANGES.length-1} weitere Neuerung${CHANGES.length>2?'en':''}`:''}</b><small>Tippen für alle Neuigkeiten</small></div><em>NEU</em></button>`; }
(function waitGate(){ const gg=document.getElementById('gate'); if(gg&&gg.style.display!=='none') return setTimeout(waitGate,500); setTimeout(()=>showWhatsNew(false),700); })();


/* =====================================================================
   „ALS APP INSTALLIEREN“ – Android: 1 Tipp · iPhone: geführte Anleitung
   ===================================================================== */
const INST=(function(){
  const ua=navigator.userAgent||'', iOS=/iPhone|iPad|iPod/.test(ua)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1),
    android=/Android/i.test(ua), inApp=/FBAN|FBAV|Instagram|Line\/|WhatsApp|wv\)|; wv/i.test(ua),
    iosSafari=iOS&&/Safari/i.test(ua)&&!/CriOS|FxiOS|EdgiOS|OPiOS/i.test(ua)&&!inApp, iosOther=iOS&&!iosSafari;
  const standalone=()=>(window.matchMedia&&matchMedia('(display-mode: standalone)').matches)||navigator.standalone===true;
  let deferred=null;
  window.addEventListener('beforeinstallprompt',e=>{ e.preventDefault(); deferred=e; try{ renderInstallCard(); }catch(x){} });
  window.addEventListener('appinstalled',()=>{ deferred=null; try{ testLocal.setItem('mc_installed','1'); }catch(e){} closeInstall(); try{ toast2('✅ App installiert – du findest sie jetzt auf dem Startbildschirm'); renderInstallCard(); }catch(e){} });
  return {iOS,android,inApp,iosSafari,iosOther,standalone,get deferred(){return deferred;},set deferred(v){deferred=v;}};
})();
const SHARE_ICO='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#4da3ff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15V3"/><path d="M7.5 7.5 12 3l4.5 4.5"/><path d="M6 10H5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-1"/></svg>';
const ADD_ICO='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round"><rect x="3" y="3" width="18" height="18" rx="4"/><path d="M12 8v8M8 12h8"/></svg>';
function installHTML(){
  const step=(n,t,ico)=>`<li><span class="n">${n}</span><div>${t}</div>${ico?`<span class="ic">${ico}</span>`:''}</li>`;
  let body='';
  if(INST.inApp){
    body=`<p>Du hast den Link in <b>WhatsApp/Instagram</b> geöffnet. Dort kann man keine Apps installieren.</p>
      <ol class="isteps">${step(1,`Tippe oben rechts auf <b>⋯</b> bzw. das Kompass-Symbol`)}${step(2,`Wähle <b>„In ${INST.iOS?'Safari':'Chrome'} öffnen“</b>`)}${step(3,'Dann hier nochmal auf <b>„Als App installieren“</b> tippen')}</ol>`;
  } else if(INST.deferred){
    body=`<p>Mit einem Tipp landet Muskel-Coach als <b>echte App</b> auf deinem Startbildschirm – mit eigenem Icon, im Vollbild und auch offline.</p>
      <button class="savebtn" id="instNow">📲 Jetzt installieren</button>`;
  } else if(INST.iosSafari){
    body=`<p>So kommt Muskel-Coach als <b>App</b> auf deinen Home-Bildschirm (dauert 10 Sekunden):</p>
      <ol class="isteps">${step(1,'Unten in Safari auf <b>Teilen</b> tippen <small style="display:block;color:var(--mut)">Neuere iPhones: erst auf <b>⋯</b> (unten rechts), dann auf <b>Teilen</b></small>',SHARE_ICO)}${step(2,'Nach unten wischen und <b>„Zum Home-Bildschirm“</b> wählen <small style="display:block;color:var(--mut)">ggf. „Als Web-App öffnen“ eingeschaltet lassen</small>',ADD_ICO)}${step(3,'Oben rechts auf <b>„Hinzufügen“</b> tippen – fertig! 🎉')}</ol>
      <p class="muted">Apple erlaubt Websites nicht, das automatisch zu machen – deshalb diese 3 Tipps.</p>`;
  } else if(INST.iosOther){
    body=`<p>Auf dem iPhone geht das am besten in <b>Safari</b>:</p>
      <ol class="isteps">${step(1,'Link kopieren und in <b>Safari</b> öffnen (oder in Chrome: Teilen-Symbol oben rechts)')}${step(2,'<b>Teilen</b> antippen',SHARE_ICO)}${step(3,'<b>„Zum Home-Bildschirm“</b> → <b>„Hinzufügen“</b>',ADD_ICO)}</ol>`;
  } else if(INST.android){
    body=`<p>So kommt Muskel-Coach als <b>App</b> auf deinen Startbildschirm:</p>
      <ol class="isteps">${step(1,'Oben rechts im Browser auf <b>⋮</b> tippen')}${step(2,'<b>„App installieren“</b> oder <b>„Zum Startbildschirm hinzufügen“</b> wählen')}${step(3,'Mit <b>„Installieren“</b> bestätigen – fertig! 🎉')}</ol>`;
  } else {
    body=`<p>Öffne diesen Link auf deinem <b>Handy</b> – dort kannst du Muskel-Coach als App auf den Startbildschirm legen. Am Computer: im Chrome/Edge-Adressfeld auf das <b>Installieren-Symbol</b> klicken.</p>`;
  }
  return `<div class="instbox"><button class="wnx" id="instX" aria-label="Schließen">✕</button>
    <div class="insthd"><img src="icon-192.png" alt=""><div><b>Als App installieren</b><small>Muskel-Coach · kostenlos · ohne App Store</small></div></div>
    ${body}<button class="later" id="instLater">Später</button></div>`;
}
function openInstall(){ let ov=$('instPop'); if(!ov){ ov=document.createElement('div'); ov.id='instPop'; ov.className='instpop'; document.body.appendChild(ov); }
  ov.innerHTML=installHTML(); ov.classList.add('on');
  $('instX').onclick=closeInstall; $('instLater').onclick=closeInstall; ov.onclick=e=>{ if(e.target===ov) closeInstall(); };
  const b=$('instNow'); if(b) b.onclick=async()=>{ const d=INST.deferred; if(!d) return; d.prompt(); try{ const r=await d.userChoice; if(r&&r.outcome==='accepted'){ try{testLocal.setItem('mc_installed','1')}catch(e){} closeInstall(); } }catch(e){} INST.deferred=null; }; }
function closeInstall(){ const ov=$('instPop'); if(ov) ov.classList.remove('on'); try{ testLocal.setItem('mc_inst_pop',String(Date.now())); }catch(e){} }
function renderInstallCard(){ const box=$('instBox'); if(!box) return; if(INST.standalone()){ box.innerHTML=''; return; }
  box.innerHTML=`<button class="instcard" id="instCard"><img src="icon-192.png" alt=""><div><b>📲 Als App installieren</b><small>${INST.deferred?'Ein Tipp – fertig':'Mit eigenem Icon auf den Startbildschirm'}</small></div><em>›</em></button>`;
  $('instCard').onclick=openInstall; }
// automatisch anbieten: beim ersten Mal, danach höchstens alle 3 Tage – nur wenn nicht schon als App geöffnet
(function autoInstall(){ if(INST.standalone()) return;
  const busy=()=>{ const g=document.getElementById('gate'); return (g&&g.style.display!=='none')||document.querySelector('#wnPop.on,.sheet.open'); };
  let last=0; try{ last=+testLocal.getItem('mc_inst_pop')||0; }catch(e){}
  if(Date.now()-last<3*864e5) return;
  let tries=0; (function wait(){ if(busy()&&tries++<120) return setTimeout(wait,1000); setTimeout(()=>{ if(!busy()&&!INST.standalone()) openInstall(); },1500); })(); })();


/* =====================================================================
   ENTWICKLER-MODUS (5× auf das Logo oben links tippen · Passwort)
   ===================================================================== */
(function(){ let taps=0,t=0; document.addEventListener('click',e=>{ if(!e.target.closest('.tb-logo')) return; const now=Date.now(); taps=now-t<700?taps+1:1; t=now; if(taps>=5){ taps=0; devLogin(); } }); })();
function devLogin(){ if(testSession.getItem('mc_dev')==='1') return devOpen();
  let ov=$('devPop'); if(!ov){ ov=document.createElement('div'); ov.id='devPop'; ov.className='wnpop'; document.body.appendChild(ov); }
  ov.innerHTML=`<form class="wnbox" id="devForm" autocomplete="off"><button type="button" class="wnx" id="devX">✕</button><div class="wnhd"><span>🛠️</span><div><b>Entwickler-Modus</b><small>Nur für den Entwickler</small></div></div>
    <input id="devPw" type="password" placeholder="Test-Passwort" class="devin"><div class="err" id="devErr" style="color:#ff9a6e;font-size:13px;min-height:18px"></div><button class="savebtn" type="submit">Öffnen</button></form>`;
  ov.classList.add('on'); $('devX').onclick=()=>ov.classList.remove('on'); setTimeout(()=>$('devPw').focus(),100);
  $('devForm').onsubmit=e=>{ e.preventDefault(); $('devErr').textContent='⏳'; if($('devPw').value.trim()==='TEST-DEV'){ testSession.setItem('mc_dev','1'); ov.classList.remove('on'); devOpen(); } else $('devErr').textContent='Falsches Passwort'; }; }
let DEVC=[]; try{ DEVC=JSON.parse(testLocal.getItem('mc_dev_codes')||'[]'); }catch(e){}
const saveDevC=()=>{ try{ testLocal.setItem('mc_dev_codes',JSON.stringify(DEVC)); }catch(e){} };
function devOpen(){ let ov=$('devSheet'); if(!ov){ ov=document.createElement('div'); ov.id='devSheet'; ov.className='devsheet'; document.body.appendChild(ov); }
  ov.classList.add('on'); document.body.style.overflow='hidden'; devRender(); devStats(); }
function devClose(){ const ov=$('devSheet'); if(ov) ov.classList.remove('on'); document.body.style.overflow=''; }
function devRender(){ const ov=$('devSheet');
  ov.innerHTML=`<div class="devtop"><button class="iconbtn" id="devBack">← Zurück</button><b>🛠️ Entwickler</b><button class="iconbtn" id="devLock">🔒 Sperren</button></div>
  <div class="devwrap">
    <h3 class="vh first">📊 Nutzer</h3>
    <div class="devstats" id="devStats"><div><b>…</b><small>Nutzer gesamt</small></div><div><b>…</b><small>heute aktiv</small></div><div><b>…</b><small>Vollversion</small></div><div><b>…</b><small>Codes eingelöst</small></div></div>
    <div class="pc devlive" id="devLive"><span class="ldot"></span><b>…</b><small>gerade online (letzte 5 Min.)</small></div>
    <div class="pc" id="devWeek"><p class="muted" style="margin:0">Lade Verlauf …</p></div>
    <p class="muted">Zählt anonym jedes Gerät einmal (ohne Namen oder persönliche Daten). Wer alle Website-Daten löscht, wird neu gezählt.</p>

    <h3 class="vh">🌍 Länder</h3>
    <div class="pc" id="devCC"><p class="muted" style="margin:0">Lade Länder …</p></div>
    <p class="muted">Ermittelt aus Zeitzone und Spracheinstellung des Handys – ohne IP-Adresse, anonym. Zählt jedes Gerät einmal ab diesem Update (frühere Nutzer erst beim nächsten Öffnen).</p>

    <h3 class="vh">🎟️ Freischalt-Code erzeugen</h3>
    <div class="pc">
      <button class="savebtn" id="devGen">🎲 Neuen lokalen Testcode erzeugen</button>
      <div id="devNew"></div>
      <p class="muted">Jeder Code funktioniert <b>genau einmal</b> – danach ist er verbraucht. Der Testcode gilt nur in diesem Browserprofil.</p>
    </div>
    <h3 class="vh">📋 Vergebene Codes <small style="text-transform:none;letter-spacing:0">${DEVC.length}</small></h3>
    <div class="pc">${DEVC.length?`<div class="devlist">${DEVC.slice().reverse().map(c=>`<div data-c="${c.code}"><code>${c.code}</code><span>${esc(c.who||c.mail||'–')}<small>${fmtD(parseD(c.date))}${c.ord?' · '+esc(c.ord):''}${c.mail&&c.who?' · '+esc(c.mail):''}</small></span><em class="st">${c.used?'✅ eingelöst':'⏳ offen'}</em></div>`).join('')}</div>
      <button class="savebtn sec2" id="devCheck">🔄 Status aller Codes prüfen</button>`:'<p class="muted" style="margin:0">Noch keine Codes erzeugt.</p>'}</div>
    <h3 class="vh">🧪 Test-Werkzeuge</h3>
    <div class="pc"><p class="muted" style="margin:0 0 8px">So sieht die App für Kunden aus – nur zum Ansehen. Deine eigene Freischaltung bleibt erhalten.</p>
      <div class="devview">${[['','⭐ Vollversion'],['basic','🔓 Basis-Version'],['trial','🎁 Demo'],['renew','⏳ Noch 5 Tage'],['expired','⌛ Abgelaufen']].map(([k,l])=>`<button data-dv="${k}" class="${(MC.preview||'')===k?'on':''}">${l}</button>`).join('')}</div>
      ${MC.real.unlocked?'':'<p class="muted" style="margin:8px 0 0">⚠️ Erst auf diesem Handy freischalten (z. B. Master-Code), dann funktioniert die Vorschau.</p>'}</div>
    <div class="pc devtools"><button id="devConf">🎉 Glückwunsch-Fenster ansehen</button><button id="devWN">„Was ist neu“ erneut zeigen</button></div>
  </div>`;
  $('devBack').onclick=devClose; $('devLock').onclick=()=>{ testSession.removeItem('mc_dev'); devClose(); toast2('Entwickler-Modus gesperrt'); };
  $('devGen').onclick=()=>{ let code; do{ code=makeCode(); }while(DEVC.some(c=>c.code===code));
    DEVC.push({code,date:ymd(new Date()),used:false}); saveDevC();
    devRender(); devStats();
    $('devNew').innerHTML=`<div class="devcode">${code}</div><button class="savebtn sec2" id="devCopy">📋 Kopieren</button>`;
    $('devCopy').onclick=async()=>{ try{ await navigator.clipboard.writeText(code); toast2('Kopiert ✓'); }catch(e){ toast2(code); } }; };
  const chk=$('devCheck'); if(chk) chk.onclick=async()=>{ chk.textContent='⏳ Prüfe …'; for(const c of DEVC){ const v=await cntGet('c-'+c.code); if(v!==null) c.used=v>0; } saveDevC(); devRender(); devStats(); toast2('Status aktualisiert'); };
  document.querySelectorAll('[data-dv]').forEach(b=>b.onclick=()=>{ if(!MC.real.unlocked){ toast2('Erst auf diesem Handy freischalten'); return; } const k=b.dataset.dv; try{ k?testLocal.setItem('mc_dev_view',k):testLocal.removeItem('mc_dev_view'); }catch(e){} location.reload(); });
  $('devConf').onclick=()=>{ devClose(); celebrateUnlock(MC.real.kind==='master'?0:Date.now()+365*864e5,false); };
  $('devWN').onclick=()=>{ devClose(); showWhatsNew(true); };
}
async function devLive(){ const box=$('devLive'); if(!box) return; const b=onBucket();
  const [a,c]=await Promise.all([cntGet('on-'+b,0),cntGet('on-'+(b-1),0)]); if(!$('devLive')) return;
  const n=(a===null&&c===null)?null:Math.max(a||0,c||0); $('devLive').querySelector('b').textContent=n===null?'–':n;
  clearTimeout(devLive.t); const ov=$('devSheet'); if(ov&&ov.classList.contains('on')) devLive.t=setTimeout(devLive,30000); }
async function devCC(){ const box=$('devCC'); if(!box) return;
  let C={}; try{ C=JSON.parse(testLocal.getItem('mc_dev_cc')||'{}'); }catch(e){}
  const draw=(st)=>{ if(!$('devCC')) return; const rows=Object.entries(C.v||{}).filter(([k,v])=>v>0).sort((a,b)=>b[1]-a[1]); const tot=rows.reduce((a,b)=>a+b[1],0)||1;
    $('devCC').innerHTML=(rows.length?`<div class="cclist">${rows.map(([k,v])=>`<div><span>${ccFlag(k)} ${CC_NAMES[k]||k}</span><i style="width:${Math.max(3,Math.round(100*v/tot))}%"></i><b>${v}</b></div>`).join('')}</div>`:'<p class="muted" style="margin:0">Noch keine Länder gezählt.</p>')
      +`<p class="muted" style="margin:6px 0 0;font-size:12px">${st==='load'?'⏳ Wird aktualisiert …':st==='err'?'⚠️ Zähldienst antwortet gerade nicht':'✓ Aktuell'}</p>`; };
  draw('load'); const keys=[...CC_LIST,'XX'], v={}; let any=false;
  for(let i=0;i<keys.length;i+=6){ const r=await Promise.all(keys.slice(i,i+6).map(k=>cntGet('cc-'+k,0))); r.forEach((n,j)=>{ if(n!==null){ any=true; v[keys[i+j]]=n; } }); if(!$('devCC')) return; }
  if(!any){ draw('err'); return; } C={v,at:Date.now()}; try{ testLocal.setItem('mc_dev_cc',JSON.stringify(C)); }catch(e){} draw('ok'); }
async function devStats(force){ setTimeout(devCC,600); devLive(); if(!$('devStats')) return;
  const today=new Date(); const k=d=>'d-'+d.toISOString().slice(0,10).replace(/-/g,'');
  const days=[...Array(7)].map((_,i)=>new Date(today.getTime()-(6-i)*864e5));
  const f=v=>v===null||v===undefined?'–':Number(v).toLocaleString('de-DE');
  const draw=(S,state)=>{ if(!$('devStats')) return; const red=DEVC.filter(c=>c.used).length;
    $('devStats').innerHTML=`<div><b>${f(S.u)}</b><small>Nutzer gesamt</small></div><div><b>${f(S.t)}</b><small>heute aktiv</small></div><div><b>${f(S.p)}</b><small>Vollversion</small></div><div><b>${red}</b><small>Codes eingelöst</small></div>`;
    const vals=S.w||[]; const mx=Math.max(1,...vals.map(v=>v||0)); const age=S.at?Math.round((Date.now()-S.at)/60000):null;
    $('devWeek').innerHTML=`<div class="pch"><b>Aktive Nutzer – letzte 7 Tage</b><button class="iconbtn" id="devRef" style="padding:4px 10px;font-size:12px">🔄</button></div>
      ${vals.length?`<div class="devbars">${days.map((d,i)=>`<div><i style="height:${Math.round(100*(vals[i]||0)/mx)}%"></i><b>${vals[i]??'–'}</b><small>${['So','Mo','Di','Mi','Do','Fr','Sa'][d.getDay()]}</small></div>`).join('')}</div>`:''}
      <p class="muted" style="margin:6px 0 0;font-size:12px">${state==='load'?'⏳ Wird aktualisiert …':state==='week'?'⏳ Verlauf wird geladen …':state==='err'?'⚠️ Zähldienst antwortet gerade nicht'+(CNT_ERR?' ('+CNT_ERR+')':'')+' – angezeigt wird der letzte Stand. 🔄 tippen zum Neu laden.':(age===null?'':age<1?'✓ Gerade aktualisiert':'Stand: vor '+age+' Min.')}</p>`;
    const rb=$('devRef'); if(rb) rb.onclick=()=>devStats(true); };
  let S={}; try{ S=JSON.parse(testLocal.getItem('mc_dev_stats')||'{}'); }catch(e){}
  draw(S,'load');
  /* nacheinander statt alles gleichzeitig – schont den kostenlosen Zähldienst */
  const main=await Promise.all(['users',k(today),'pro-users','unlocks'].map(x=>cntGet(x))); if(!$('devStats')) return;
  if(main.every(v=>v===null)){ draw(S,'err'); return; }
  S={...S,u:main[0]??S.u,t:main[1]??S.t,p:(main[2]===null&&main[3]===null)?S.p:Math.max(main[2]||0,main[3]||0),at:Date.now()};
  draw(S,'week');
  const w=[]; for(let i=0;i<days.length;i+=2){ w.push(...await Promise.all(days.slice(i,i+2).map(d=>cntGet(k(d),0)))); if(!$('devStats')) return; }
  if(!w.every(v=>v===null)) S.w=w;
  try{ testLocal.setItem('mc_dev_stats',JSON.stringify(S)); }catch(e){}
  draw(S,'ok'); }

setTimeout(()=>{ try{ start3DThumbs().catch(e=>console.warn('3D',e)); }catch(e){ console.warn('3D',e); } },400);
renderSummary(); renderChips(); renderGrid(); (function(){let t='home';try{t=testLocal.getItem('mc_tab')||'home'}catch(e){} setView(t);})(); route(); heroLoop(); initShare();
$('tback').onclick=closeLive; $('resume').onclick=openLive;
$('restPlus').onclick=()=>{ if(restEnd){ restEnd+=15000; restTotal+=15; tickLive(); } };
$('restSkip').onclick=()=>{ restEnd=0; tickLive(); };

updResume();

/* ===== Demo-Countdown, Basis-Version & Freischalten per Code ===== */
/* tawk: Chat-ID aus tawk.to (Format 'xxxxxxxx/yyyyyyy'), leer = kein Chat */
/* Angebot: old = alter Preis (durchgestrichen), sale = Name der Aktion. Angebot beenden: old:'' und sale:'' setzen. */
function priceTag(){ return '<b style="color:var(--acc)">kostenloser Testzugang</b>'; }
function openChat(){ toast2('TESTVERSION · Live-Chat ist deaktiviert.'); }
(function(){
  const g=document.getElementById('gate');
  if(MC.unlocked&&MC.kind==='master'){ g.remove(); window.MC_GATE={show(){},code(){}}; return; }
  g.style.display='none';
  const left=MC.left;
  const dots=()=>Array.from({length:MC.TRIAL},(_,i)=>`<i class="${i<left?(left<=2?'hot':'on'):''}"></i>`).join('');
  function show(mode,why){
    g.style.display='flex'; document.body.style.overflow='hidden';
    const fmtD2=t=>new Date(t).toLocaleDateString(LANG==='en'?'en-GB':'de-DE');
    if(mode==='renew') mode='code';
    const head = mode==='expired'
      ? `<div class="cd hot"><b>0</b><span>Tage<br>Vollversion</span></div><p><b style="color:#ff9a6e">Deine Vollversion ist abgelaufen.</b> Sie gilt jeweils 1 Jahr. Du nutzt jetzt die kostenlose Basis-Version – mit einem neuen Code hast du wieder ein Jahr alles für ${priceTag()}.</p>`
      : mode==='trial'
      ? `<div class="cd ${left<=2?'hot':''}"><b>${left}</b><span>${left===1?'Tag':'Tage'}<br>Vollversion gratis</span></div><div class="cddots">${dots()}</div>
         <p>TESTVERSION · Du kannst alle Übungen in der Demo ausprobieren. Käufe sind deaktiviert.</p>`
      : `<p>${why?`🔒 <b>${String(why).replace(/[<>]/g,'')}</b> gehört zur Vollversion.<br>`:'<b style="color:#ff9a6e">Deine 10-Tage-Demo ist vorbei.</b> Du nutzt jetzt die kostenlose Basis-Version.<br>'}Hol dir alles für 1 Jahr – nur ${priceTag()}:</p>`;
    const codeForm=()=>`<form class="box codebox" id="gateForm" autocomplete="off">
      <div style="font-size:54px;line-height:1">🔑</div>
      <h2>Freischalt-Code</h2>
      <p>Gib hier den <b>lokalen Testcode</b> ein, den du in dieser TESTVERSION erzeugt hast. ${MC.unlocked?`Deine Vollversion läuft noch bis <b>${fmtD2(MC.until)}</b>. Mit einem neuen Code verlängerst du um <b>1 Jahr</b> – die Resttage bleiben erhalten.`:'Danach ist die Vollversion <b>1 Jahr</b> lang freigeschaltet.'}</p>
      <input id="gatePw" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="TEST-123456" aria-label="Freischalt-Code">
      <button type="submit">Freischalten</button>
      <div class="err" id="gateErr"></div>
      <div class="codelbl" style="margin-top:14px">TESTVERSION · Käufe deaktiviert</div>
      <button type="button" class="later" id="gateLater">Abbrechen</button>
    </form>`;
    g.innerHTML=mode==='code'?codeForm():`<form class="box" id="gateForm" autocomplete="off">
      <img src="icon-512.png" alt="Muskel-Coach" style="width:84px;height:84px;border-radius:20px;box-shadow:0 8px 30px rgba(255,40,40,.35)">
      ${head}
      <ul class="profeat">${PRO_FEATURES.map(f=>`<li><i>${f[0]}</i><div><b>${f[1]}</b><small>${f[2]}</small></div></li>`).join('')}</ul>
      <p>TESTVERSION · Käufe sind deaktiviert. Gib einen lokal erzeugten Testcode ein.</p>
      <input id="gatePw" type="password" autocomplete="off" placeholder="TEST-123456" aria-label="Freischalt-Code">
      <button type="submit">Freischalten</button>
      <div class="err" id="gateErr"></div>
      <button type="button" class="later" id="gateLater">${mode==='trial'?'Weiter testen ›':'Mit Basis-Version weiter ›'}</button>
    </form>`;
    document.getElementById('gateForm').addEventListener('submit',ev=>{ ev.preventDefault();
      const v=document.getElementById('gatePw').value.trim();
      /* Schutz gegen Durchprobieren: nach 5 falschen Codes Wartezeit 3 Min., jedes weitere Mal +3 Min. */
      let F={n:0,u:0}; try{ F=Object.assign(F,JSON.parse(testLocal.getItem('mc_code_fail')||'{}')); }catch(e){}
      if(F.u>Date.now()){ document.getElementById('gateErr').textContent='Zu viele falsche Versuche – bitte in '+Math.ceil((F.u-Date.now())/60000)+' Min. erneut versuchen.'; return; }
      const failAdd=()=>{ F.n++; if(F.n>=5) F.u=Date.now()+3*60000*(F.n-4); try{ testLocal.setItem('mc_code_fail',JSON.stringify(F)); }catch(e){} };
      const failReset=()=>{ try{ testLocal.removeItem('mc_code_fail'); }catch(e){} };
      const okUnlock=(k)=>{ failReset(); const u=MC.grant(k==='master'?'master':'code'); cntHit('unlocks'); g.style.display='none'; celebrateUnlock(u,true); };
      if(!v) return;
      if(v==='TEST-MASTER'){ okUnlock('master'); return; }
      const err=document.getElementById('gateErr');
      redeemCode(v).then(result=>{
        if(result==='ok'){ okUnlock('code'); return; }
        failAdd();
        err.textContent=result==='used'?'Dieser Testcode wurde schon verwendet.':'Falscher Code – bitte nochmal prüfen.';
        g.classList.remove('shake'); void g.offsetWidth; g.classList.add('shake');
      }).catch(()=>{ err.textContent='Testcode konnte lokal nicht geprüft werden.'; });
    });
    document.getElementById('gateLater').onclick=hide;
    if(mode==='code') setTimeout(()=>{ try{ document.getElementById('gatePw').focus(); }catch(e){} },250);
  }
  function hide(){ g.style.display='none'; document.body.style.overflow=''; try{ testLocal.setItem('mc_trial_pop',new Date().toDateString()); }catch(e){} if(!MC.unlocked||MC.daysLeft<=30) pill(); else { const b=document.getElementById('demoPill'); if(b) b.remove(); } }
  function pill(){ let b=document.getElementById('demoPill'); if(!b){ b=document.createElement('div'); b.id='demoPill'; b.className='demopill'; document.body.appendChild(b); }
    if(MC.unlocked){ const d=MC.daysLeft; b.classList.toggle('hot',d<=7);
      b.innerHTML=`<button type="button" class="dpmain">⭐ Vollversion · noch <b>${d} ${d===1?'Tag':'Tage'}</b></button><button type="button" class="dpcode">🔑 Verlängern</button>`;
      b.querySelector('.dpmain').onclick=()=>show('renew'); b.querySelector('.dpcode').onclick=()=>show('renew'); return; }
    b.classList.toggle('hot',MC.trial&&left<=2);
    b.innerHTML=`<button type="button" class="dpmain">${MC.trial?`🎁 Demo · noch <b>${left} ${left===1?'Tag':'Tage'}</b>`:`🔓 Basis · <b>Vollversion Testzugang</b>`}</button><button type="button" class="dpcode">🔑 Code eingeben</button>`;
    b.querySelector('.dpmain').onclick=()=>show(MC.trial?'trial':'basic');
    b.querySelector('.dpcode').onclick=()=>show('code'); }
  window.MC_GATE={show,code:()=>show('code')};
  let popped=''; try{ popped=testLocal.getItem('mc_trial_pop')||''; }catch(e){}
  let basicSeen=''; try{ basicSeen=testLocal.getItem('mc_basic_seen')||''; }catch(e){}
  if(MC.preview){ try{ testLocal.removeItem('mc_renew_pop'); testLocal.removeItem('mc_exp_seen'); testLocal.removeItem('mc_trial_pop'); }catch(e){} }
  if(MC.unlocked){ const d=MC.daysLeft; if(d<=30){ const step=d<=1?1:d<=7?7:30; let last=0; try{ last=+testLocal.getItem('mc_renew_pop')||0; }catch(e){}
      if(last!==step){ try{ testLocal.setItem('mc_renew_pop',String(step)); }catch(e){} show('renew'); } else pill(); } }
  else if(MC.expired){ let es=''; try{ es=testLocal.getItem('mc_exp_seen')||''; }catch(e){} if(es!==String(MC.until)){ try{ testLocal.setItem('mc_exp_seen',String(MC.until)); }catch(e){} show('expired'); } else pill(); }
  else if(MC.trial){ if(popped===new Date().toDateString()) pill(); else show('trial'); }
  else { if(!basicSeen){ try{ testLocal.setItem('mc_basic_seen','1'); }catch(e){} show('basic'); } else pill(); }
})();

/* Hinweis, solange der Entwickler eine andere Version ansieht */
(function(){ if(!MC.preview) return; const n={basic:'Basis-Version',trial:'Demo (noch 7 Tage)',expired:'Vollversion abgelaufen',renew:'Vollversion – noch 5 Tage'}[MC.preview];
  const b=document.createElement('button'); b.className='pvbar'; b.innerHTML='👁 Vorschau: <b>'+n+'</b> · <u>zurück zur Vollversion</u>';
  b.onclick=()=>{ try{ testLocal.removeItem('mc_dev_view'); }catch(e){} location.reload(); }; document.body.appendChild(b); })();

/* Titel oben passt sich der Breite an */
(function(){ const fit=()=>{ const h=document.querySelector('.topbar2 h1'); if(!h) return; let fs=22; h.style.fontSize=fs+'px'; while(h.scrollWidth>h.clientWidth+1&&fs>12){ fs-=.5; h.style.fontSize=fs+'px'; } };
  fit(); addEventListener('resize',fit); if(document.fonts&&document.fonts.ready) document.fonts.ready.then(fit); setTimeout(fit,800); })();
/* Ziehen zum Aktualisieren (auch in der installierten App, wo iOS das nicht selbst kann) */
(function(){ let y0=null,dy=0; const TH=70; const el=document.createElement('div'); el.id='ptr'; document.body.appendChild(el);
  const blocked=t=>{ for(let n=t;n&&n!==document.body;n=n.parentElement){ if(n.nodeName==='CANVAS'||n.nodeName==='INPUT'||n.nodeName==='TEXTAREA') return true; const cs=getComputedStyle(n); if(cs.position==='fixed') return true; if(/(auto|scroll)/.test(cs.overflowY)&&n.scrollTop>0) return true; } return document.body.style.overflow==='hidden'; };
  const show=d=>{ const v=Math.min(d*.5,90); el.style.transform=`translate(-50%,${v-40}px)`; el.style.opacity=Math.min(1,d/40); const go=d>TH*1.6; el.classList.toggle('go',go); el.textContent=go?'↻ Loslassen zum Aktualisieren':'↓ Ziehen zum Aktualisieren'; };
  addEventListener('touchstart',e=>{ y0=(window.scrollY<=0&&e.touches.length===1&&!blocked(e.target))?e.touches[0].clientY:null; dy=0; },{passive:true});
  addEventListener('touchmove',e=>{ if(y0===null) return; dy=e.touches[0].clientY-y0; if(dy<=0||window.scrollY>0){ el.style.opacity=0; return; } show(dy); },{passive:true});
  addEventListener('touchend',()=>{ if(y0===null) return; y0=null;
    if(dy>TH*1.6&&window.scrollY<=0){ el.classList.add('go'); el.textContent='⟳ Aktualisiere …'; el.style.transform='translate(-50%,10px)'; el.style.opacity=1; setTimeout(()=>location.reload(),250); }
    else { el.style.opacity=0; el.style.transform='translate(-50%,-70px)'; } dy=0; },{passive:true});
})();

(function(){
  const b=document.getElementById('saleBadge'); if(!b) return;
  const row=b.parentNode;
  function paint(){
    if(row) row.classList.toggle('hasbadge',!b.hidden);
    let pro=false; try{ pro=!!MC.unlocked; }catch(e){}
    if(pro){ if(b.className==='pro') return; b.hidden=false; b.className='pro'; b.innerHTML='<span class="gift">✓</span>Vollversion'; b.onclick=null; row&&row.classList.add('hasbadge'); return; }
    if(b.textContent==='Testzugang') return;
    b.hidden=false; b.className=''; row&&row.classList.add('hasbadge');
    b.textContent='Testzugang';
    b.setAttribute('aria-label','Testzugang');
    b.onclick=()=>{ try{ if(window.MC_GATE) MC_GATE.show(MC.trial?'trial':'basic'); else upsell(); }catch(e){ try{ upsell(); }catch(x){} } };
  }
  paint(); setInterval(paint,3000);
})();
