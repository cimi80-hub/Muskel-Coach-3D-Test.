Dr. Muskel Coach – 3D-Labor v0.1

Dateien:
- index.html: eigenständiger iPhone-kompatibler Three.js-Prototyp
- model.glb: vom Nutzer hochgeladenes CC0-Basismodell

Installation GitHub Pages:
1. Neues öffentliches Repository z.B. Muskel-Coach-3D-Test anlegen.
2. Beide Dateien im Wurzelverzeichnis hochladen (nicht nur die ZIP).
3. Settings > Pages > Deploy from a branch > main / (root) > Save.
4. Pages-Link im Safari öffnen.

Hinweis: Noch KEINE biomechanisch korrekte Bankdrück-Animation. Es handelt sich um einen Test des Skinned-Mesh-Rigs, mit prozeduralen Gelenkrotationen und schematischer Hantel. Anatomische Muskelschicht und restliche 89 Übungen sind nicht implementiert. Three.js wird über jsDelivr geladen, Internet nötig.
